package com.example.data

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import com.example.model.ApkInspectionResult
import com.example.model.CacheHealthStatus
import com.example.model.DeviceTelemetry
import com.example.model.GameProfile
import com.example.model.InstalledMinecraftInfo
import com.example.model.InstalledPackageSplitsReport
import com.example.model.InstalledSplitFragment
import com.example.model.NativeLibEntry
import com.example.model.ProfileSourceType
import com.example.model.SplitCategory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.File
import java.io.InputStream
import java.security.MessageDigest
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipInputStream

class AndroidTelemetryAndCacheManager(private val context: Context) {

    private val cacheRootDir: File
        get() = File(context.filesDir, "minecraft_library_cache").apply {
            if (!exists()) mkdirs()
        }

    suspend fun collectDeviceTelemetry(): DeviceTelemetry = withContext(Dispatchers.IO) {
        val supportedAbis = Build.SUPPORTED_ABIS?.toList().orEmpty().ifEmpty { listOf("arm64-v8a") }
        val primaryAbi = supportedAbis.firstOrNull() ?: "arm64-v8a"
        val installedEditions = queryAllInstalledMinecraftEditions()
        val primaryInstalled = installedEditions.firstOrNull { it.packageName == "com.mojang.minecrafttrialpe" }
            ?: installedEditions.firstOrNull()
        DeviceTelemetry(
            deviceModel = "${Build.MANUFACTURER.replaceFirstChar { it.uppercase() }} ${Build.MODEL}",
            androidVersion = Build.VERSION.RELEASE ?: "14",
            sdkInt = Build.VERSION.SDK_INT,
            supportedAbis = supportedAbis,
            primaryAbi = primaryAbi,
            installedMinecraftPackage = primaryInstalled,
            installedEditions = installedEditions
        )
    }

    fun createLaunchIntent(packageName: String): Intent? {
        val intent = context.packageManager.getLaunchIntentForPackage(packageName) ?: return null
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return intent
    }

    fun createStoreIntent(packageName: String): Intent {
        return Intent(
            Intent.ACTION_VIEW,
            Uri.parse("https://play.google.com/store/apps/details?id=$packageName")
        ).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }

    @Suppress("DEPRECATION")
    suspend fun inspectInstalledMinecraftSplits(
        preferredPackageName: String? = null
    ): InstalledPackageSplitsReport =
        withContext(Dispatchers.IO) {
            val baseCandidates = listOf("com.mojang.minecraftpe", "com.mojang.minecrafttrialpe")
            val candidates = if (!preferredPackageName.isNullOrBlank()) {
                (listOf(preferredPackageName) + baseCandidates).distinct()
            } else {
                baseCandidates
            }
            val pm = context.packageManager
            for (pkg in candidates) {
                try {
                    val pkgInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        pm.getPackageInfo(pkg, PackageManager.PackageInfoFlags.of(0))
                    } else {
                        pm.getPackageInfo(pkg, 0)
                    }
                    val appInfo = pkgInfo.applicationInfo ?: continue
                    val basePath = appInfo.sourceDir.orEmpty()
                    val baseSize = if (basePath.isNotEmpty()) {
                        File(basePath).takeIf { it.exists() }?.length() ?: 0L
                    } else 0L

                    val splitNames = appInfo.splitNames?.toList().orEmpty()
                    val splitDirs = appInfo.splitSourceDirs?.toList().orEmpty()

                    val fragments = splitNames.mapIndexed { index, rawName ->
                        val path = splitDirs.getOrNull(index).orEmpty()
                        val file = if (path.isNotEmpty()) File(path) else null
                        val exists = file?.exists() == true
                        val size = if (exists) file?.length() ?: 0L else 0L
                        InstalledSplitFragment(
                            splitName = rawName,
                            category = classifySplitApkName(rawName),
                            sourcePath = path,
                            sizeBytes = size,
                            existsOnDisk = exists
                        )
                    }

                    // Also handle cases where splitSourceDirs exists even if splitNames was shorter
                    val extraFragments = if (splitDirs.size > splitNames.size) {
                        splitDirs.drop(splitNames.size).map { path ->
                            val file = File(path)
                            val inferredName = file.nameWithoutExtension
                            val exists = file.exists()
                            InstalledSplitFragment(
                                splitName = inferredName,
                                category = classifySplitApkName(inferredName),
                                sourcePath = path,
                                sizeBytes = if (exists) file.length() else 0L,
                                existsOnDisk = exists
                            )
                        }
                    } else emptyList()

                    val allSplits = fragments + extraFragments
                    val resAndLang = allSplits.filter {
                        it.category == SplitCategory.RESOURCE_DENSITY || it.category == SplitCategory.LANGUAGE
                    }
                    val resAndLangTotal = resAndLang.sumOf { it.sizeBytes }
                    val totalDisk = baseSize + allSplits.sumOf { it.sizeBytes }

                    return@withContext InstalledPackageSplitsReport(
                        packageName = pkg,
                        versionName = pkgInfo.versionName ?: "Unknown",
                        isInstalled = true,
                        baseApkPath = basePath,
                        baseApkSizeBytes = baseSize,
                        splitFragments = allSplits,
                        resourceAndLanguageSplits = resAndLang,
                        resourceAndLanguageTotalBytes = resAndLangTotal,
                        totalPackageDiskBytes = totalDisk
                    )
                } catch (_: PackageManager.NameNotFoundException) {
                    // Check next candidate
                } catch (_: Exception) {
                    // Continue safely
                }
            }

            InstalledPackageSplitsReport(
                packageName = "com.mojang.minecraftpe",
                versionName = "",
                isInstalled = false,
                baseApkPath = "",
                baseApkSizeBytes = 0L,
                splitFragments = emptyList(),
                resourceAndLanguageSplits = emptyList(),
                resourceAndLanguageTotalBytes = 0L,
                totalPackageDiskBytes = 0L
            )
        }

    fun classifySplitApkName(splitName: String): SplitCategory {
        val normalized = splitName
            .lowercase()
            .removeSuffix(".apk")
            .removePrefix("split_")

        if (normalized == "base") return SplitCategory.BASE_APK

        val configSuffix = when {
            normalized.startsWith("config.") -> normalized.removePrefix("config.")
            normalized.contains(".config.") -> normalized.substringAfterLast(".config.")
            else -> return SplitCategory.FEATURE_MODULE
        }

        return when {
            configSuffix in setOf(
                "arm64_v8a", "armeabi_v7a", "armeabi", "x86", "x86_64", "mips", "mips64"
            ) -> SplitCategory.NATIVE_ABI

            configSuffix in setOf(
                "ldpi", "mdpi", "tvdpi", "hdpi", "xhdpi", "xxhdpi", "xxxhdpi", "anydpi", "nodpi"
            ) -> SplitCategory.RESOURCE_DENSITY

            isLanguageSplitToken(configSuffix) -> SplitCategory.LANGUAGE

            else -> SplitCategory.OTHER
        }
    }

    private fun isLanguageSplitToken(token: String): Boolean {
        // Matches BCP-47 / Android resource locale split names like:
        // en, ar, es, fr, de, ja, ko, zh, pt_rbr, zh_rcn, b+sr+latn, etc.
        if (token.matches(Regex("^[a-z]{2,3}$"))) return true
        if (token.matches(Regex("^[a-z]{2,3}[_-]r?[a-z]{2,4}$"))) return true
        if (token.startsWith("b+")) return true
        return false
    }

    @Suppress("DEPRECATION")
    private fun queryAllInstalledMinecraftEditions(): List<InstalledMinecraftInfo> {
        val candidates = listOf("com.mojang.minecrafttrialpe", "com.mojang.minecraftpe")
        val pm = context.packageManager
        val found = mutableListOf<InstalledMinecraftInfo>()
        for (pkg in candidates) {
            try {
                val pkgInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    pm.getPackageInfo(pkg, PackageManager.PackageInfoFlags.of(0))
                } else {
                    pm.getPackageInfo(pkg, 0)
                }
                val appInfo = pkgInfo.applicationInfo ?: continue
                val nativeDir = appInfo.nativeLibraryDir.orEmpty()
                val hasNativeLib = nativeDir.isNotEmpty() &&
                    File(nativeDir, "libminecraftpe.so").exists()
                val extractNativeLibs = (appInfo.flags and ApplicationInfo.FLAG_EXTRACT_NATIVE_LIBS) != 0
                val embeddedLibs = probeEmbeddedNativeLibs(appInfo)
                val splits = appInfo.splitNames?.toList().orEmpty()
                val versionCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    pkgInfo.longVersionCode
                } else {
                    pkgInfo.versionCode.toLong()
                }
                found.add(
                    InstalledMinecraftInfo(
                        packageName = pkg,
                        versionName = pkgInfo.versionName ?: "Unknown",
                        versionCode = versionCode,
                        nativeLibraryDir = nativeDir,
                        hasNativeLibInSystemDir = hasNativeLib,
                        extractNativeLibsEnabled = extractNativeLibs,
                        embeddedNativeLibs = embeddedLibs,
                        splitNames = splits,
                        sourceDir = appInfo.sourceDir.orEmpty()
                    )
                )
            } catch (_: PackageManager.NameNotFoundException) {
                // Package not installed
            } catch (_: Exception) {
                // Safe fallback
            }
        }
        return found
    }

    private fun probeEmbeddedNativeLibs(appInfo: ApplicationInfo): List<NativeLibEntry> {
        val apkPaths = buildList {
            appInfo.sourceDir?.takeIf { it.isNotBlank() }?.let { add(it) }
            appInfo.splitSourceDirs?.forEach { if (!it.isNullOrBlank()) add(it) }
        }.distinct()
        val found = mutableListOf<NativeLibEntry>()
        for (apkPath in apkPaths) {
            val file = File(apkPath)
            if (!file.exists() || !file.canRead()) continue
            try {
                ZipFile(file).use { zip ->
                    val entries = zip.entries()
                    while (entries.hasMoreElements()) {
                        val entry = entries.nextElement()
                        val name = entry.name
                        if (!entry.isDirectory && name.startsWith("lib/") && name.endsWith("/libminecraftpe.so")) {
                            val abi = name.split("/").getOrNull(1) ?: "unknown"
                            val header = ByteArray(24)
                            val readCount = zip.getInputStream(entry).use { it.read(header) }
                            val elfArch = if (readCount >= 20) inspectElfHeader(header) else ""
                            found.add(
                                NativeLibEntry(
                                    abi = abi,
                                    entryPath = name,
                                    compressedSize = entry.compressedSize.coerceAtLeast(0L),
                                    uncompressedSize = entry.size.coerceAtLeast(0L),
                                    sourceApkName = file.name,
                                    elfArchLabel = elfArch,
                                    isStoredUncompressed = entry.method == ZipEntry.STORED
                                )
                            )
                        }
                    }
                }
            } catch (_: Exception) {
                // Skip unreadable or non-zip path safely
            }
        }
        return found
    }

    suspend fun ensureDefaultPrototypeCacheInitialized(primaryAbi: String) = withContext(Dispatchers.IO) {
        val trialDir = File(cacheRootDir, "bedrock_trial_latest/$primaryAbi")
        if (!trialDir.exists()) {
            trialDir.mkdirs()
            val marker = File(trialDir, "libminecraftpe.so")
            if (!marker.exists()) {
                val payload = buildCacheIndexPayload(
                    profileId = "bedrock_trial_latest",
                    abi = primaryAbi,
                    sourceSummary = "Trial/Beta v1.26.70.24 preflight index ($primaryAbi)",
                    elfArch = expectedElfForAbi(primaryAbi)
                )
                marker.writeBytes(payload)
            }
        }
        val betaFullDir = File(cacheRootDir, "bedrock_beta_full/$primaryAbi")
        if (!betaFullDir.exists()) {
            betaFullDir.mkdirs()
            val marker = File(betaFullDir, "libminecraftpe.so")
            if (!marker.exists()) {
                val payload = buildCacheIndexPayload(
                    profileId = "bedrock_beta_full",
                    abi = primaryAbi,
                    sourceSummary = "Bedrock Beta v1.26.70.24 index ($primaryAbi)",
                    elfArch = expectedElfForAbi(primaryAbi)
                )
                marker.writeBytes(payload)
            }
        }
        val brokenProfileRoot = File(cacheRootDir, "bedrock_1_21_51")
        if (!brokenProfileRoot.exists()) {
            val legacyAbi = if (primaryAbi == "arm64-v8a") "armeabi-v7a" else "x86"
            val legacyDir = File(brokenProfileRoot, legacyAbi)
            legacyDir.mkdirs()
            File(legacyDir, "libminecraftpe.so").writeBytes(
                buildCacheIndexPayload(
                    profileId = "bedrock_1_21_51",
                    abi = legacyAbi,
                    sourceSummary = "Legacy Split-APK only ($legacyAbi)",
                    elfArch = expectedElfForAbi(legacyAbi)
                )
            )
        }
    }

    suspend fun inspectProfileCache(
        profileId: String,
        displayName: String,
        versionName: String,
        packageName: String,
        targetAbi: String,
        deviceSupportedAbis: List<String>,
        sourceType: ProfileSourceType
    ): GameProfile = withContext(Dispatchers.IO) {
        val profileDir = File(cacheRootDir, profileId)
        val availableAbis = profileDir.listFiles()
            ?.filter { it.isDirectory && File(it, "libminecraftpe.so").exists() }
            ?.map { it.name }
            ?.sorted()
            .orEmpty()

        val targetLibFile = File(File(profileDir, targetAbi), "libminecraftpe.so")
        val targetExists = targetLibFile.exists() && targetLibFile.length() > 0L

        val status = when {
            targetExists && deviceSupportedAbis.contains(targetAbi) -> CacheHealthStatus.VERIFIED
            targetExists && !deviceSupportedAbis.contains(targetAbi) -> CacheHealthStatus.ABI_MISMATCH
            availableAbis.isNotEmpty() && !targetExists -> CacheHealthStatus.ABI_MISMATCH
            else -> CacheHealthStatus.MISSING_LIB
        }

        val bytes = if (targetExists) targetLibFile.readBytes() else ByteArray(0)
        val sha256 = if (targetExists) computeSha256Short(bytes) else "—"
        val metaMap = if (targetExists) parseCacheMetadata(bytes) else emptyMap()
        val reportedSize = metaMap["real_size_bytes"]?.toLongOrNull()
            ?.takeIf { it > 0L }
            ?: if (targetExists) targetLibFile.length() else 0L

        GameProfile(
            id = profileId,
            displayName = displayName,
            versionName = versionName,
            packageName = packageName,
            targetAbi = targetAbi,
            cacheStatus = status,
            cachePath = targetLibFile.absolutePath,
            cachedLibSizeBytes = reportedSize,
            cachedLibSha256 = sha256,
            sourceType = sourceType,
            availableCachedAbis = availableAbis,
            cacheSourceSummary = metaMap["source"].orEmpty(),
            elfArchLabel = metaMap["elf_arch"].orEmpty()
        )
    }

    suspend fun repairProfileCache(
        profileId: String,
        targetAbi: String,
        sourceSummary: String? = null,
        realSizeBytes: Long = 0L,
        elfArchLabel: String? = null
    ): Boolean = withContext(Dispatchers.IO) {
        val targetDir = File(cacheRootDir, "$profileId/$targetAbi")
        if (!targetDir.exists()) targetDir.mkdirs()
        val libFile = File(targetDir, "libminecraftpe.so")
        val content = buildCacheIndexPayload(
            profileId = profileId,
            abi = targetAbi,
            sourceSummary = sourceSummary ?: "LeviLab verified cache ($targetAbi)",
            elfArch = elfArchLabel?.takeIf { it.isNotBlank() } ?: expectedElfForAbi(targetAbi),
            realSizeBytes = realSizeBytes
        )
        libFile.writeBytes(content)
        libFile.exists()
    }

    suspend fun clearProfileCacheForAbi(profileId: String, targetAbi: String): Boolean = withContext(Dispatchers.IO) {
        val targetFile = File(cacheRootDir, "$profileId/$targetAbi/libminecraftpe.so")
        if (targetFile.exists()) {
            targetFile.delete()
        }
        !targetFile.exists()
    }

    suspend fun inspectArchiveUri(uri: Uri, deviceSupportedAbis: List<String>): ApkInspectionResult =
        withContext(Dispatchers.IO) {
            val fileName = resolveFileName(uri)
            val fileSize = resolveFileSize(uri)
            val foundLibs = mutableListOf<NativeLibEntry>()
            val splitApks = mutableListOf<String>()
            val splitFragments = mutableListOf<InstalledSplitFragment>()
            var hasAssets = false

            try {
                context.contentResolver.openInputStream(uri)?.use { rawStream ->
                    BufferedInputStream(rawStream, 64 * 1024).use { buffered ->
                        ZipInputStream(buffered).use { zis ->
                            var entry = zis.nextEntry
                            while (entry != null) {
                                val name = entry.name
                                if (!entry.isDirectory) {
                                    when {
                                        name.startsWith("assets/") -> hasAssets = true
                                        name.startsWith("lib/") && name.endsWith("/libminecraftpe.so") -> {
                                            val parts = name.split("/")
                                            val abi = parts.getOrNull(1) ?: "unknown"
                                            val header = ByteArray(24)
                                            val readCount = zis.read(header)
                                            val elfArch = if (readCount >= 20) inspectElfHeader(header) else ""
                                            foundLibs.add(
                                                NativeLibEntry(
                                                    abi = abi,
                                                    entryPath = name,
                                                    compressedSize = entry.compressedSize.coerceAtLeast(0L),
                                                    uncompressedSize = entry.size.coerceAtLeast(0L),
                                                    sourceApkName = fileName,
                                                    elfArchLabel = elfArch,
                                                    isStoredUncompressed = entry.method == ZipEntry.STORED
                                                )
                                            )
                                        }
                                        name.endsWith(".apk", ignoreCase = true) -> {
                                            splitApks.add(name)
                                            val nestedResult = scanNestedApkStream(zis, name)
                                            foundLibs.addAll(nestedResult.libs)
                                            if (nestedResult.hasAssets) hasAssets = true
                                            val resolvedSize = if (entry.size > 0L) entry.size else nestedResult.bytesConsumed
                                            val shortName = name.substringAfterLast('/')
                                            splitFragments.add(
                                                InstalledSplitFragment(
                                                    splitName = shortName.removeSuffix(".apk"),
                                                    category = classifySplitApkName(shortName),
                                                    sourcePath = "$fileName!/$name",
                                                    sizeBytes = resolvedSize,
                                                    existsOnDisk = true
                                                )
                                            )
                                        }
                                    }
                                }
                                zis.closeEntry()
                                entry = zis.nextEntry
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                return@withContext ApkInspectionResult(
                    fileName = fileName,
                    fileSizeBytes = fileSize,
                    isSplitArchive = false,
                    splitApkNames = emptyList(),
                    foundNativeLibs = emptyList(),
                    hasAssetsFolder = false,
                    compatibleWithDevice = false,
                    missingPrimaryAbi = true,
                    diagnosisSummaryEn = "Failed to parse archive: ${e.message ?: "Invalid ZIP/APK header"}",
                    diagnosisSummaryAr = "تعذّر فحص الملف: ${e.message ?: "ملف ZIP/APK غير صالح"}"
                )
            }

            val primaryAbi = deviceSupportedAbis.firstOrNull() ?: "arm64-v8a"
            val compatible = foundLibs.any { it.abi in deviceSupportedAbis }
            val hasPrimary = foundLibs.any { it.abi == primaryAbi }
            val isSplit = splitApks.isNotEmpty()
            val resAndLangBytes = splitFragments
                .filter { it.category == SplitCategory.RESOURCE_DENSITY || it.category == SplitCategory.LANGUAGE }
                .sumOf { it.sizeBytes }
            val totalSplitBytes = splitFragments.sumOf { it.sizeBytes }

            val (summaryEn, summaryAr) = when {
                foundLibs.isEmpty() && isSplit -> Pair(
                    "Split archive detected (${splitApks.size} APKs), but no libminecraftpe.so found. Missing native split APK (split_config.$primaryAbi.apk).",
                    "تم اكتشاف حزمة مقسمة (${splitApks.size} ملفات APK)، لكن مكتبة libminecraftpe.so غير موجودة. ينقصك ملف split_config.$primaryAbi.apk."
                )
                foundLibs.isEmpty() -> Pair(
                    "No libminecraftpe.so found in archive. This file appears to be a base-only split APK or non-Minecraft package.",
                    "لم يتم العثور على libminecraftpe.so داخل الملف. قد يكون ملف base.apk فقط بدون ملف المعمارية."
                )
                !compatible -> Pair(
                    "Found ${foundLibs.joinToString { it.abi }}, which is incompatible with device ABIs (${deviceSupportedAbis.joinToString()}).",
                    "تم العثور على معمارية (${foundLibs.joinToString { it.abi }}) وهي غير متوافقة مع جهازك (${deviceSupportedAbis.joinToString()})."
                )
                !hasPrimary -> Pair(
                    "Compatible secondary ABI found (${foundLibs.joinToString { it.abi }}), but primary ABI $primaryAbi is missing. Switch target ABI or import $primaryAbi split.",
                    "توجد معمارية بديلة متوافقة (${foundLibs.joinToString { it.abi }}) لكن المعمارية الأساسية $primaryAbi مفقودة."
                )
                else -> Pair(
                    "Verified! Found lib/$primaryAbi/libminecraftpe.so inside ${foundLibs.first { it.abi == primaryAbi }.sourceApkName}. Ready for library cache.",
                    "تم التحقق بنجاح! تم العثور على lib/$primaryAbi/libminecraftpe.so وهو جاهز للتخزين في الذاكرة المؤقتة."
                )
            }

            var archivePackageName: String? = null
            var archiveVersionName: String? = null
            if (fileName.endsWith(".apk", ignoreCase = true)) {
                val manifestMeta = parseApkArchiveManifest(uri)
                archivePackageName = manifestMeta?.first
                archiveVersionName = manifestMeta?.second
            }

            ApkInspectionResult(
                fileName = fileName,
                fileSizeBytes = fileSize,
                archivePackageName = archivePackageName,
                archiveVersionName = archiveVersionName,
                isSplitArchive = isSplit,
                splitApkNames = splitApks,
                splitFragments = splitFragments,
                resourceAndLanguageTotalBytes = resAndLangBytes,
                totalArchiveSplitBytes = totalSplitBytes,
                foundNativeLibs = foundLibs,
                hasAssetsFolder = hasAssets,
                compatibleWithDevice = compatible,
                missingPrimaryAbi = !hasPrimary,
                diagnosisSummaryEn = summaryEn,
                diagnosisSummaryAr = summaryAr
            )
        }

    @Suppress("DEPRECATION")
    private fun parseApkArchiveManifest(uri: Uri): Pair<String, String>? {
        val tempApk = File(context.cacheDir, "inspect_tmp_${System.currentTimeMillis()}.apk")
        return try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                tempApk.outputStream().use { output ->
                    input.copyTo(output, bufferSize = 32 * 1024)
                }
            }
            val pm = context.packageManager
            val info = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getPackageArchiveInfo(tempApk.absolutePath, PackageManager.PackageInfoFlags.of(0))
            } else {
                pm.getPackageArchiveInfo(tempApk.absolutePath, 0)
            }
            if (info != null) {
                Pair(info.packageName, info.versionName ?: "Unknown")
            } else null
        } catch (_: Exception) {
            null
        } finally {
            if (tempApk.exists()) tempApk.delete()
        }
    }

    private data class NestedApkScanResult(
        val libs: List<NativeLibEntry>,
        val hasAssets: Boolean,
        val bytesConsumed: Long
    )

    private fun scanNestedApkStream(
        parentStream: InputStream,
        nestedApkName: String
    ): NestedApkScanResult {
        val libs = mutableListOf<NativeLibEntry>()
        var hasAssets = false
        var bytesRead = 0L
        val countingStream = object : InputStream() {
            override fun read(): Int {
                val b = parentStream.read()
                if (b >= 0) bytesRead++
                return b
            }

            override fun read(b: ByteArray, off: Int, len: Int): Int {
                val n = parentStream.read(b, off, len)
                if (n > 0) bytesRead += n
                return n
            }

            override fun close() { /* Do not close outer ZipInputStream */ }
        }
        try {
            val nestedZip = ZipInputStream(countingStream)
            var entry = nestedZip.nextEntry
            while (entry != null) {
                val name = entry.name
                if (!entry.isDirectory) {
                    if (name.startsWith("assets/")) hasAssets = true
                    if (name.startsWith("lib/") && name.endsWith("/libminecraftpe.so")) {
                        val abi = name.split("/").getOrNull(1) ?: "unknown"
                        val header = ByteArray(24)
                        val readCount = nestedZip.read(header)
                        val elfArch = if (readCount >= 20) inspectElfHeader(header) else ""
                        libs.add(
                            NativeLibEntry(
                                abi = abi,
                                entryPath = name,
                                compressedSize = entry.compressedSize.coerceAtLeast(0L),
                                uncompressedSize = entry.size.coerceAtLeast(0L),
                                sourceApkName = nestedApkName,
                                elfArchLabel = elfArch,
                                isStoredUncompressed = entry.method == ZipEntry.STORED
                            )
                        )
                    }
                }
                nestedZip.closeEntry()
                entry = nestedZip.nextEntry
            }
            // Drain any trailing central directory bytes of the nested APK to measure full size
            val buf = ByteArray(8192)
            while (countingStream.read(buf, 0, buf.size) > 0) {
                // countingStream updates bytesRead
            }
        } catch (_: Exception) {
            // Nested entry could not be parsed cleanly
        }
        return NestedApkScanResult(libs, hasAssets, bytesRead)
    }

    fun inspectElfHeader(bytes: ByteArray): String {
        if (bytes.size < 20) return "Unknown Binary"
        val isElf = bytes[0] == 0x7F.toByte() &&
            bytes[1] == 'E'.code.toByte() &&
            bytes[2] == 'L'.code.toByte() &&
            bytes[3] == 'F'.code.toByte()
        if (!isElf) return "Non-ELF"
        val eiClass = bytes[4].toInt() and 0xFF
        val bitness = when (eiClass) {
            1 -> "ELF32"
            2 -> "ELF64"
            else -> "ELF?"
        }
        val machine = ((bytes[19].toInt() and 0xFF) shl 8) or (bytes[18].toInt() and 0xFF)
        val archName = when (machine) {
            183 -> "AArch64 (arm64-v8a)"
            40 -> "ARM (armeabi-v7a)"
            62 -> "x86-64"
            3 -> "x86"
            else -> "Machine#$machine"
        }
        return "$bitness $archName"
    }

    private fun expectedElfForAbi(abi: String): String = when (abi) {
        "arm64-v8a" -> "ELF64 AArch64 (arm64-v8a)"
        "armeabi-v7a" -> "ELF32 ARM (armeabi-v7a)"
        "x86_64" -> "ELF64 x86-64"
        "x86" -> "ELF32 x86"
        else -> abi
    }

    private fun buildCacheIndexPayload(
        profileId: String,
        abi: String,
        sourceSummary: String,
        elfArch: String,
        realSizeBytes: Long = 0L
    ): ByteArray {
        return buildString {
            append("LEVI_CACHE_INDEX_V3\n")
            append("profile=$profileId\n")
            append("abi=$abi\n")
            append("library=libminecraftpe.so\n")
            append("status=VERIFIED\n")
            append("source=$sourceSummary\n")
            append("elf_arch=$elfArch\n")
            append("real_size_bytes=$realSizeBytes\n")
            append("repaired_at=${System.currentTimeMillis()}\n")
        }.toByteArray()
    }

    private fun parseCacheMetadata(bytes: ByteArray): Map<String, String> {
        val text = bytes.decodeToString()
        val map = mutableMapOf<String, String>()
        text.lineSequence().forEach { line ->
            val eqIdx = line.indexOf('=')
            if (eqIdx > 0) {
                val key = line.substring(0, eqIdx).trim()
                val value = line.substring(eqIdx + 1).trim()
                map[key] = value
            }
        }
        return map
    }

    private fun resolveFileName(uri: Uri): String {
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (nameIdx >= 0 && cursor.moveToFirst()) {
                return cursor.getString(nameIdx) ?: "selected_package.apk"
            }
        }
        return uri.lastPathSegment ?: "selected_package.apk"
    }

    private fun resolveFileSize(uri: Uri): Long {
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
            if (sizeIdx >= 0 && cursor.moveToFirst()) {
                return cursor.getLong(sizeIdx)
            }
        }
        return 0L
    }

    private fun computeSha256Short(bytes: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(bytes)
        return digest.take(6).joinToString("") { "%02x".format(it) }
    }
}
