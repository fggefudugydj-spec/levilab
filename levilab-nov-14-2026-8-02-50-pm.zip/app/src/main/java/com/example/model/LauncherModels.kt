package com.example.model

enum class AppLanguage(val code: String, val label: String) {
    EN("en", "English"),
    AR("ar", "العربية")
}

enum class CacheHealthStatus {
    VERIFIED,
    MISSING_LIB,
    ABI_MISMATCH,
    STALE_INDEX
}

enum class ProfileSourceType {
    INTERNAL_CACHE,
    APK_IMPORT,
    SPLIT_APKS,
    INSTALLED_PACKAGE
}

data class GameProfile(
    val id: String,
    val displayName: String,
    val versionName: String,
    val packageName: String,
    val targetAbi: String,
    val cacheStatus: CacheHealthStatus,
    val cachePath: String,
    val cachedLibSizeBytes: Long,
    val cachedLibSha256: String,
    val sourceType: ProfileSourceType,
    val availableCachedAbis: List<String> = emptyList(),
    val isInstalledOnDevice: Boolean = false,
    val installedVersionName: String? = null,
    val cacheSourceSummary: String = "",
    val elfArchLabel: String = ""
)

data class InstalledMinecraftInfo(
    val packageName: String,
    val versionName: String,
    val versionCode: Long,
    val nativeLibraryDir: String,
    val hasNativeLibInSystemDir: Boolean,
    val extractNativeLibsEnabled: Boolean = true,
    val embeddedNativeLibs: List<NativeLibEntry> = emptyList(),
    val splitNames: List<String>,
    val sourceDir: String
)

data class DeviceTelemetry(
    val deviceModel: String,
    val androidVersion: String,
    val sdkInt: Int,
    val supportedAbis: List<String>,
    val primaryAbi: String,
    val installedMinecraftPackage: InstalledMinecraftInfo?,
    val installedEditions: List<InstalledMinecraftInfo> = emptyList()
)

enum class SplitCategory {
    BASE_APK,
    NATIVE_ABI,
    RESOURCE_DENSITY,
    LANGUAGE,
    FEATURE_MODULE,
    OTHER
}

data class InstalledSplitFragment(
    val splitName: String,
    val category: SplitCategory,
    val sourcePath: String,
    val sizeBytes: Long,
    val existsOnDisk: Boolean
)

data class InstalledPackageSplitsReport(
    val packageName: String,
    val versionName: String,
    val isInstalled: Boolean,
    val baseApkPath: String,
    val baseApkSizeBytes: Long,
    val splitFragments: List<InstalledSplitFragment>,
    val resourceAndLanguageSplits: List<InstalledSplitFragment>,
    val resourceAndLanguageTotalBytes: Long,
    val totalPackageDiskBytes: Long
)

data class NativeLibEntry(
    val abi: String,
    val entryPath: String,
    val compressedSize: Long,
    val uncompressedSize: Long,
    val sourceApkName: String,
    val elfArchLabel: String = "",
    val isStoredUncompressed: Boolean = false
)

data class ApkInspectionResult(
    val fileName: String,
    val fileSizeBytes: Long,
    val archivePackageName: String? = null,
    val archiveVersionName: String? = null,
    val isSplitArchive: Boolean,
    val splitApkNames: List<String>,
    val splitFragments: List<InstalledSplitFragment> = emptyList(),
    val resourceAndLanguageTotalBytes: Long = 0L,
    val totalArchiveSplitBytes: Long = 0L,
    val foundNativeLibs: List<NativeLibEntry>,
    val hasAssetsFolder: Boolean,
    val compatibleWithDevice: Boolean,
    val missingPrimaryAbi: Boolean,
    val diagnosisSummaryEn: String,
    val diagnosisSummaryAr: String
)

enum class ModType {
    NATIVE_SO,
    RESOURCE_PACK,
    BEHAVIOR_PACK
}

data class ModItem(
    val id: String,
    val name: String,
    val author: String,
    val version: String,
    val type: ModType,
    val requiredAbi: String,
    val enabled: Boolean,
    val loadOrder: Int,
    val descriptionEn: String,
    val descriptionAr: String
)

enum class PreflightStage {
    PACKAGE_CHECK,
    ABI_MATCH,
    LIB_CACHE,
    MOD_VALIDATION,
    LAUNCH_HANDOFF
}

enum class StageState {
    PENDING,
    RUNNING,
    PASSED,
    FAILED,
    FIXED
}

data class PreflightStep(
    val stage: PreflightStage,
    val state: StageState,
    val detail: String = ""
)

enum class LogLevel {
    INFO,
    WARN,
    ERROR,
    FIX,
    SUCCESS
}

data class LaunchLogEntry(
    val id: Long,
    val timestamp: String,
    val level: LogLevel,
    val message: String
)

sealed class FailureReason {
    data class MissingMinecraftPeLib(
        val expectedPath: String,
        val expectedAbi: String,
        val availableAbisInCache: List<String>,
        val splitHint: Boolean
    ) : FailureReason()

    data class AbiMismatch(
        val deviceAbi: String,
        val cachedAbi: String
    ) : FailureReason()

    data class ModConflict(
        val conflictingMods: List<String>,
        val targetAbi: String
    ) : FailureReason()
}

data class LaunchSessionState(
    val isRunning: Boolean = false,
    val progress: Float = 0f,
    val steps: List<PreflightStep> = emptyList(),
    val logs: List<LaunchLogEntry> = emptyList(),
    val failedReason: FailureReason? = null,
    val succeeded: Boolean = false,
    val elapsedMs: Long = 0L,
    val targetPackageName: String = "com.mojang.minecrafttrialpe",
    val launchedPackageName: String? = null,
    val targetPackageMissingOnDevice: Boolean = false
)

data class RootCauseGuideItem(
    val id: String,
    val titleEn: String,
    val titleAr: String,
    val symptomEn: String,
    val symptomAr: String,
    val solutionEn: String,
    val solutionAr: String,
    val severityTag: String
)
