package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Launch
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.FolderZip
import androidx.compose.material.icons.outlined.Healing
import androidx.compose.material.icons.rounded.Build
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.HourglassTop
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Shop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.AppLanguage
import com.example.model.FailureReason
import com.example.model.LogLevel
import com.example.model.PreflightStage
import com.example.model.StageState
import com.example.ui.LeviStrings
import com.example.ui.LeviUiState
import com.example.ui.components.LeviLeafMark
import com.example.ui.theme.JetBrainsMonoFamily

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun LaunchConsoleScreen(
    uiState: LeviUiState,
    strings: LeviStrings,
    onBackToLauncher: () -> Unit,
    onAutoRepairAndRetry: () -> Unit,
    onOpenDiagnostics: () -> Unit,
    onInspectArchiveUri: (Uri) -> Unit,
    onOpenInstalledGame: (String) -> Unit,
    onOpenPlayStore: (String) -> Unit,
    onShowCopiedFeedback: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBackToLauncher)

    val session = uiState.launchSession
    val context = LocalContext.current
    val logListState = rememberLazyListState()

    val archivePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            onInspectArchiveUri(uri)
        }
    }

    LaunchedEffect(session.logs.size) {
        if (session.logs.isNotEmpty()) {
            logListState.animateScrollToItem(session.logs.lastIndex)
        }
    }

    val animatedProgress by animateFloatAsState(
        targetValue = session.progress,
        animationSpec = spring(),
        label = "preflight_progress"
    )

    val statusHeadline = when {
        session.isRunning -> strings.launchStartingTitle
        session.failedReason != null -> strings.launchFailedTitle
        session.succeeded -> strings.launchSuccessTitle
        else -> strings.launchStartingTitle
    }

    val barColor = when {
        session.failedReason != null -> MaterialTheme.colorScheme.error
        session.succeeded -> MaterialTheme.colorScheme.primary
        else -> MaterialTheme.colorScheme.primary
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 760.dp),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 18.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Top Header matching LeviLauncher's signature layout + leaf emblem
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = strings.launchStartingTitle,
                            style = MaterialTheme.typography.displaySmall,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = strings.launchStartingSubtitle,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Spacer(Modifier.width(12.dp))
                    LeviLeafMark(size = 46.dp)
                }
            }

            // Status Headline + Animated Progress Bar
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = statusHeadline,
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (session.failedReason != null) {
                                MaterialTheme.colorScheme.error
                            } else {
                                MaterialTheme.colorScheme.onBackground
                            }
                        )
                        if (session.elapsedMs > 0L) {
                            Text(
                                text = "${session.elapsedMs} ms",
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = JetBrainsMonoFamily,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    LinearProgressIndicator(
                        progress = { animatedProgress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(50)),
                        color = barColor,
                        trackColor = MaterialTheme.colorScheme.surfaceContainerHigh
                    )

                    // 5-Stage Preflight Stepper Chips
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        session.steps.forEach { step ->
                            val stageLabel = when (step.stage) {
                                PreflightStage.PACKAGE_CHECK -> strings.stagePackageCheck
                                PreflightStage.ABI_MATCH -> strings.stageAbiMatch
                                PreflightStage.LIB_CACHE -> strings.stageLibCache
                                PreflightStage.MOD_VALIDATION -> strings.stageModValidation
                                PreflightStage.LAUNCH_HANDOFF -> strings.stageLaunchHandoff
                            }
                            val (bg, fg, icon) = when (step.state) {
                                StageState.PASSED, StageState.FIXED -> Triple(
                                    MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.65f),
                                    MaterialTheme.colorScheme.onPrimaryContainer,
                                    Icons.Rounded.CheckCircle
                                )
                                StageState.FAILED -> Triple(
                                    MaterialTheme.colorScheme.errorContainer,
                                    MaterialTheme.colorScheme.onErrorContainer,
                                    Icons.Rounded.ErrorOutline
                                )
                                StageState.RUNNING -> Triple(
                                    MaterialTheme.colorScheme.secondaryContainer,
                                    MaterialTheme.colorScheme.onSecondaryContainer,
                                    Icons.Rounded.HourglassTop
                                )
                                StageState.PENDING -> Triple(
                                    MaterialTheme.colorScheme.surfaceContainer,
                                    MaterialTheme.colorScheme.onSurfaceVariant,
                                    Icons.Rounded.HourglassTop
                                )
                            }
                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(bg)
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(5.dp)
                            ) {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = null,
                                    tint = fg,
                                    modifier = Modifier.size(14.dp)
                                )
                                Text(
                                    text = stageLabel,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = fg
                                )
                            }
                        }
                    }
                }
            }

            // Launch Log Terminal Box
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = strings.launchLogTitle,
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        IconButton(
                            onClick = {
                                val text = session.logs.joinToString("\n") {
                                    "[${it.timestamp}] ${it.message}"
                                }
                                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                cm.setPrimaryClip(ClipData.newPlainText("LeviLab Launch Log", text))
                                onShowCopiedFeedback(strings.logCopiedToast)
                            },
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("copy_log_button")
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.ContentCopy,
                                contentDescription = strings.copyLogCta,
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    val cursorTransition = rememberInfiniteTransition(label = "terminal_cursor")
                    val cursorAlpha by cursorTransition.animateFloat(
                        initialValue = 1f,
                        targetValue = 0.15f,
                        animationSpec = infiniteRepeatable(
                            animation = tween(durationMillis = 550),
                            repeatMode = RepeatMode.Reverse
                        ),
                        label = "cursor_alpha"
                    )

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(185.dp)
                            .clip(MaterialTheme.shapes.medium)
                            .background(MaterialTheme.colorScheme.surfaceContainerLowest)
                            .border(
                                1.5.dp,
                                if (session.failedReason != null) MaterialTheme.colorScheme.error.copy(alpha = 0.65f)
                                else MaterialTheme.colorScheme.outline,
                                MaterialTheme.shapes.medium
                            )
                            .padding(14.dp)
                    ) {
                        LazyColumn(
                            state = logListState,
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            items(session.logs, key = { it.id }) { entry ->
                                val lineColor = when (entry.level) {
                                    LogLevel.ERROR -> MaterialTheme.colorScheme.error
                                    LogLevel.WARN -> MaterialTheme.colorScheme.tertiary
                                    LogLevel.SUCCESS, LogLevel.FIX -> MaterialTheme.colorScheme.secondary
                                    LogLevel.INFO -> MaterialTheme.colorScheme.onSurface
                                }
                                Text(
                                    text = "[${entry.timestamp}] ${entry.message}",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontFamily = JetBrainsMonoFamily,
                                    color = lineColor
                                )
                            }
                            item(key = "terminal_cursor") {
                                Box(
                                    modifier = Modifier
                                        .padding(top = 2.dp)
                                        .size(width = 7.dp, height = 14.dp)
                                        .background(
                                            MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = cursorAlpha)
                                        )
                                )
                            }
                        }
                    }
                }
            }

            // Smart Failure Recovery Card (shown immediately when libminecraftpe.so is missing or ABI conflicts)
            item {
                val failure = session.failedReason
                AnimatedVisibility(visible = failure != null) {
                    if (failure != null) {
                        val isAr = uiState.language == AppLanguage.AR
                        Card(
                            shape = MaterialTheme.shapes.medium,
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceContainer
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(
                                    1.dp,
                                    MaterialTheme.colorScheme.error.copy(alpha = 0.55f),
                                    MaterialTheme.shapes.medium
                                )
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text(
                                    text = strings.recoveryBannerTitle,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.error
                                )

                                val detailMessage = when (failure) {
                                    is FailureReason.MissingMinecraftPeLib -> {
                                        if (isAr) {
                                            "لم يتم العثور على libminecraftpe.so لمعمارية ${failure.expectedAbi} في الكاش. " +
                                                if (failure.availableAbisInCache.isNotEmpty()) {
                                                    "تم العثور فقط على: ${failure.availableAbisInCache.joinToString()} (مشكلة حزمة Split APK أو تعارض معمارية)."
                                                } else {
                                                    "مجلد الكاش فارغ أو لم يتم استخراج المكتبة منه."
                                                }
                                        } else {
                                            "libminecraftpe.so for ${failure.expectedAbi} is missing from the cache. " +
                                                if (failure.availableAbisInCache.isNotEmpty()) {
                                                    "Only [${failure.availableAbisInCache.joinToString()}] found on disk (Split-APK or ABI mismatch)."
                                                } else {
                                                    "Cache directory is empty or unextracted."
                                                }
                                        }
                                    }
                                    is FailureReason.AbiMismatch -> {
                                        if (isAr) {
                                            "المعمارية المختارة (${failure.cachedAbi}) لا يدعمها جهازك (${failure.deviceAbi})."
                                        } else {
                                            "Selected ABI (${failure.cachedAbi}) is not supported on this device (${failure.deviceAbi})."
                                        }
                                    }
                                    is FailureReason.ModConflict -> {
                                        if (isAr) {
                                            "تعارض في معمارية المودات: ${failure.conflictingMods.joinToString()} مع ${failure.targetAbi}."
                                        } else {
                                            "Mod ABI conflict for ${failure.conflictingMods.joinToString()} on ${failure.targetAbi}."
                                        }
                                    }
                                }

                                Text(
                                    text = detailMessage,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Button(
                                        onClick = onAutoRepairAndRetry,
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(48.dp)
                                            .testTag("auto_repair_retry_button"),
                                        shape = MaterialTheme.shapes.small
                                    ) {
                                        Icon(Icons.Outlined.Healing, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text(strings.autoRepairAndRetryCta, maxLines = 1)
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    OutlinedButton(
                                        onClick = {
                                            archivePickerLauncher.launch(arrayOf("*/*"))
                                        },
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(48.dp),
                                        shape = MaterialTheme.shapes.small
                                    ) {
                                        Icon(Icons.Outlined.FolderZip, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text(strings.inspectApkCta, maxLines = 1)
                                    }

                                    OutlinedButton(
                                        onClick = onOpenDiagnostics,
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(48.dp)
                                            .testTag("launch_open_diagnostics_button"),
                                        shape = MaterialTheme.shapes.small
                                    ) {
                                        Icon(Icons.Rounded.Build, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text(strings.openDiagnosticsCta, maxLines = 1)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Launch Handoff or Official Play Store Trial Install Card when preflight succeeded
            item {
                AnimatedVisibility(visible = session.succeeded && session.failedReason == null) {
                    Card(
                        shape = MaterialTheme.shapes.medium,
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceContainer
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                1.dp,
                                MaterialTheme.colorScheme.primary.copy(alpha = 0.65f),
                                MaterialTheme.shapes.medium
                            )
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            if (session.launchedPackageName != null) {
                                Text(
                                    text = "${strings.launchSuccessTitle} • ${session.launchedPackageName}",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Button(
                                    onClick = { onOpenInstalledGame(session.launchedPackageName) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(48.dp)
                                        .testTag("open_installed_game_button"),
                                    shape = MaterialTheme.shapes.small
                                ) {
                                    Icon(Icons.Rounded.PlayArrow, contentDescription = null, modifier = Modifier.size(20.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text(strings.openInstalledGameCta)
                                }
                            } else if (session.targetPackageMissingOnDevice) {
                                Text(
                                    text = strings.packageNotInstalledBannerTitle,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                                Text(
                                    text = strings.packageNotInstalledBannerBody,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Button(
                                    onClick = { onOpenPlayStore(session.targetPackageName) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(48.dp)
                                        .testTag("open_play_store_trial_button"),
                                    shape = MaterialTheme.shapes.small
                                ) {
                                    Icon(Icons.Rounded.Shop, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text(strings.openOnPlayStoreCta)
                                }
                                OutlinedButton(
                                    onClick = { archivePickerLauncher.launch(arrayOf("*/*")) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(48.dp),
                                    shape = MaterialTheme.shapes.small
                                ) {
                                    Icon(Icons.AutoMirrored.Rounded.Launch, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text(strings.inspectApkCta)
                                }
                            }
                        }
                    }
                }
            }

            // Back to Launcher primary action (matches original screenshot placement)
            item {
                Button(
                    onClick = onBackToLauncher,
                    modifier = Modifier
                        .height(50.dp)
                        .testTag("back_to_launcher_button"),
                    shape = MaterialTheme.shapes.medium,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    )
                ) {
                    Text(
                        text = strings.backToLauncherCta,
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            }
        }
    }
}
