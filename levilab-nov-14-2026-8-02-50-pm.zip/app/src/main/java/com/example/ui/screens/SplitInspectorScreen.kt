package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.FolderZip
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.outlined.PhotoSizeSelectLarge
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.SdStorage
import androidx.compose.material.icons.rounded.Inventory2
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.model.AppLanguage
import com.example.model.InstalledSplitFragment
import com.example.model.SplitCategory
import com.example.ui.LeviStrings
import com.example.ui.LeviUiState
import com.example.ui.components.StatusPill
import com.example.ui.theme.JetBrainsMonoFamily
import java.util.Locale

private enum class SplitSourceMode {
    INSTALLED_PACKAGE,
    INSPECTED_BUNDLE
}

private enum class SplitFilterOption {
    RESOURCE_AND_LANGUAGE,
    ALL,
    RESOURCES_ONLY,
    LANGUAGES_ONLY,
    NATIVE_ABI_ONLY
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SplitInspectorScreen(
    uiState: LeviUiState,
    strings: LeviStrings,
    onRefreshInstalledSplits: (String?) -> Unit,
    onInspectArchiveUri: (Uri) -> Unit,
    modifier: Modifier = Modifier
) {
    val archivePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            onInspectArchiveUri(uri)
        }
    }

    val installedReport = uiState.installedSplitsReport
    val inspectedBundle = uiState.apkInspectionResult

    var sourceMode by remember(installedReport?.isInstalled, inspectedBundle?.fileName) {
        mutableStateOf(
            if (installedReport?.isInstalled != true && inspectedBundle?.splitFragments?.isNotEmpty() == true) {
                SplitSourceMode.INSPECTED_BUNDLE
            } else {
                SplitSourceMode.INSTALLED_PACKAGE
            }
        )
    }

    var activeFilter by remember { mutableStateOf(SplitFilterOption.RESOURCE_AND_LANGUAGE) }

    val activeFragments: List<InstalledSplitFragment> = remember(
        sourceMode, installedReport, inspectedBundle
    ) {
        when (sourceMode) {
            SplitSourceMode.INSTALLED_PACKAGE -> installedReport?.splitFragments.orEmpty()
            SplitSourceMode.INSPECTED_BUNDLE -> inspectedBundle?.splitFragments.orEmpty()
        }
    }

    val filteredFragments = remember(activeFragments, activeFilter) {
        when (activeFilter) {
            SplitFilterOption.RESOURCE_AND_LANGUAGE -> activeFragments.filter {
                it.category == SplitCategory.RESOURCE_DENSITY || it.category == SplitCategory.LANGUAGE
            }
            SplitFilterOption.ALL -> activeFragments
            SplitFilterOption.RESOURCES_ONLY -> activeFragments.filter {
                it.category == SplitCategory.RESOURCE_DENSITY
            }
            SplitFilterOption.LANGUAGES_ONLY -> activeFragments.filter {
                it.category == SplitCategory.LANGUAGE
            }
            SplitFilterOption.NATIVE_ABI_ONLY -> activeFragments.filter {
                it.category == SplitCategory.NATIVE_ABI
            }
        }
    }

    val resourceBytes = activeFragments
        .filter { it.category == SplitCategory.RESOURCE_DENSITY }
        .sumOf { it.sizeBytes }
    val languageBytes = activeFragments
        .filter { it.category == SplitCategory.LANGUAGE }
        .sumOf { it.sizeBytes }
    val nativeBytes = activeFragments
        .filter { it.category == SplitCategory.NATIVE_ABI }
        .sumOf { it.sizeBytes }
    val baseBytes = when (sourceMode) {
        SplitSourceMode.INSTALLED_PACKAGE -> installedReport?.baseApkSizeBytes ?: 0L
        SplitSourceMode.INSPECTED_BUNDLE -> activeFragments
            .filter { it.category == SplitCategory.BASE_APK }
            .sumOf { it.sizeBytes }
    }
    val resAndLangTotalBytes = resourceBytes + languageBytes
    val totalDiskBytes = when (sourceMode) {
        SplitSourceMode.INSTALLED_PACKAGE -> installedReport?.totalPackageDiskBytes ?: 0L
        SplitSourceMode.INSPECTED_BUNDLE -> inspectedBundle?.totalArchiveSplitBytes ?: 0L
    }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 720.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = strings.splitsTitle,
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = strings.splitsSubtitle,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Action Bar: Rescan Package + Inspect .APKS/.XAPK Bundle
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = { onRefreshInstalledSplits(installedReport?.packageName) },
                        enabled = !uiState.isScanningSplits,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("refresh_splits_button"),
                        shape = MaterialTheme.shapes.medium
                    ) {
                        if (uiState.isScanningSplits) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                strokeWidth = 2.dp,
                                color = MaterialTheme.colorScheme.onPrimary
                            )
                        } else {
                            Icon(Icons.Outlined.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                        }
                        Spacer(Modifier.width(6.dp))
                        Text(strings.refreshSplitsCta, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }

                    OutlinedButton(
                        onClick = {
                            archivePickerLauncher.launch(
                                arrayOf(
                                    "application/vnd.android.package-archive",
                                    "application/zip",
                                    "application/octet-stream",
                                    "*/*"
                                )
                            )
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("splits_pick_bundle_button"),
                        shape = MaterialTheme.shapes.medium
                    ) {
                        Icon(Icons.Outlined.FolderZip, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(strings.inspectApkCta, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }

            val installedEditions = uiState.telemetry?.installedEditions.orEmpty()
            if (installedEditions.size > 1) {
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = strings.editionSelectorLabel,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            installedEditions.forEach { edition ->
                                FilterChip(
                                    selected = installedReport?.packageName == edition.packageName &&
                                        sourceMode == SplitSourceMode.INSTALLED_PACKAGE,
                                    onClick = {
                                        sourceMode = SplitSourceMode.INSTALLED_PACKAGE
                                        onRefreshInstalledSplits(edition.packageName)
                                    },
                                    label = {
                                        Text(
                                            text = "${edition.packageName} (${edition.versionName})",
                                            fontFamily = JetBrainsMonoFamily
                                        )
                                    }
                                )
                            }
                        }
                    }
                }
            }

            // Source Switcher when a bundle has also been inspected
            if (inspectedBundle != null && inspectedBundle.splitFragments.isNotEmpty()) {
                item {
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = sourceMode == SplitSourceMode.INSTALLED_PACKAGE,
                            onClick = { sourceMode = SplitSourceMode.INSTALLED_PACKAGE },
                            modifier = Modifier.testTag("split_source_installed"),
                            label = { Text(strings.installedSourceLabel) }
                        )
                        FilterChip(
                            selected = sourceMode == SplitSourceMode.INSPECTED_BUNDLE,
                            onClick = { sourceMode = SplitSourceMode.INSPECTED_BUNDLE },
                            modifier = Modifier.testTag("split_source_bundle"),
                            label = {
                                Text(
                                    text = "${strings.bundleSourceLabel}: ${inspectedBundle.fileName}",
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        )
                    }
                }
            }

            // Disk Usage Summary Card
            val hasSourceData = (sourceMode == SplitSourceMode.INSTALLED_PACKAGE && installedReport?.isInstalled == true) ||
                (sourceMode == SplitSourceMode.INSPECTED_BUNDLE && inspectedBundle?.splitFragments?.isNotEmpty() == true)

            if (!hasSourceData) {
                item {
                    Card(
                        shape = MaterialTheme.shapes.medium,
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, MaterialTheme.shapes.medium)
                    ) {
                        Column(
                            modifier = Modifier.padding(20.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Inventory2,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.tertiary
                                )
                                Text(
                                    text = strings.noInstalledMinecraftSplitsTitle,
                                    style = MaterialTheme.typography.titleMedium
                                )
                            }
                            Text(
                                text = strings.noInstalledMinecraftSplitsBody,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            } else {
                item {
                    Card(
                        shape = MaterialTheme.shapes.large,
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, MaterialTheme.colorScheme.outline, MaterialTheme.shapes.large)
                    ) {
                        Column(
                            modifier = Modifier.padding(18.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.Top
                            ) {
                                Column(
                                    modifier = Modifier.weight(1f),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text(
                                        text = strings.resAndLangTotalLabel,
                                        style = MaterialTheme.typography.labelLarge,
                                        color = MaterialTheme.colorScheme.secondary
                                    )
                                    Text(
                                        text = formatDiskBytes(resAndLangTotalBytes),
                                        style = MaterialTheme.typography.displaySmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Text(
                                        text = if (sourceMode == SplitSourceMode.INSTALLED_PACKAGE && installedReport != null) {
                                            "${installedReport.packageName} • v${installedReport.versionName}"
                                        } else {
                                            inspectedBundle?.fileName.orEmpty()
                                        },
                                        style = MaterialTheme.typography.labelSmall,
                                        fontFamily = JetBrainsMonoFamily,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = strings.totalPackageDiskLabel,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = formatDiskBytes(totalDiskBytes),
                                        style = MaterialTheme.typography.titleLarge,
                                        fontFamily = JetBrainsMonoFamily,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }

                            // Segmented Proportional Disk Bar
                            if (totalDiskBytes > 0L) {
                                val resWeight = (resourceBytes.toFloat() / totalDiskBytes).coerceAtLeast(0f)
                                val langWeight = (languageBytes.toFloat() / totalDiskBytes).coerceAtLeast(0f)
                                val nativeWeight = (nativeBytes.toFloat() / totalDiskBytes).coerceAtLeast(0f)
                                val baseWeight = (1f - resWeight - langWeight - nativeWeight).coerceAtLeast(0.02f)

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(10.dp)
                                        .clip(RoundedCornerShape(50))
                                        .background(MaterialTheme.colorScheme.surfaceContainerHigh),
                                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                                ) {
                                    if (resWeight > 0.005f) {
                                        Box(
                                            modifier = Modifier
                                                .weight(resWeight)
                                                .height(10.dp)
                                                .background(MaterialTheme.colorScheme.primary)
                                        )
                                    }
                                    if (langWeight > 0.005f) {
                                        Box(
                                            modifier = Modifier
                                                .weight(langWeight)
                                                .height(10.dp)
                                                .background(MaterialTheme.colorScheme.secondary)
                                        )
                                    }
                                    if (nativeWeight > 0.005f) {
                                        Box(
                                            modifier = Modifier
                                                .weight(nativeWeight)
                                                .height(10.dp)
                                                .background(MaterialTheme.colorScheme.tertiary)
                                        )
                                    }
                                    Box(
                                        modifier = Modifier
                                            .weight(baseWeight)
                                            .height(10.dp)
                                            .background(MaterialTheme.colorScheme.outline)
                                    )
                                }
                            }

                            // 4-cell breakdown grid
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                DiskMetricPill(
                                    label = strings.resourceSplitsLabel,
                                    value = formatDiskBytes(resourceBytes),
                                    accentColor = MaterialTheme.colorScheme.primary
                                )
                                DiskMetricPill(
                                    label = strings.languageSplitsLabel,
                                    value = formatDiskBytes(languageBytes),
                                    accentColor = MaterialTheme.colorScheme.secondary
                                )
                                DiskMetricPill(
                                    label = strings.nativeSplitsLabel,
                                    value = formatDiskBytes(nativeBytes),
                                    accentColor = MaterialTheme.colorScheme.tertiary
                                )
                                DiskMetricPill(
                                    label = strings.baseApkLabel,
                                    value = formatDiskBytes(baseBytes),
                                    accentColor = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                // Category Filter Chips
                item {
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val filters = listOf(
                            SplitFilterOption.RESOURCE_AND_LANGUAGE to strings.filterResAndLang,
                            SplitFilterOption.ALL to strings.filterAllSplits,
                            SplitFilterOption.RESOURCES_ONLY to strings.filterResources,
                            SplitFilterOption.LANGUAGES_ONLY to strings.filterLanguages,
                            SplitFilterOption.NATIVE_ABI_ONLY to strings.filterNativeAbi
                        )
                        filters.forEach { (option, label) ->
                            FilterChip(
                                selected = activeFilter == option,
                                onClick = { activeFilter = option },
                                modifier = Modifier.testTag("split_filter_${option.name.lowercase()}"),
                                label = { Text(label) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                    selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            )
                        }
                    }
                }

                if (filteredFragments.isEmpty()) {
                    item {
                        Card(
                            shape = MaterialTheme.shapes.medium,
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, MaterialTheme.shapes.medium)
                        ) {
                            Text(
                                text = if (uiState.language == AppLanguage.AR) {
                                    "لا توجد حزم تقسيم مطابقة لهذا الفلتر."
                                } else {
                                    "No split fragments match the selected category filter."
                                },
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(16.dp)
                            )
                        }
                    }
                } else {
                    items(filteredFragments, key = { "${it.splitName}_${it.sourcePath}" }) { fragment ->
                        SplitFragmentCard(
                            fragment = fragment,
                            language = uiState.language
                        )
                    }
                }
            }

            item { Spacer(Modifier.height(12.dp)) }
        }
    }
}

@Composable
private fun DiskMetricPill(
    label: String,
    value: String,
    accentColor: androidx.compose.ui.graphics.Color
) {
    Row(
        modifier = Modifier
            .clip(MaterialTheme.shapes.small)
            .background(MaterialTheme.colorScheme.surfaceContainerLowest)
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, MaterialTheme.shapes.small)
            .padding(horizontal = 10.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(RoundedCornerShape(50))
                .background(accentColor)
        )
        Text(
            text = "$label: ",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.labelSmall,
            fontFamily = JetBrainsMonoFamily,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
private fun SplitFragmentCard(
    fragment: InstalledSplitFragment,
    language: AppLanguage
) {
    val (categoryLabel, categoryIcon, pillBg, pillFg) = when (fragment.category) {
        SplitCategory.RESOURCE_DENSITY -> Quad(
            if (language == AppLanguage.AR) "موارد (DPI)" else "RESOURCE",
            Icons.Outlined.PhotoSizeSelectLarge,
            MaterialTheme.colorScheme.primaryContainer,
            MaterialTheme.colorScheme.onPrimaryContainer
        )
        SplitCategory.LANGUAGE -> Quad(
            if (language == AppLanguage.AR) "لغة" else "LANGUAGE",
            Icons.Outlined.Language,
            MaterialTheme.colorScheme.secondaryContainer,
            MaterialTheme.colorScheme.onSecondaryContainer
        )
        SplitCategory.NATIVE_ABI -> Quad(
            "NATIVE ABI",
            Icons.Outlined.Memory,
            MaterialTheme.colorScheme.tertiaryContainer,
            MaterialTheme.colorScheme.onTertiaryContainer
        )
        else -> Quad(
            fragment.category.name,
            Icons.Outlined.SdStorage,
            MaterialTheme.colorScheme.surfaceContainerHigh,
            MaterialTheme.colorScheme.onSurface
        )
    }

    Card(
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, MaterialTheme.shapes.medium)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(MaterialTheme.shapes.small)
                            .background(pillBg),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = categoryIcon,
                            contentDescription = null,
                            tint = pillFg,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = fragment.splitName,
                            style = MaterialTheme.typography.titleSmall,
                            fontFamily = JetBrainsMonoFamily,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        StatusPill(
                            text = categoryLabel,
                            containerColor = pillBg,
                            contentColor = pillFg,
                            leadingDot = false,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
                Spacer(Modifier.width(8.dp))
                Text(
                    text = formatDiskBytes(fragment.sizeBytes),
                    style = MaterialTheme.typography.titleMedium,
                    fontFamily = JetBrainsMonoFamily,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            if (fragment.sourcePath.isNotBlank()) {
                Text(
                    text = fragment.sourcePath,
                    style = MaterialTheme.typography.labelSmall,
                    fontFamily = JetBrainsMonoFamily,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

private data class Quad<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)

fun formatDiskBytes(bytes: Long): String {
    if (bytes <= 0L) return "0 B"
    val kb = bytes / 1024.0
    if (kb < 1024.0) return String.format(Locale.US, "%.1f KB", kb)
    val mb = kb / 1024.0
    if (mb < 1024.0) return String.format(Locale.US, "%.2f MB", mb)
    val gb = mb / 1024.0
    return String.format(Locale.US, "%.2f GB", gb)
}
