package com.example

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import androidx.test.core.app.ApplicationProvider
import com.example.data.AndroidTelemetryAndCacheManager
import com.example.model.CacheHealthStatus
import com.example.model.ProfileSourceType
import com.example.model.SplitCategory
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read app name string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("LeviLab", appName)
    }

    @Test
    fun `cache manager detects missing libminecraftpe and repairs it`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val manager = AndroidTelemetryAndCacheManager(context)

        manager.ensureDefaultPrototypeCacheInitialized("arm64-v8a")

        val brokenProfile = manager.inspectProfileCache(
            profileId = "bedrock_1_21_51",
            displayName = "Bedrock 1.21.51",
            versionName = "1.21.51.02",
            packageName = "com.mojang.minecraftpe",
            targetAbi = "arm64-v8a",
            deviceSupportedAbis = listOf("arm64-v8a", "armeabi-v7a"),
            sourceType = ProfileSourceType.SPLIT_APKS
        )
        assertEquals(CacheHealthStatus.ABI_MISMATCH, brokenProfile.cacheStatus)
        assertTrue(brokenProfile.availableCachedAbis.contains("armeabi-v7a"))

        val repaired = manager.repairProfileCache("bedrock_1_21_51", "arm64-v8a")
        assertTrue(repaired)

        val verifiedProfile = manager.inspectProfileCache(
            profileId = "bedrock_1_21_51",
            displayName = "Bedrock 1.21.51",
            versionName = "1.21.51.02",
            packageName = "com.mojang.minecraftpe",
            targetAbi = "arm64-v8a",
            deviceSupportedAbis = listOf("arm64-v8a", "armeabi-v7a"),
            sourceType = ProfileSourceType.SPLIT_APKS
        )
        assertEquals(CacheHealthStatus.VERIFIED, verifiedProfile.cacheStatus)
        assertTrue(verifiedProfile.cachedLibSizeBytes > 0L)
    }

    @Test
    fun `split inspector classifies resource and language splits and sums disk usage`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val manager = AndroidTelemetryAndCacheManager(context)

        assertEquals(SplitCategory.RESOURCE_DENSITY, manager.classifySplitApkName("split_config.xxhdpi"))
        assertEquals(SplitCategory.LANGUAGE, manager.classifySplitApkName("split_config.ar"))
        assertEquals(SplitCategory.LANGUAGE, manager.classifySplitApkName("config.pt_rBR"))
        assertEquals(SplitCategory.NATIVE_ABI, manager.classifySplitApkName("split_config.arm64_v8a"))

        val tempDir = File(context.cacheDir, "test_splits").apply { mkdirs() }
        val baseFile = File(tempDir, "base.apk").apply { writeBytes(ByteArray(1024)) }
        val resFile = File(tempDir, "split_config.xxhdpi.apk").apply { writeBytes(ByteArray(2048)) }
        val langFile = File(tempDir, "split_config.ar.apk").apply { writeBytes(ByteArray(512)) }
        val abiFile = File(tempDir, "split_config.arm64_v8a.apk").apply { writeBytes(ByteArray(4096)) }

        val pkgInfo = PackageInfo().apply {
            packageName = "com.mojang.minecraftpe"
            versionName = "1.21.51.02"
            applicationInfo = ApplicationInfo().apply {
                packageName = "com.mojang.minecraftpe"
                sourceDir = baseFile.absolutePath
                splitNames = arrayOf("config.xxhdpi", "config.ar", "config.arm64_v8a")
                splitSourceDirs = arrayOf(
                    resFile.absolutePath,
                    langFile.absolutePath,
                    abiFile.absolutePath
                )
            }
        }
        shadowOf(context.packageManager).installPackage(pkgInfo)

        val report = manager.inspectInstalledMinecraftSplits()
        assertTrue(report.isInstalled)
        assertEquals(3, report.splitFragments.size)
        assertEquals(2, report.resourceAndLanguageSplits.size)
        assertEquals(2048L + 512L, report.resourceAndLanguageTotalBytes)
        assertEquals(1024L + 2048L + 512L + 4096L, report.totalPackageDiskBytes)
    }

    @Test
    fun `telemetry detects installed bedrock trial and creates store intent`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val manager = AndroidTelemetryAndCacheManager(context)

        val trialPkg = PackageInfo().apply {
            packageName = "com.mojang.minecrafttrialpe"
            versionName = "1.21.60.21"
            applicationInfo = ApplicationInfo().apply {
                packageName = "com.mojang.minecrafttrialpe"
                sourceDir = "/data/app/trial/base.apk"
            }
        }
        shadowOf(context.packageManager).installPackage(trialPkg)

        val telemetry = manager.collectDeviceTelemetry()
        assertTrue(telemetry.installedEditions.any { it.packageName == "com.mojang.minecrafttrialpe" })
        assertEquals("1.21.60.21", telemetry.installedMinecraftPackage?.versionName)

        val storeIntent = manager.createStoreIntent("com.mojang.minecrafttrialpe")
        assertEquals(
            "https://play.google.com/store/apps/details?id=com.mojang.minecrafttrialpe",
            storeIntent.dataString
        )
    }

    @Test
    fun `telemetry probes extractNativeLibs false split apk and verifies ELF64 AArch64 header`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val manager = AndroidTelemetryAndCacheManager(context)

        val tempDir = File(context.cacheDir, "test_v126_beta").apply { mkdirs() }
        val baseApk = File(tempDir, "base.apk").apply { writeBytes(ByteArray(256)) }
        val splitArm64Apk = File(tempDir, "split_config.arm64_v8a.apk")

        // Construct minimal valid ELF64 AArch64 header (e_machine = 183 = 0xB7, 0x00)
        val elfHeader = ByteArray(24).apply {
            this[0] = 0x7F.toByte()
            this[1] = 'E'.code.toByte()
            this[2] = 'L'.code.toByte()
            this[3] = 'F'.code.toByte()
            this[4] = 2 // ELFCLASS64
            this[18] = 0xB7.toByte() // EM_AARCH64 (183)
            this[19] = 0x00
        }
        java.util.zip.ZipOutputStream(splitArm64Apk.outputStream()).use { zos ->
            zos.putNextEntry(java.util.zip.ZipEntry("lib/arm64-v8a/libminecraftpe.so"))
            zos.write(elfHeader)
            zos.closeEntry()
        }

        val betaTrialPkg = PackageInfo().apply {
            packageName = "com.mojang.minecrafttrialpe"
            versionName = "1.26.70.24"
            applicationInfo = ApplicationInfo().apply {
                packageName = "com.mojang.minecrafttrialpe"
                sourceDir = baseApk.absolutePath
                splitNames = arrayOf("config.arm64_v8a")
                splitSourceDirs = arrayOf(splitArm64Apk.absolutePath)
                flags = 0 // extractNativeLibs = false
            }
        }
        shadowOf(context.packageManager).installPackage(betaTrialPkg)

        val telemetry = manager.collectDeviceTelemetry()
        val detected = telemetry.installedEditions.first { it.packageName == "com.mojang.minecrafttrialpe" }
        assertEquals("1.26.70.24", detected.versionName)
        assertEquals(false, detected.extractNativeLibsEnabled)
        assertEquals(1, detected.embeddedNativeLibs.size)
        assertEquals("arm64-v8a", detected.embeddedNativeLibs.first().abi)
        assertEquals("ELF64 AArch64 (arm64-v8a)", detected.embeddedNativeLibs.first().elfArchLabel)
    }
}
