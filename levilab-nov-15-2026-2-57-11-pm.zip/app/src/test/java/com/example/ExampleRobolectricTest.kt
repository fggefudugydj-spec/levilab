package com.example

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import androidx.test.core.app.ApplicationProvider
import com.example.data.AndroidTelemetryAndCacheManager
import com.example.data.BedrockRakNetPinger
import com.example.data.DexInspector
import com.example.data.ElfBinaryInspector
import com.example.data.LauncherPreferencesRepository
import com.example.data.PersistentLaunchLogger
import com.example.model.CacheHealthStatus
import com.example.model.LogLevel
import com.example.model.ProfileSourceType
import com.example.model.SplitCategory
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read app name string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("LeviLab", appName)
    }

    @Test
    fun `cache inspector rejects non-ELF or small fake libminecraftpe files`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val manager = AndroidTelemetryAndCacheManager(context)

        val abiDir = File(manager.cacheRootDir, "fake_test/arm64-v8a").apply { mkdirs() }
        val libFile = File(abiDir, "libminecraftpe.so")

        // 1. Plain text fake file must NOT verify and must be cleaned up
        libFile.writeText("LEVI_CACHE_INDEX_V4\nabi=arm64-v8a\n")
        val textProfile = manager.inspectProfileCache(
            profileId = "fake_test",
            displayName = "Bedrock Preview",
            versionName = "1.26.70.24",
            packageName = "com.mojang.minecraftpe.preview",
            targetAbi = "arm64-v8a",
            deviceSupportedAbis = listOf("arm64-v8a"),
            sourceType = ProfileSourceType.INSTALLED_PACKAGE
        )
        assertFalse(textProfile.hasRealElfBinary)
        assertEquals(CacheHealthStatus.MISSING_LIB, textProfile.cacheStatus)

        // 2. Small ELF header <= 1 MB must NOT verify
        libFile.writeBytes(buildSyntheticElf64(loadAlign = 16384L, neededLibs = listOf("libc++_shared.so"), minTotalSize = 4096))
        val smallElfProfile = manager.inspectProfileCache(
            profileId = "fake_test",
            displayName = "Bedrock Preview",
            versionName = "1.26.70.24",
            packageName = "com.mojang.minecraftpe.preview",
            targetAbi = "arm64-v8a",
            deviceSupportedAbis = listOf("arm64-v8a"),
            sourceType = ProfileSourceType.INSTALLED_PACKAGE
        )
        assertFalse(smallElfProfile.hasRealElfBinary)
        assertEquals(CacheHealthStatus.MISSING_LIB, smallElfProfile.cacheStatus)

        // 3. cleanupInvalidCacheFiles removes both fake/small files
        manager.cleanupInvalidCacheFiles()
        assertFalse(libFile.exists())

        // 4. Valid ELF64 > 1 MB is ACCEPTED as VERIFIED
        libFile.writeBytes(buildSyntheticElf64(loadAlign = 16384L, neededLibs = listOf("libc++_shared.so"), minTotalSize = 1_100_000))
        val validElfProfile = manager.inspectProfileCache(
            profileId = "fake_test",
            displayName = "Bedrock Preview",
            versionName = "1.26.70.24",
            packageName = "com.mojang.minecraftpe.preview",
            targetAbi = "arm64-v8a",
            deviceSupportedAbis = listOf("arm64-v8a"),
            sourceType = ProfileSourceType.INSTALLED_PACKAGE
        )
        assertTrue(validElfProfile.hasRealElfBinary)
        assertEquals(CacheHealthStatus.VERIFIED, validElfProfile.cacheStatus)
    }

    @Test
    fun `direct nativeLibraryDir is used without copying when valid gt 1MB ELF exists there`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val manager = AndroidTelemetryAndCacheManager(context)

        val sysNativeDir = File(context.cacheDir, "fake_sys_native_lib_dir/arm64").apply { mkdirs() }
        val sysSo = File(sysNativeDir, "libminecraftpe.so")
        sysSo.writeBytes(buildSyntheticElf64(loadAlign = 16384L, neededLibs = listOf("libc++_shared.so"), minTotalSize = 1_100_000))

        val previewPkg = PackageInfo().apply {
            packageName = "com.mojang.minecraftpe.preview"
            versionName = "1.26.70.24"
            applicationInfo = ApplicationInfo().apply {
                packageName = "com.mojang.minecraftpe.preview"
                sourceDir = File(context.cacheDir, "dummy_base.apk").apply { writeBytes(ByteArray(16)) }.absolutePath
                nativeLibraryDir = sysNativeDir.absolutePath
            }
        }
        shadowOf(context.packageManager).installPackage(previewPkg)

        val profile = manager.inspectProfileCache(
            profileId = "direct_sys_profile",
            displayName = "Bedrock Preview",
            versionName = "1.26.70.24",
            packageName = "com.mojang.minecraftpe.preview",
            targetAbi = "arm64-v8a",
            deviceSupportedAbis = listOf("arm64-v8a"),
            sourceType = ProfileSourceType.INSTALLED_PACKAGE,
            installedNativeLibDir = sysNativeDir.absolutePath
        )
        assertEquals(CacheHealthStatus.VERIFIED, profile.cacheStatus)
        assertTrue(profile.hasRealElfBinary)
        assertEquals(sysSo.absolutePath, profile.cachePath)

        val res = manager.extractRealLibsFromInstalledPackage(
            profileId = "direct_sys_profile",
            packageName = "com.mojang.minecraftpe.preview",
            targetAbi = "arm64-v8a"
        )
        assertTrue(res.success)
        assertEquals("nativeLibraryDir (direct)", res.mainLib?.sourceApkName)
    }

    @Test
    fun `extractRealLibsFromInstalledPackage extracts gt 1MB ELF64 and companions via temp and rename`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val manager = AndroidTelemetryAndCacheManager(context)

        val tempDir = File(context.cacheDir, "test_real_extract_preview").apply { mkdirs() }
        val baseApk = File(tempDir, "base.apk").apply { writeBytes(ByteArray(128)) }
        val splitArm64Apk = File(tempDir, "split_config.arm64_v8a.apk")

        val bigElf = buildSyntheticElf64(
            loadAlign = 16384L,
            neededLibs = listOf("libc++_shared.so", "libfmod.so"),
            jniSymbols = listOf("Java_com_mojang_minecraftpe_MainActivity_nativeShutdown", "JNI_OnLoad"),
            minTotalSize = 1_100_000
        )
        val companionElf = buildSyntheticElf64(
            loadAlign = 16384L,
            neededLibs = emptyList(),
            minTotalSize = 2048
        )

        ZipOutputStream(splitArm64Apk.outputStream()).use { zos ->
            zos.putNextEntry(ZipEntry("lib/arm64-v8a/libminecraftpe.so"))
            zos.write(bigElf)
            zos.closeEntry()
            zos.putNextEntry(ZipEntry("lib/arm64-v8a/libc++_shared.so"))
            zos.write(companionElf)
            zos.closeEntry()
            zos.putNextEntry(ZipEntry("lib/arm64-v8a/libfmod.so"))
            zos.write(companionElf)
            zos.closeEntry()
        }

        val previewPkg = PackageInfo().apply {
            packageName = "com.mojang.minecraftpe.preview"
            versionName = "1.26.70.24"
            applicationInfo = ApplicationInfo().apply {
                packageName = "com.mojang.minecraftpe.preview"
                sourceDir = baseApk.absolutePath
                splitNames = arrayOf("config.arm64_v8a")
                splitSourceDirs = arrayOf(splitArm64Apk.absolutePath)
                flags = 0
            }
        }
        shadowOf(context.packageManager).installPackage(previewPkg)

        val res = manager.extractRealLibsFromInstalledPackage(
            profileId = "bedrock_preview_1_26_70_24",
            packageName = "com.mojang.minecraftpe.preview",
            targetAbi = "arm64-v8a"
        )
        assertTrue(res.success)
        assertNotNull(res.mainLib)
        assertEquals(1_100_000L, res.mainLib!!.uncompressedSize)
        assertEquals("ELF64 AArch64 (arm64-v8a)", res.mainLib!!.elfArchLabel)

        val abiDir = File(manager.cacheRootDir, "bedrock_preview_1_26_70_24/arm64-v8a")
        assertTrue(abiDir.listFiles()?.none { it.name.endsWith(".tmp") } == true)

        val profile = manager.inspectProfileCache(
            profileId = "bedrock_preview_1_26_70_24",
            displayName = "Bedrock Preview v1.26.70.24",
            versionName = "1.26.70.24",
            packageName = "com.mojang.minecraftpe.preview",
            targetAbi = "arm64-v8a",
            deviceSupportedAbis = listOf("arm64-v8a"),
            sourceType = ProfileSourceType.INSTALLED_PACKAGE
        )
        assertEquals(CacheHealthStatus.VERIFIED, profile.cacheStatus)
        assertTrue(profile.hasRealElfBinary)
        assertTrue(profile.companionLibsFound.containsAll(listOf("libc++_shared.so", "libfmod.so")))
        assertEquals(listOf("libc++_shared.so", "libfmod.so"), profile.neededLibraries)

        // Verify topological load order puts local dependencies before libminecraftpe.so
        val loadOrder = ElfBinaryInspector.resolveTopologicalLoadOrder(abiDir, "libminecraftpe.so")
        assertEquals(
            listOf("libc++_shared.so", "libfmod.so", "libminecraftpe.so"),
            loadOrder.map { it.libraryName }
        )
    }

    @Test
    fun `extractRealLibsFromArchiveUri extracts nested split ELF64 gt 1MB from apks bundle`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val manager = AndroidTelemetryAndCacheManager(context)

        val tempDir = File(context.cacheDir, "test_apks_archive_real").apply { mkdirs() }
        val apksFile = File(tempDir, "Minecraft_Preview_1.26.70.24.apks")

        val bigElf = buildSyntheticElf64(
            loadAlign = 16384L,
            neededLibs = listOf("libfmod.so"),
            minTotalSize = 1_060_000
        )
        val companionElf = buildSyntheticElf64(loadAlign = 16384L, neededLibs = emptyList(), minTotalSize = 2048)

        val innerApkBytes = ByteArrayOutputStream().use { baos ->
            ZipOutputStream(baos).use { innerZos ->
                innerZos.putNextEntry(ZipEntry("lib/arm64-v8a/libminecraftpe.so"))
                innerZos.write(bigElf)
                innerZos.closeEntry()
                innerZos.putNextEntry(ZipEntry("lib/arm64-v8a/libfmod.so"))
                innerZos.write(companionElf)
                innerZos.closeEntry()
            }
            baos.toByteArray()
        }

        ZipOutputStream(apksFile.outputStream()).use { outerZos ->
            outerZos.putNextEntry(ZipEntry("base.apk"))
            outerZos.write(ByteArray(64))
            outerZos.closeEntry()
            outerZos.putNextEntry(ZipEntry("split_config.arm64_v8a.apk"))
            outerZos.write(innerApkBytes)
            outerZos.closeEntry()
        }

        val res = manager.extractRealLibsFromArchiveUri(
            uri = android.net.Uri.fromFile(apksFile),
            profileId = "preview_archive_profile",
            targetAbi = "arm64-v8a"
        )
        assertTrue(res.success)
        assertNotNull(res.mainLib)
        assertEquals("ELF64 AArch64 (arm64-v8a)", res.mainLib!!.elfArchLabel)

        val profile = manager.inspectProfileCache(
            profileId = "preview_archive_profile",
            displayName = "Bedrock Preview Archive",
            versionName = "1.26.70.24",
            packageName = "com.mojang.minecraftpe.preview",
            targetAbi = "arm64-v8a",
            deviceSupportedAbis = listOf("arm64-v8a"),
            sourceType = ProfileSourceType.SPLIT_APKS
        )
        assertEquals(CacheHealthStatus.VERIFIED, profile.cacheStatus)
        assertTrue(profile.hasRealElfBinary)
        assertTrue(profile.companionLibsFound.contains("libfmod.so"))
    }

    @Test
    fun `elf inspector extracts DT_NEEDED and JNI symbols`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val elfFile = File(context.cacheDir, "test_jni_elf.so")
        elfFile.writeBytes(
            buildSyntheticElf64(
                loadAlign = 16384L,
                neededLibs = listOf("libfmod.so", "libc++_shared.so"),
                jniSymbols = listOf("Java_com_mojang_minecraftpe_MainActivity_nativeOnPickImage", "JNI_OnLoad"),
                minTotalSize = 4096
            )
        )

        val report = ElfBinaryInspector.inspectElfFile(elfFile, includeJniSymbols = true)
        assertTrue(report.isValidElf)
        assertTrue(report.is16KbAligned)
        assertEquals(listOf("libfmod.so", "libc++_shared.so"), report.neededLibraries)
        assertTrue(report.jniSymbols.contains("JNI_OnLoad"))
        assertTrue(report.jniSymbols.contains("Java_com_mojang_minecraftpe_MainActivity_nativeOnPickImage"))
    }

    @Test
    fun `dex inspector parses com_mojang classes, inheritance chain, and MainActivity native methods`() {
        val syntheticDex = buildMinimalSyntheticDex(
            classDescriptor = "Lcom/mojang/minecraftpe/MainActivity;",
            nativeMethodName = "nativeShutdown"
        )
        val res = DexInspector.inspectDex(syntheticDex)
        assertTrue(res.mojangClasses.contains("com.mojang.minecraftpe.MainActivity"))
        assertEquals(1, res.mainActivityNativeMethods.size)
        assertEquals("nativeShutdown", res.mainActivityNativeMethods.first().methodName)
        assertEquals("DEX", res.mainActivityNativeMethods.first().source)
        val chain = DexInspector.resolveInheritanceChain(
            startCandidates = listOf("com.mojang.minecraftpe.MainActivity"),
            superclassMap = res.superclassMap
        )
        assertEquals(listOf("com.mojang.minecraftpe.MainActivity", "java.lang.Object"), chain)
    }

    @Test
    fun `persistent launch logger appends across sessions and recovers interrupted crash marker`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val logger = PersistentLaunchLogger(context)
        logger.clearLog()
        logger.startNewSession("Test Session 1")
        logger.append(LogLevel.INFO, "STAGE-A", "First line")
        logger.markPendingRiskyCall("System.load(/data/user/0/test/libminecraftpe.so)")

        // Simulate abrupt native crash before clearPendingRiskyCall() was invoked:
        val loggerAfterRestart = PersistentLaunchLogger(context)
        val crashNote = loggerAfterRestart.recoverInterruptedRiskyStepIfAny()
        assertNotNull(crashNote)
        assertTrue(crashNote!!.contains("System.load"))

        // Starting a second session appends rather than wiping crash history:
        loggerAfterRestart.startNewSession("Test Session 2")
        val entries = loggerAfterRestart.readPersistedEntries()
        assertTrue(entries.any { it.message.contains("First line") })
        assertTrue(entries.any { it.level == LogLevel.ERROR && it.message.contains("[CRASH]") })
        assertNull(loggerAfterRestart.recoverInterruptedRiskyStepIfAny())
    }

    @Test
    fun `strict getLaunchIntentForPackage resolves official preview package`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val manager = AndroidTelemetryAndCacheManager(context)

        val previewPkg = PackageInfo().apply {
            packageName = "com.mojang.minecraftpe.preview"
            versionName = "1.26.70.24"
            applicationInfo = ApplicationInfo().apply {
                packageName = "com.mojang.minecraftpe.preview"
                sourceDir = "/data/app/preview/base.apk"
            }
        }
        val resolveInfo = android.content.pm.ResolveInfo().apply {
            activityInfo = android.content.pm.ActivityInfo().apply {
                packageName = "com.mojang.minecraftpe.preview"
                name = "com.mojang.minecraftpe.MainActivity"
            }
        }
        val mainIntent = android.content.Intent(android.content.Intent.ACTION_MAIN).apply {
            addCategory(android.content.Intent.CATEGORY_LAUNCHER)
            setPackage("com.mojang.minecraftpe.preview")
        }
        shadowOf(context.packageManager).installPackage(previewPkg)
        shadowOf(context.packageManager).addResolveInfoForIntent(mainIntent, resolveInfo)

        val launchIntent = manager.getStrictLaunchIntentForPackage("com.mojang.minecraftpe.preview")
        assertNotNull(launchIntent)
        assertEquals("com.mojang.minecraftpe.preview", launchIntent?.component?.packageName)
    }

    @Test
    fun `split inspector classifies resource and language splits and sums disk usage`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val manager = AndroidTelemetryAndCacheManager(context)

        assertEquals(SplitCategory.RESOURCE_DENSITY, manager.classifySplitApkName("split_config.xxhdpi"))
        assertEquals(SplitCategory.LANGUAGE, manager.classifySplitApkName("split_config.ar"))
        assertEquals(SplitCategory.NATIVE_ABI, manager.classifySplitApkName("split_config.arm64_v8a"))

        val tempDir = File(context.cacheDir, "test_splits").apply { mkdirs() }
        val baseFile = File(tempDir, "base.apk").apply { writeBytes(ByteArray(1024)) }
        val resFile = File(tempDir, "split_config.xxhdpi.apk").apply { writeBytes(ByteArray(2048)) }
        val langFile = File(tempDir, "split_config.ar.apk").apply { writeBytes(ByteArray(512)) }
        val abiFile = File(tempDir, "split_config.arm64_v8a.apk").apply { writeBytes(ByteArray(4096)) }

        val pkgInfo = PackageInfo().apply {
            packageName = "com.mojang.minecraftpe.preview"
            versionName = "1.26.70.24"
            applicationInfo = ApplicationInfo().apply {
                packageName = "com.mojang.minecraftpe.preview"
                sourceDir = baseFile.absolutePath
                splitNames = arrayOf("config.xxhdpi", "config.ar", "config.arm64_v8a")
                splitSourceDirs = arrayOf(
                    resFile.absolutePath,
                    langFile.absolutePath,
                    abiFile.absolutePath
                )
            }
        }
        shadowOf(context.packageManager).installPackage(pkgInfo)

        val report = manager.inspectInstalledMinecraftSplits("com.mojang.minecraftpe.preview")
        assertTrue(report.isInstalled)
        assertEquals("com.mojang.minecraftpe.preview", report.packageName)
        assertEquals(3, report.splitFragments.size)
        assertEquals(2048L + 512L, report.resourceAndLanguageTotalBytes)
        assertEquals(1024L + 2048L + 512L + 4096L, report.totalPackageDiskBytes)
    }

    @Test
    fun `isolated sandbox creates games com_mojang directory and persists options_txt`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val manager = AndroidTelemetryAndCacheManager(context)

        val initial = manager.ensureIsolatedSandbox("bedrock_preview_1_26_70_24")
        assertTrue(File(initial.sandboxRootPath).exists())
        assertTrue(File(initial.optionsTxtPath).exists())

        val updated = manager.updateSandboxOptions(
            profileId = "bedrock_preview_1_26_70_24",
            playerName = "PreviewTester",
            isolatedEnabled = true,
            gfxVsync = false,
            devEnableProfiler = true,
            devShowChunkMap = true,
            maxFramerate = 120
        )
        assertEquals("PreviewTester", updated.playerName)
        assertEquals(120, updated.maxFramerate)
    }

    @Test
    fun `raknet pinger parses 0x1c pong MOTD`() {
        val motdPayload = "MCPE;§aLeviLab Preview;900;1.26.70.24;3;20;998877;PreviewWorld;Survival"
        val motdBytes = motdPayload.toByteArray()
        val pong = ByteBuffer.allocate(1 + 8 + 8 + 16 + 2 + motdBytes.size).order(ByteOrder.BIG_ENDIAN).apply {
            put(0x1c.toByte())
            putLong(123456L)
            putLong(998877L)
            put(ByteArray(16) { 0x00 })
            putShort(motdBytes.size.toShort())
            put(motdBytes)
        }.array()

        val parsed = BedrockRakNetPinger.parseUnconnectedPongPacket(
            host = "127.0.0.1",
            port = 19132,
            packetBytes = pong,
            length = pong.size,
            latencyMs = 15L
        )
        assertNotNull(parsed)
        assertEquals("LeviLab Preview", parsed!!.motd)
        assertEquals("1.26.70.24", parsed.gameVersion)
    }

    @Test
    fun `preferences repository defaults to preview profile and persists real mods only`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repo = LauncherPreferencesRepository(context)
        val initial = repo.prefsFlow.first()
        assertEquals("bedrock_preview_1_26_70_24", initial.selectedProfileId)
        assertTrue(initial.customMods.isEmpty())
    }

    private fun buildSyntheticElf64(
        loadAlign: Long,
        neededLibs: List<String>,
        jniSymbols: List<String> = emptyList(),
        minTotalSize: Int = 2048
    ): ByteArray {
        val dynstrOffset = 0x100
        val dynstrBytes = ByteArrayOutputStream().apply {
            write(0)
        }
        val neededOffsets = neededLibs.map { lib ->
            val off = dynstrBytes.size()
            dynstrBytes.write(lib.toByteArray(Charsets.UTF_8))
            dynstrBytes.write(0)
            off
        }
        jniSymbols.forEach { sym ->
            dynstrBytes.write(sym.toByteArray(Charsets.UTF_8))
            dynstrBytes.write(0)
        }
        val dynstr = dynstrBytes.toByteArray()

        val dynamicOffset = ((dynstrOffset + dynstr.size + 63) / 64) * 64
        val dynamicEntryCount = neededOffsets.size + 3 // DT_NEEDEDs + DT_STRTAB + DT_STRSZ + DT_NULL
        val requiredSize = dynamicOffset + dynamicEntryCount * 16 + 64
        val totalSize = maxOf(requiredSize, minTotalSize)
        val buf = ByteBuffer.allocate(totalSize).order(ByteOrder.LITTLE_ENDIAN)

        buf.put(0, 0x7F.toByte())
        buf.put(1, 'E'.code.toByte())
        buf.put(2, 'L'.code.toByte())
        buf.put(3, 'F'.code.toByte())
        buf.put(4, 2.toByte()) // ELFCLASS64
        buf.put(5, 1.toByte()) // ELFDATA2LSB
        buf.putShort(18, 183.toShort()) // EM_AARCH64
        buf.putLong(32, 64L) // e_phoff
        buf.putShort(54, 56.toShort()) // e_phentsize
        buf.putShort(56, 2.toShort()) // e_phnum

        // Phdr[0]: PT_LOAD
        buf.putInt(64, 1)
        buf.putLong(64 + 8, 0L)
        buf.putLong(64 + 16, 0L)
        buf.putLong(64 + 32, totalSize.toLong())
        buf.putLong(64 + 48, loadAlign)

        // Phdr[1]: PT_DYNAMIC
        buf.putInt(64 + 56, 2)
        buf.putLong(64 + 56 + 8, dynamicOffset.toLong())
        buf.putLong(64 + 56 + 16, dynamicOffset.toLong())
        buf.putLong(64 + 56 + 32, (dynamicEntryCount * 16).toLong())
        buf.putLong(64 + 56 + 48, 8L)

        dynstr.forEachIndexed { idx, b -> buf.put(dynstrOffset + idx, b) }

        var pos = dynamicOffset
        neededOffsets.forEach { off ->
            buf.putLong(pos, 1L) // DT_NEEDED
            buf.putLong(pos + 8, off.toLong())
            pos += 16
        }
        buf.putLong(pos, 5L) // DT_STRTAB
        buf.putLong(pos + 8, dynstrOffset.toLong())
        pos += 16
        buf.putLong(pos, 10L) // DT_STRSZ
        buf.putLong(pos + 8, dynstr.size.toLong())
        pos += 16
        buf.putLong(pos, 0L) // DT_NULL
        buf.putLong(pos + 8, 0L)

        return buf.array()
    }

    private fun buildMinimalSyntheticDex(
        classDescriptor: String,
        nativeMethodName: String
    ): ByteArray {
        // String table: [0]="()V", [1]=classDescriptor, [2]="Ljava/lang/Object;", [3]="V", [4]=nativeMethodName
        val strings = listOf("()V", classDescriptor, "Ljava/lang/Object;", "V", nativeMethodName)
        val totalSize = 1024
        val bytes = ByteArray(totalSize)
        val buf = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)

        // Magic "dex\n035\0"
        val magic = "dex\n035\u0000".toByteArray(Charsets.US_ASCII)
        System.arraycopy(magic, 0, bytes, 0, magic.size)

        val stringIdsOff = 0x70
        val typeIdsOff = 0x90
        val protoIdsOff = 0xB0
        val methodIdsOff = 0xD0
        val classDefsOff = 0xF0
        val stringDataStart = 0x140
        val classDataOff = 0x280

        buf.putInt(56, strings.size) // string_ids_size
        buf.putInt(60, stringIdsOff)
        buf.putInt(64, 3) // type_ids_size: [0]=class, [1]=Object, [2]=void
        buf.putInt(68, typeIdsOff)
        buf.putInt(72, 1) // proto_ids_size: [0]=()V
        buf.putInt(76, protoIdsOff)
        buf.putInt(88, 1) // method_ids_size: [0]=class.nativeMethodName()V
        buf.putInt(92, methodIdsOff)
        buf.putInt(96, 1) // class_defs_size
        buf.putInt(100, classDefsOff)

        var dataCursor = stringDataStart
        strings.forEachIndexed { idx, s ->
            buf.putInt(stringIdsOff + idx * 4, dataCursor)
            val utf = s.toByteArray(Charsets.UTF_8)
            bytes[dataCursor++] = utf.size.toByte()
            System.arraycopy(utf, 0, bytes, dataCursor, utf.size)
            dataCursor += utf.size
            bytes[dataCursor++] = 0
        }

        // type_ids: [0] -> string 1 (class), [1] -> string 2 (Object), [2] -> string 3 ("V")
        buf.putInt(typeIdsOff, 1)
        buf.putInt(typeIdsOff + 4, 2)
        buf.putInt(typeIdsOff + 8, 3)

        // proto_id[0]: shorty_idx=0, return_type_idx=2, parameters_off=0
        buf.putInt(protoIdsOff, 0)
        buf.putInt(protoIdsOff + 4, 2)
        buf.putInt(protoIdsOff + 8, 0)

        // method_id[0]: class_idx=0, proto_idx=0, name_idx=4
        buf.putShort(methodIdsOff, 0)
        buf.putShort(methodIdsOff + 2, 0)
        buf.putInt(methodIdsOff + 4, 4)

        // class_def[0]: class_idx=0, superclass_idx=1 (Object), ..., class_data_off
        buf.putInt(classDefsOff, 0)
        buf.putInt(classDefsOff + 8, 1)
        buf.putInt(classDefsOff + 24, classDataOff)

        // class_data_item at classDataOff:
        // static_fields=0, instance_fields=0, direct_methods=1, virtual_methods=0
        var cPos = classDataOff
        bytes[cPos++] = 0
        bytes[cPos++] = 0
        bytes[cPos++] = 1
        bytes[cPos++] = 0
        // encoded_method: method_idx_diff=0, access_flags=0x0100 (ACC_NATIVE, uleb128: 0x80, 0x02), code_off=0
        bytes[cPos++] = 0
        bytes[cPos++] = 0x80.toByte()
        bytes[cPos++] = 0x02
        bytes[cPos++] = 0

        return bytes
    }
}
