package com.example

import android.app.Application
import com.example.data.PersistentLaunchLogger

class LeviLabApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        val logger = PersistentLaunchLogger(this)
        logger.recoverInterruptedRiskyStepIfAny()

        val previousHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                logger.recordUncaughtCrash(thread.name, throwable)
            } catch (_: Throwable) {
                // Best effort persistence before process exit
            }
            previousHandler?.uncaughtException(thread, throwable)
        }
    }
}
