package com.example.ui.screens.home

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.FolderCopy
import androidx.compose.material.icons.outlined.FolderOpen
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.ui.LeviStrings
import com.example.ui.LeviUiState
import com.example.ui.components.StatusPill
import com.example.ui.theme.JetBrainsMonoFamily

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SandboxOptionsSection(
    uiState: LeviUiState,
    strings: LeviStrings,
    onUpdateSandboxOptions: (String, Boolean, Boolean, Boolean, Boolean, Int, Int) -> Unit,
    onToggleLaunchInsideTask: (Boolean) -> Unit,
    onToggleAutoSyncOptions: (Boolean) -> Unit,
    onLinkMojangTreeClick: () -> Unit,
    onUnlinkMojangTree: () -> Unit,
    onSyncOptionsToSaf: () -> Unit,
    modifier: Modifier = Modifier
) {
    val sandbox = uiState.activeSandbox ?: return

    Card(
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, MaterialTheme.shapes.medium)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.FolderCopy,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.secondary
                    )
                    Column {
                        Text(
                            text = strings.sandboxTitle,
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            text = strings.sandboxSubtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                StatusPill(
                    text = "${sandbox.resourcePackCount} RP • ${sandbox.behaviorPackCount} BP",
                    containerColor = MaterialTheme.colorScheme.secondaryContainer,
                    contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
                    leadingDot = false
                )
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(MaterialTheme.shapes.small)
                    .background(MaterialTheme.colorScheme.surfaceContainerLowest)
                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant, MaterialTheme.shapes.small)
                    .padding(10.dp)
            ) {
                Text(
                    text = sandbox.sandboxRootPath,
                    style = MaterialTheme.typography.labelSmall,
                    fontFamily = JetBrainsMonoFamily,
                    color = MaterialTheme.colorScheme.secondary
                )
            }

            var editedPlayerName by remember(sandbox.profileId, sandbox.playerName) {
                mutableStateOf(sandbox.playerName)
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = editedPlayerName,
                    onValueChange = { editedPlayerName = it },
                    label = { Text(strings.playerNameLabel) },
                    singleLine = true,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("sandbox_player_name_input")
                )
                Button(
                    onClick = {
                        onUpdateSandboxOptions(
                            editedPlayerName,
                            sandbox.isolatedEnabled,
                            sandbox.gfxVsync,
                            sandbox.devEnableProfiler,
                            sandbox.devShowChunkMap,
                            sandbox.maxFramerate,
                            sandbox.gfxViewDistance
                        )
                    },
                    modifier = Modifier
                        .height(52.dp)
                        .testTag("save_player_name_button"),
                    shape = MaterialTheme.shapes.small
                ) {
                    Text(strings.savePlayerNameCta)
                }
            }

            SandboxToggleRow(
                label = strings.launchInsideTaskLabel,
                subtitle = strings.launchInsideTaskHint,
                checked = uiState.launchInsideTask,
                testTag = "launch_inside_task_switch",
                onCheckedChange = onToggleLaunchInsideTask
            )

            SandboxToggleRow(
                label = strings.autoSyncOptionsLabel,
                checked = uiState.autoSyncOptionsOnLaunch,
                testTag = "auto_sync_options_switch",
                onCheckedChange = onToggleAutoSyncOptions
            )

            SandboxToggleRow(
                label = strings.sandboxIsolatedLabel,
                checked = sandbox.isolatedEnabled,
                testTag = "sandbox_isolated_switch",
                onCheckedChange = { enabled ->
                    onUpdateSandboxOptions(
                        editedPlayerName,
                        enabled,
                        sandbox.gfxVsync,
                        sandbox.devEnableProfiler,
                        sandbox.devShowChunkMap,
                        sandbox.maxFramerate,
                        sandbox.gfxViewDistance
                    )
                }
            )
            SandboxToggleRow(
                label = strings.sandboxVsyncLabel,
                checked = sandbox.gfxVsync,
                testTag = "sandbox_vsync_switch",
                onCheckedChange = { vsync ->
                    onUpdateSandboxOptions(
                        editedPlayerName,
                        sandbox.isolatedEnabled,
                        vsync,
                        sandbox.devEnableProfiler,
                        sandbox.devShowChunkMap,
                        sandbox.maxFramerate,
                        sandbox.gfxViewDistance
                    )
                }
            )
            SandboxToggleRow(
                label = strings.sandboxProfilerLabel,
                checked = sandbox.devEnableProfiler,
                testTag = "sandbox_profiler_switch",
                onCheckedChange = { prof ->
                    onUpdateSandboxOptions(
                        editedPlayerName,
                        sandbox.isolatedEnabled,
                        sandbox.gfxVsync,
                        prof,
                        sandbox.devShowChunkMap,
                        sandbox.maxFramerate,
                        sandbox.gfxViewDistance
                    )
                }
            )
            SandboxToggleRow(
                label = strings.sandboxChunkMapLabel,
                checked = sandbox.devShowChunkMap,
                testTag = "sandbox_chunk_map_switch",
                onCheckedChange = { chunkMap ->
                    onUpdateSandboxOptions(
                        editedPlayerName,
                        sandbox.isolatedEnabled,
                        sandbox.gfxVsync,
                        sandbox.devEnableProfiler,
                        chunkMap,
                        sandbox.maxFramerate,
                        sandbox.gfxViewDistance
                    )
                }
            )

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = strings.sandboxMaxFpsLabel,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(60, 90, 120).forEach { fps ->
                        FilterChip(
                            selected = sandbox.maxFramerate == fps,
                            onClick = {
                                onUpdateSandboxOptions(
                                    editedPlayerName,
                                    sandbox.isolatedEnabled,
                                    sandbox.gfxVsync,
                                    sandbox.devEnableProfiler,
                                    sandbox.devShowChunkMap,
                                    fps,
                                    sandbox.gfxViewDistance
                                )
                            },
                            label = {
                                Text("$fps FPS", fontFamily = JetBrainsMonoFamily)
                            }
                        )
                    }
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = strings.renderDistanceLabel,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(6, 12, 16, 24).forEach { chunks ->
                        FilterChip(
                            selected = sandbox.gfxViewDistance == chunks,
                            onClick = {
                                onUpdateSandboxOptions(
                                    editedPlayerName,
                                    sandbox.isolatedEnabled,
                                    sandbox.gfxVsync,
                                    sandbox.devEnableProfiler,
                                    sandbox.devShowChunkMap,
                                    sandbox.maxFramerate,
                                    chunks
                                )
                            },
                            label = {
                                Text("$chunks ch", fontFamily = JetBrainsMonoFamily)
                            }
                        )
                    }
                }
            }

            val safSummary = uiState.linkedMojangSummary
            if (safSummary == null) {
                OutlinedButton(
                    onClick = onLinkMojangTreeClick,
                    enabled = !uiState.isSyncingSafTree,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("link_mojang_saf_button"),
                    shape = MaterialTheme.shapes.small
                ) {
                    Icon(Icons.Outlined.FolderOpen, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(strings.linkMojangFolderCta)
                }
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(MaterialTheme.shapes.small)
                        .background(MaterialTheme.colorScheme.surfaceContainerLowest)
                        .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f), MaterialTheme.shapes.small)
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${safSummary.folderDisplayName} • ${safSummary.worldsCount}W / ${safSummary.resourcePacksCount}RP / ${safSummary.behaviorPacksCount}BP",
                            style = MaterialTheme.typography.labelMedium,
                            fontFamily = JetBrainsMonoFamily,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.weight(1f)
                        )
                        TextButton(
                            onClick = onUnlinkMojangTree,
                            modifier = Modifier
                                .height(48.dp)
                                .testTag("unlink_mojang_saf_button")
                        ) {
                            Text(strings.unlinkFolderCta, color = MaterialTheme.colorScheme.error)
                        }
                    }
                    if (safSummary.worldNames.isNotEmpty()) {
                        Text(
                            text = "${strings.safWorldsLabel}: ${safSummary.worldNames.joinToString()}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    if (!safSummary.hasOptionsTxt) {
                        Text(
                            text = strings.safNoOptionsHint,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Button(
                        onClick = onSyncOptionsToSaf,
                        enabled = !uiState.isSyncingSafTree,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("sync_options_saf_button"),
                        shape = MaterialTheme.shapes.small
                    ) {
                        Text(strings.syncOptionsToSafCta)
                    }
                }
            }
        }
    }
}

@Composable
private fun SandboxToggleRow(
    label: String,
    checked: Boolean,
    testTag: String,
    subtitle: String? = null,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) }
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
            if (subtitle != null) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Spacer(Modifier.width(8.dp))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            modifier = Modifier.testTag(testTag)
        )
    }
}
