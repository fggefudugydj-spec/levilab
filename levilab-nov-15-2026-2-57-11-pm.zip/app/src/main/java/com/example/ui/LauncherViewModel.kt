package com.example.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AndroidTelemetryAndCacheManager
import com.example.data.BedrockRakNetPinger
import com.example.data.ElfBinaryInspector
import com.example.data.LauncherPersistedPrefs
import com.example.data.LauncherPreferencesRepository
import com.example.data.PackageProbeManager
import com.example.data.PackageProbeReport
import com.example.data.PersistentLaunchLogger
import com.example.data.SafMojangStorageManager
import com.example.data.SafMojangTreeSummary
import com.example.model.ApkInspectionResult
import com.example.model.AppLanguage
import com.example.model.BedrockServerPreset
import com.example.model.CacheHealthStatus
import com.example.model.CustomProfileSpec
import com.example.model.DeviceTelemetry
import com.example.model.FailureReason
import com.example.model.GameProfile
import com.example.model.InstalledPackageSplitsReport
import com.example.model.IsolatedSandboxConfig
import com.example.model.LaunchLogEntry
import com.example.model.LaunchSessionState
import com.example.model.LaunchStageId
import com.example.model.LaunchStageStep
import com.example.model.LogLevel
import com.example.model.ModItem
import com.example.model.ProfileSourceType
import com.example.model.RootCauseGuideItem
import com.example.model.ServerPingStatus
import com.example.model.StageState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

data class LeviUiState(
    val isInitializing: Boolean = true,
    val language: AppLanguage = AppLanguage.AR,
    val telemetry: DeviceTelemetry? = null,
    val profiles: List<GameProfile> = emptyList(),
    val selectedProfileId: String = "bedrock_preview_1_26_70_24",
    val activeSandbox: IsolatedSandboxConfig? = null,
    val targetAbiOverride: String = "AUTO",
    val isInspectingApk: Boolean = false,
    val isExtractingRealLib: Boolean = false,
    val apkInspectionResult: ApkInspectionResult? = null,
    val isScanningSplits: Boolean = false,
    val installedSplitsReport: InstalledPackageSplitsReport? = null,
    val mods: List<ModItem> = emptyList(),
    val savedServers: List<BedrockServerPreset> = emptyList(),
    val serverPingStatuses: Map<String, ServerPingStatus> = emptyMap(),
    val linkedMojangSummary: SafMojangTreeSummary? = null,
    val isSyncingSafTree: Boolean = false,
    val launchInsideTask: Boolean = true,
    val autoSyncOptionsOnLaunch: Boolean = true,
    val launchSession: LaunchSessionState = LaunchSessionState(),
    val isProbingPackage: Boolean = false,
    val probeReport: PackageProbeReport? = null,
    val rootCauseGuides: List<RootCauseGuideItem> = defaultRootCauseGuides(),
    val statusBanner: String? = null
) {
    val selectedProfile: GameProfile?
        get() = profiles.firstOrNull { it.id == selectedProfileId } ?: profiles.firstOrNull()

    val effectiveTargetAbi: String
        get() = if (targetAbiOverride == "AUTO") {
            telemetry?.primaryAbi ?: "arm64-v8a"
        } else {
            targetAbiOverride
        }
}

class LauncherViewModel(application: Application) : AndroidViewModel(application) {

    private val cacheManager = AndroidTelemetryAndCacheManager(application)
    private val prefsRepo = LauncherPreferencesRepository(application)
    private val safStorageManager = SafMojangStorageManager(application)
    private val launchLogger = PersistentLaunchLogger(application)
    private val probeManager = PackageProbeManager(application)

    private val _uiState = MutableStateFlow(
        LeviUiState(
            launchSession = LaunchSessionState(
                persistedLogPath = launchLogger.latestLogFile.absolutePath
            )
        )
    )
    val uiState: StateFlow<LeviUiState> = _uiState.asStateFlow()

    private var launchJob: Job? = null
    private var latestPrefs = LauncherPersistedPrefs()
    private var autoBoundInstalledOnce = false
    private var lastInspectedArchiveUri: Uri? = null

    init {
        viewModelScope.launch {
            cacheManager.cleanupInvalidCacheFiles()
            val previousLogs = withContext(Dispatchers.IO) { launchLogger.readPersistedEntries() }
            val hasCrashEntry = previousLogs.any { it.message.contains("[CRASH]") }
            val telemetry = cacheManager.collectDeviceTelemetry()
            val splitsReport = cacheManager.inspectInstalledMinecraftSplits(
                telemetry.installedMinecraftPackage?.packageName ?: "com.mojang.minecraftpe.preview"
            )
            _uiState.update {
                it.copy(
                    telemetry = telemetry,
                    installedSplitsReport = splitsReport,
                    launchSession = it.launchSession.copy(
                        logs = previousLogs,
                        persistedLogPath = launchLogger.latestLogFile.absolutePath,
                        crashRecoveryNote = if (hasCrashEntry) {
                            previousLogs.lastOrNull { e -> e.message.contains("[CRASH]") }?.message
                        } else null
                    )
                )
            }

            prefsRepo.prefsFlow.collect { prefs ->
                latestPrefs = prefs
                val orderMap = prefs.modOrderIds.withIndex().associate { it.value to it.index }
                // Only real user-imported mods/packs; zero pre-programmed fake mods.
                val mergedMods = prefs.customMods
                    .distinctBy { it.id }
                    .sortedWith(compareBy<ModItem> { orderMap[it.id] ?: Int.MAX_VALUE }.thenBy { it.loadOrder })
                    .mapIndexed { idx, mod ->
                        mod.copy(
                            enabled = mod.id !in prefs.disabledModIds,
                            loadOrder = idx + 1
                        )
                    }
                val sandbox = cacheManager.ensureIsolatedSandbox(prefs.selectedProfileId)

                _uiState.update {
                    it.copy(
                        language = prefs.language,
                        selectedProfileId = prefs.selectedProfileId,
                        activeSandbox = sandbox,
                        targetAbiOverride = prefs.targetAbiOverride,
                        mods = mergedMods,
                        savedServers = prefs.savedServers,
                        launchInsideTask = prefs.launchInsideTask,
                        autoSyncOptionsOnLaunch = prefs.autoSyncOptionsOnLaunch
                    )
                }
                val extraPkgs = prefs.customProfiles.map { it.packageName }
                val refreshedTelemetry = if (extraPkgs.isNotEmpty()) {
                    cacheManager.collectDeviceTelemetry(extraPkgs)
                } else {
                    telemetry
                }
                refreshProfiles(refreshedTelemetry, prefs.targetAbiOverride, prefs.customProfiles)

                val savedTreeUri = prefs.linkedMojangTreeUri
                if (savedTreeUri == null) {
                    _uiState.update { it.copy(linkedMojangSummary = null) }
                } else if (_uiState.value.linkedMojangSummary?.treeUriString != savedTreeUri) {
                    val summary = safStorageManager.inspectLinkedTree(Uri.parse(savedTreeUri))
                    _uiState.update { it.copy(linkedMojangSummary = summary) }
                }

                if (!autoBoundInstalledOnce) {
                    autoBoundInstalledOnce = true
                    val currentProfiles = _uiState.value.profiles
                    val currentSelected = currentProfiles.firstOrNull { it.id == prefs.selectedProfileId }
                    if (currentSelected?.isInstalledOnDevice != true) {
                        val previewInstalled = currentProfiles.firstOrNull {
                            it.isInstalledOnDevice && it.packageName == "com.mojang.minecraftpe.preview"
                        } ?: currentProfiles.firstOrNull {
                            it.isInstalledOnDevice && it.installedVersionName?.contains("1.26.70") == true
                        } ?: currentProfiles.firstOrNull { it.isInstalledOnDevice }
                        if (previewInstalled != null) {
                            prefsRepo.setSelectedProfile(previewInstalled.id)
                        }
                    }
                }
            }
        }
    }

    private suspend fun refreshProfiles(
        telemetry: DeviceTelemetry?,
        abiOverride: String,
        customSpecs: List<CustomProfileSpec> = latestPrefs.customProfiles
    ) {
        val activeTelemetry = telemetry ?: cacheManager.collectDeviceTelemetry(
            customSpecs.map { it.packageName }
        )
        val effectiveAbi = if (abiOverride == "AUTO") activeTelemetry.primaryAbi else abiOverride

        val previewInstalled = activeTelemetry.installedEditions.firstOrNull {
            it.packageName == "com.mojang.minecraftpe.preview"
        }
        val fullInstalled = activeTelemetry.installedEditions.firstOrNull {
            it.packageName == "com.mojang.minecraftpe"
        }
        val betaInstalled = activeTelemetry.installedEditions.firstOrNull {
            it.packageName == "com.mojang.minecraftpe.beta"
        }
        val trialInstalled = activeTelemetry.installedEditions.firstOrNull {
            it.packageName == "com.mojang.minecrafttrialpe"
        }

        val previewProfile = cacheManager.inspectProfileCache(
            profileId = "bedrock_preview_1_26_70_24",
            displayName = "Bedrock Preview v1.26.70.24",
            versionName = previewInstalled?.versionName ?: "1.26.70.24",
            packageName = "com.mojang.minecraftpe.preview",
            targetAbi = effectiveAbi,
            deviceSupportedAbis = activeTelemetry.supportedAbis,
            sourceType = if (previewInstalled != null) ProfileSourceType.INSTALLED_PACKAGE else ProfileSourceType.INTERNAL_CACHE,
            installedNativeLibDir = previewInstalled?.nativeLibraryDir
        ).copy(
            isInstalledOnDevice = previewInstalled != null,
            installedVersionName = previewInstalled?.versionName
        )

        val fullProfile = cacheManager.inspectProfileCache(
            profileId = "bedrock_full",
            displayName = "Minecraft Bedrock",
            versionName = fullInstalled?.versionName ?: "1.26.70",
            packageName = "com.mojang.minecraftpe",
            targetAbi = effectiveAbi,
            deviceSupportedAbis = activeTelemetry.supportedAbis,
            sourceType = if (fullInstalled != null) ProfileSourceType.INSTALLED_PACKAGE else ProfileSourceType.INTERNAL_CACHE,
            installedNativeLibDir = fullInstalled?.nativeLibraryDir
        ).copy(
            isInstalledOnDevice = fullInstalled != null,
            installedVersionName = fullInstalled?.versionName
        )

        val extraStandardProfiles = buildList {
            if (betaInstalled != null) {
                add(
                    cacheManager.inspectProfileCache(
                        profileId = "bedrock_beta",
                        displayName = "Bedrock Beta",
                        versionName = betaInstalled.versionName,
                        packageName = "com.mojang.minecraftpe.beta",
                        targetAbi = effectiveAbi,
                        deviceSupportedAbis = activeTelemetry.supportedAbis,
                        sourceType = ProfileSourceType.INSTALLED_PACKAGE,
                        installedNativeLibDir = betaInstalled.nativeLibraryDir
                    ).copy(isInstalledOnDevice = true, installedVersionName = betaInstalled.versionName)
                )
            }
            if (trialInstalled != null) {
                add(
                    cacheManager.inspectProfileCache(
                        profileId = "bedrock_trial_latest",
                        displayName = "Bedrock Trial",
                        versionName = trialInstalled.versionName,
                        packageName = "com.mojang.minecrafttrialpe",
                        targetAbi = effectiveAbi,
                        deviceSupportedAbis = activeTelemetry.supportedAbis,
                        sourceType = ProfileSourceType.INSTALLED_PACKAGE,
                        installedNativeLibDir = trialInstalled.nativeLibraryDir
                    ).copy(isInstalledOnDevice = true, installedVersionName = trialInstalled.versionName)
                )
            }
        }

        val customProfiles = customSpecs.map { spec ->
            val pkgInstalled = activeTelemetry.installedEditions.firstOrNull {
                it.packageName == spec.packageName
            }
            cacheManager.inspectProfileCache(
                profileId = spec.id,
                displayName = spec.displayName,
                versionName = spec.versionName,
                packageName = spec.packageName,
                targetAbi = effectiveAbi,
                deviceSupportedAbis = activeTelemetry.supportedAbis,
                sourceType = if (pkgInstalled != null) ProfileSourceType.INSTALLED_PACKAGE else ProfileSourceType.INTERNAL_CACHE,
                isCustomInstance = true,
                installedNativeLibDir = pkgInstalled?.nativeLibraryDir
            ).copy(
                isInstalledOnDevice = pkgInstalled != null,
                installedVersionName = pkgInstalled?.versionName
            )
        }

        val knownPackages = setOf(
            "com.mojang.minecraftpe.preview",
            "com.mojang.minecraftpe",
            "com.mojang.minecraftpe.beta",
            "com.mojang.minecrafttrialpe"
        ) + customSpecs.map { it.packageName }.toSet()

        val discoveredExtraProfiles = activeTelemetry.installedEditions
            .filter { it.packageName !in knownPackages }
            .map { installed ->
                val autoId = "detected_${installed.packageName.replace('.', '_')}"
                cacheManager.ensureIsolatedSandbox(autoId)
                cacheManager.inspectProfileCache(
                    profileId = autoId,
                    displayName = "${installed.appLabel} (${installed.versionName})",
                    versionName = installed.versionName,
                    packageName = installed.packageName,
                    targetAbi = effectiveAbi,
                    deviceSupportedAbis = activeTelemetry.supportedAbis,
                    sourceType = ProfileSourceType.INSTALLED_PACKAGE,
                    isCustomInstance = false,
                    installedNativeLibDir = installed.nativeLibraryDir
                ).copy(
                    isInstalledOnDevice = true,
                    installedVersionName = installed.versionName
                )
            }

        _uiState.update {
            it.copy(
                isInitializing = false,
                telemetry = activeTelemetry,
                profiles = listOf(previewProfile, fullProfile) + extraStandardProfiles + discoveredExtraProfiles + customProfiles
            )
        }
    }

    fun selectProfile(profileId: String) {
        viewModelScope.launch {
            prefsRepo.setSelectedProfile(profileId)
            val sandbox = cacheManager.ensureIsolatedSandbox(profileId)
            val targetPkg = _uiState.value.profiles.firstOrNull { it.id == profileId }?.packageName
            val splitsReport = if (targetPkg != null) {
                cacheManager.inspectInstalledMinecraftSplits(targetPkg)
            } else null
            _uiState.update {
                it.copy(
                    activeSandbox = sandbox,
                    installedSplitsReport = splitsReport ?: it.installedSplitsReport
                )
            }
        }
    }

    fun createCustomIsolatedInstance(
        displayName: String,
        versionName: String,
        packageName: String
    ) {
        val cleanName = displayName.trim().ifEmpty { "Bedrock Preview Custom" }
        val cleanVersion = versionName.trim().ifEmpty { "1.26.70.24" }
        val cleanPkg = packageName.trim().ifEmpty { "com.mojang.minecraftpe.preview" }
        val id = "isolated_${System.currentTimeMillis()}"

        viewModelScope.launch {
            val spec = CustomProfileSpec(
                id = id,
                displayName = cleanName,
                versionName = cleanVersion,
                packageName = cleanPkg,
                isolatedDataEnabled = true
            )
            cacheManager.ensureIsolatedSandbox(id, isolatedEnabled = true)
            prefsRepo.addCustomProfile(spec)
            _uiState.update {
                it.copy(
                    statusBanner = if (it.language == AppLanguage.AR) {
                        "تمت إضافة ملف الحزمة: $cleanName ($cleanPkg). استخرج المكتبات الحقيقية قبل التحقق."
                    } else {
                        "Added profile: $cleanName ($cleanPkg). Extract real libraries to verify."
                    }
                )
            }
        }
    }

    fun deleteCustomInstance(profileId: String) {
        viewModelScope.launch {
            prefsRepo.removeCustomProfile(profileId)
            _uiState.update {
                it.copy(
                    statusBanner = if (it.language == AppLanguage.AR) {
                        "تم حذف الملف المخصص."
                    } else {
                        "Removed custom profile."
                    }
                )
            }
        }
    }

    fun updateSandboxOptions(
        playerName: String,
        isolatedEnabled: Boolean,
        gfxVsync: Boolean,
        devEnableProfiler: Boolean,
        devShowChunkMap: Boolean,
        maxFramerate: Int,
        gfxViewDistance: Int = 12
    ) {
        val profileId = _uiState.value.selectedProfileId
        viewModelScope.launch {
            val updated = cacheManager.updateSandboxOptions(
                profileId = profileId,
                playerName = playerName,
                isolatedEnabled = isolatedEnabled,
                gfxVsync = gfxVsync,
                devEnableProfiler = devEnableProfiler,
                devShowChunkMap = devShowChunkMap,
                maxFramerate = maxFramerate,
                gfxViewDistance = gfxViewDistance
            )
            _uiState.update { it.copy(activeSandbox = updated) }
        }
    }

    fun setTargetAbiOverride(abi: String) {
        viewModelScope.launch {
            prefsRepo.setTargetAbiOverride(abi)
        }
    }

    fun setLanguage(language: AppLanguage) {
        viewModelScope.launch {
            prefsRepo.setLanguage(language)
        }
    }

    fun setLaunchInsideTask(enabled: Boolean) {
        viewModelScope.launch {
            prefsRepo.setLaunchInsideTask(enabled)
        }
    }

    fun setAutoSyncOptionsOnLaunch(enabled: Boolean) {
        viewModelScope.launch {
            prefsRepo.setAutoSyncOptionsOnLaunch(enabled)
        }
    }

    fun inspectArchive(uri: Uri) {
        lastInspectedArchiveUri = uri
        viewModelScope.launch {
            _uiState.update { it.copy(isInspectingApk = true) }
            val abis = _uiState.value.telemetry?.supportedAbis ?: listOf("arm64-v8a")
            val result = cacheManager.inspectArchiveUri(uri, abis)
            _uiState.update {
                it.copy(
                    isInspectingApk = false,
                    apkInspectionResult = result
                )
            }
        }
    }

    fun importModFromUri(uri: Uri) {
        val state = _uiState.value
        val profileId = state.selectedProfileId
        val abi = state.effectiveTargetAbi
        viewModelScope.launch {
            val imported = cacheManager.inspectAndStageModUri(uri, profileId, abi)
            if (imported != null) {
                prefsRepo.addCustomMod(imported)
                val updatedSandbox = cacheManager.ensureIsolatedSandbox(profileId)
                _uiState.update {
                    it.copy(
                        activeSandbox = updatedSandbox,
                        statusBanner = if (state.language == AppLanguage.AR) {
                            "تم استيراد ${imported.name} وفحصه بنجاح."
                        } else {
                            "Imported and verified ${imported.name}."
                        }
                    )
                }
            } else {
                _uiState.update {
                    it.copy(
                        statusBanner = if (state.language == AppLanguage.AR) {
                            "فشل استيراد الملف أو أنه ليس ملف ELF/.mcpack صالحاً."
                        } else {
                            "Failed to import file (invalid ELF/.mcpack or unreadable)."
                        }
                    )
                }
            }
        }
    }

    fun refreshInstalledSplits(preferredPackage: String? = null) {
        viewModelScope.launch {
            _uiState.update { it.copy(isScanningSplits = true) }
            val extraPkgs = latestPrefs.customProfiles.map { it.packageName }
            val telemetry = cacheManager.collectDeviceTelemetry(extraPkgs)
            val pkg = preferredPackage ?: _uiState.value.selectedProfile?.packageName
            val splitsReport = cacheManager.inspectInstalledMinecraftSplits(pkg)
            _uiState.update {
                it.copy(
                    isScanningSplits = false,
                    telemetry = telemetry,
                    installedSplitsReport = splitsReport
                )
            }
            refreshProfiles(telemetry, _uiState.value.targetAbiOverride)
        }
    }

    fun applyInspectedArchiveToCache() {
        val state = _uiState.value
        val profile = state.selectedProfile ?: return
        val archiveUri = lastInspectedArchiveUri ?: return

        viewModelScope.launch {
            _uiState.update { it.copy(isExtractingRealLib = true) }
            val result = cacheManager.extractRealLibsFromArchiveUri(
                uri = archiveUri,
                profileId = profile.id,
                targetAbi = state.effectiveTargetAbi
            )
            refreshProfiles(state.telemetry, state.targetAbiOverride)
            _uiState.update {
                it.copy(
                    isExtractingRealLib = false,
                    statusBanner = if (result.success && result.mainLib != null) {
                        val mb = result.mainLib.uncompressedSize / (1024.0 * 1024.0)
                        if (state.language == AppLanguage.AR) {
                            "تم استخراج ${result.extractedFiles.size} مكتبة حقيقية (${"%.1f".format(Locale.US, mb)} MB) عبر ملف مؤقت وإعادة تسمية."
                        } else {
                            "Extracted ${result.extractedFiles.size} real libs (${"%.1f".format(Locale.US, mb)} MB) via temp+rename."
                        }
                    } else {
                        if (state.language == AppLanguage.AR) {
                            "فشل الاستخراج: ${result.failureMessage}"
                        } else {
                            "Extraction failed: ${result.failureMessage}"
                        }
                    }
                )
            }
        }
    }

    fun syncCacheFromInstalledPackage() {
        val state = _uiState.value
        val profile = state.selectedProfile ?: return
        val targetAbi = state.effectiveTargetAbi
        viewModelScope.launch {
            _uiState.update { it.copy(isExtractingRealLib = true) }
            val extraPkgs = latestPrefs.customProfiles.map { it.packageName }
            val telemetry = cacheManager.collectDeviceTelemetry(extraPkgs)
            val installedPkg = telemetry.installedEditions.firstOrNull { it.packageName == profile.packageName }

            val result = if (installedPkg != null) {
                cacheManager.extractRealLibsFromInstalledPackage(
                    profileId = profile.id,
                    packageName = installedPkg.packageName,
                    targetAbi = targetAbi
                )
            } else null

            refreshProfiles(telemetry, state.targetAbiOverride)
            _uiState.update {
                it.copy(
                    isExtractingRealLib = false,
                    statusBanner = when {
                        installedPkg == null -> if (state.language == AppLanguage.AR) {
                            "الحزمة ${profile.packageName} غير مثبتة على الجهاز — تعذّر الاستخراج."
                        } else {
                            "Package ${profile.packageName} is not installed — cannot extract."
                        }
                        result?.success == true && result.mainLib != null -> {
                            val mb = result.mainLib.uncompressedSize / (1024.0 * 1024.0)
                            if (state.language == AppLanguage.AR) {
                                "تم استخراج ${result.extractedFiles.size} مكتبة حقيقية (${"%.1f".format(Locale.US, mb)} MB • ${result.mainLib.elfArchLabel}) عبر temp+rename."
                            } else {
                                "Extracted ${result.extractedFiles.size} real libs (${"%.1f".format(Locale.US, mb)} MB • ${result.mainLib.elfArchLabel}) via temp+rename."
                            }
                        }
                        else -> if (state.language == AppLanguage.AR) {
                            "فشل استخراج المكتبات الحقيقية: ${result?.failureMessage ?: "خطأ غير معروف"}"
                        } else {
                            "Real library extraction failed: ${result?.failureMessage ?: "Unknown error"}"
                        }
                    }
                )
            }
        }
    }

    fun selectAndBindInstalledPackage(packageName: String) {
        viewModelScope.launch {
            val matching = _uiState.value.profiles.firstOrNull { it.packageName == packageName }
            if (matching != null) {
                selectProfile(matching.id)
            } else {
                val installed = _uiState.value.telemetry?.installedEditions?.firstOrNull { it.packageName == packageName }
                createCustomIsolatedInstance(
                    displayName = installed?.appLabel ?: "Installed Bedrock",
                    versionName = installed?.versionName ?: "1.26.70.24",
                    packageName = packageName
                )
            }
        }
    }

    fun runPackageProbe(packageName: String? = null) {
        val state = _uiState.value
        val targetPkg = packageName?.takeIf { it.isNotBlank() }
            ?: state.selectedProfile?.packageName
            ?: "com.mojang.minecraftpe.preview"
        viewModelScope.launch {
            _uiState.update { it.copy(isProbingPackage = true) }
            val profile = state.profiles.firstOrNull { it.packageName == targetPkg } ?: state.selectedProfile
            val cachedPath = profile?.cachePath
            val report = probeManager.probePackage(
                packageName = targetPkg,
                cachedLibPath = cachedPath
            )
            _uiState.update {
                it.copy(
                    isProbingPackage = false,
                    probeReport = report
                )
            }
        }
    }

    fun connectToBedrockServer(
        host: String,
        port: Int,
        launchStarter: ((Intent) -> Boolean)? = null
    ) {
        val cleanHost = host.trim()
        if (cleanHost.isEmpty()) return
        val state = _uiState.value
        val targetPkg = state.selectedProfile?.takeIf { it.isInstalledOnDevice }?.packageName
            ?: state.telemetry?.installedMinecraftPackage?.packageName
        val insideTask = state.launchInsideTask && launchStarter != null
        val intent = cacheManager.createServerConnectIntent(
            packageName = targetPkg,
            host = cleanHost,
            port = port,
            insideCurrentTask = insideTask
        )
        val launched = if (insideTask) {
            launchStarter!!.invoke(intent)
        } else {
            try {
                getApplication<Application>().startActivity(intent)
                true
            } catch (_: Exception) {
                false
            }
        }
        if (!launched) {
            _uiState.update {
                it.copy(
                    statusBanner = if (state.language == AppLanguage.AR) {
                        "تعذّر فتح ماينكرافت عبر رابط السيرفر minecraft://connect."
                    } else {
                        "Unable to open Minecraft with minecraft://connect URI."
                    }
                )
            }
        }
    }

    fun addSavedServer(name: String, host: String, port: Int) {
        val cleanHost = host.trim()
        if (cleanHost.isEmpty()) return
        val cleanName = name.trim().ifEmpty { cleanHost }
        viewModelScope.launch {
            prefsRepo.addSavedServer(
                BedrockServerPreset(
                    id = "srv_${System.currentTimeMillis()}",
                    name = cleanName,
                    host = cleanHost,
                    port = port.coerceIn(1, 65535)
                )
            )
        }
    }

    fun removeSavedServer(serverId: String) {
        viewModelScope.launch {
            prefsRepo.removeSavedServer(serverId)
            _uiState.update {
                it.copy(serverPingStatuses = it.serverPingStatuses - serverId)
            }
        }
    }

    fun pingServer(serverId: String, host: String, port: Int) {
        viewModelScope.launch {
            _uiState.update {
                it.copy(serverPingStatuses = it.serverPingStatuses + (serverId to ServerPingStatus(isPinging = true)))
            }
            val result = BedrockRakNetPinger.pingServer(host, port)
            val status = ServerPingStatus(
                isPinging = false,
                isOnline = result.isOnline,
                latencyMs = result.latencyMs,
                motd = result.motd,
                gameVersion = result.gameVersion,
                playerCount = result.playerCount,
                maxPlayers = result.maxPlayers,
                worldName = result.worldName,
                gameMode = result.gameMode,
                error = result.errorMessage
            )
            _uiState.update {
                it.copy(serverPingStatuses = it.serverPingStatuses + (serverId to status))
            }
        }
    }

    fun addExternalServerToMinecraft(name: String, host: String, port: Int) {
        val cleanHost = host.trim()
        if (cleanHost.isEmpty()) return
        val state = _uiState.value
        val targetPkg = state.selectedProfile?.takeIf { it.isInstalledOnDevice }?.packageName
            ?: state.telemetry?.installedMinecraftPackage?.packageName
        val intent = cacheManager.createAddExternalServerIntent(targetPkg, name, cleanHost, port)
        try {
            getApplication<Application>().startActivity(intent)
        } catch (_: Exception) {
            _uiState.update {
                it.copy(
                    statusBanner = if (state.language == AppLanguage.AR) {
                        "تعذّر إرسال السيرفر إلى ماينكرافت عبر addExternalServer."
                    } else {
                        "Unable to open Minecraft addExternalServer link."
                    }
                )
            }
        }
    }

    fun linkMojangSafTree(uri: Uri) {
        viewModelScope.launch {
            _uiState.update { it.copy(isSyncingSafTree = true) }
            runCatching {
                getApplication<Application>().contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            }
            val summary = safStorageManager.inspectLinkedTree(uri)
            if (summary != null) {
                prefsRepo.setLinkedMojangTreeUri(uri.toString())
                _uiState.update { state ->
                    state.copy(
                        isSyncingSafTree = false,
                        linkedMojangSummary = summary,
                        statusBanner = if (state.language == AppLanguage.AR) {
                            "تم ربط مجلد ${summary.folderDisplayName}: ${summary.worldsCount} عوالم، ${summary.resourcePacksCount} موارد، ${summary.behaviorPacksCount} سلوك."
                        } else {
                            "Linked ${summary.folderDisplayName}: ${summary.worldsCount} worlds, ${summary.resourcePacksCount} RP, ${summary.behaviorPacksCount} BP."
                        }
                    )
                }
            } else {
                _uiState.update { state ->
                    state.copy(
                        isSyncingSafTree = false,
                        statusBanner = if (state.language == AppLanguage.AR) {
                            "تعذّر قراءة محتويات المجلد المحدد."
                        } else {
                            "Unable to read selected folder."
                        }
                    )
                }
            }
        }
    }

    fun unlinkMojangSafTree() {
        viewModelScope.launch {
            prefsRepo.setLinkedMojangTreeUri(null)
            _uiState.update { it.copy(linkedMojangSummary = null) }
        }
    }

    fun syncOptionsToLinkedSafTree() {
        val state = _uiState.value
        val summary = state.linkedMojangSummary ?: return
        val sandbox = state.activeSandbox ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isSyncingSafTree = true) }
            val ok = performOptionsSyncToSaf(summary, sandbox)
            val refreshedSummary = safStorageManager.inspectLinkedTree(Uri.parse(summary.treeUriString))
            _uiState.update {
                it.copy(
                    isSyncingSafTree = false,
                    linkedMojangSummary = refreshedSummary ?: it.linkedMojangSummary,
                    statusBanner = if (state.language == AppLanguage.AR) {
                        if (ok) "تمت مزامنة options.txt الحقيقي داخل مجلد ماينكرافت بنجاح."
                        else "فشلت الكتابة إلى options.txt (تحقق من صلاحية المجلد)."
                    } else {
                        if (ok) "Synced settings into real Minecraft options.txt."
                        else "Failed to write options.txt (check folder write permission)."
                    }
                )
            }
        }
    }

    private suspend fun performOptionsSyncToSaf(
        summary: SafMojangTreeSummary,
        sandbox: IsolatedSandboxConfig
    ): Boolean {
        val targetUri = safStorageManager.ensureOrCreateOptionsTxtUri(summary) ?: return false
        val existing = safStorageManager.readOptionsFromSafUri(targetUri).toMutableMap()
        existing["mp_username"] = sandbox.playerName
        existing["gfx_vsync"] = if (sandbox.gfxVsync) "1" else "0"
        existing["gfx_max_framerate"] = sandbox.maxFramerate.toString()
        existing["gfx_viewdistance"] = sandbox.gfxViewDistance.toString()
        existing["dev_enable_profiler"] = if (sandbox.devEnableProfiler) "1" else "0"
        existing["dev_show_chunk_map"] = if (sandbox.devShowChunkMap) "1" else "0"
        val formatted = existing.entries.joinToString("\n", postfix = "\n") { "${it.key}:${it.value}" }
        return safStorageManager.writeOptionsToSafUri(targetUri, formatted)
    }

    fun sendPackToMinecraft(mod: ModItem) {
        val state = _uiState.value
        val path = mod.stagedFilePath ?: return
        val targetPkg = state.selectedProfile?.takeIf { it.isInstalledOnDevice }?.packageName
            ?: state.telemetry?.installedMinecraftPackage?.packageName
        val intent = cacheManager.createOpenPackIntent(path, targetPkg)
        if (intent != null) {
            try {
                getApplication<Application>().startActivity(intent)
            } catch (_: Exception) {
                val fallback = cacheManager.createOpenPackIntent(path, null)
                try {
                    if (fallback != null) {
                        getApplication<Application>().startActivity(fallback)
                    }
                } catch (_: Exception) {
                    _uiState.update {
                        it.copy(
                            statusBanner = if (state.language == AppLanguage.AR) {
                                "لا يوجد تطبيق ماينكرافت مثبت يستقبل ملفات .mcpack/.mcaddon."
                            } else {
                                "No installed Minecraft APK available to receive this pack."
                            }
                        )
                    }
                }
            }
        }
    }

    fun repairSelectedProfileCache() {
        syncCacheFromInstalledPackage()
    }

    fun clearSelectedProfileCache() {
        val state = _uiState.value
        val profile = state.selectedProfile ?: return
        val targetAbi = state.effectiveTargetAbi
        viewModelScope.launch {
            cacheManager.clearProfileCacheForAbi(profile.id, targetAbi)
            refreshProfiles(state.telemetry, state.targetAbiOverride)
            _uiState.update {
                it.copy(
                    statusBanner = if (state.language == AppLanguage.AR) {
                        "تم مسح كاش $targetAbi."
                    } else {
                        "Cleared $targetAbi cache."
                    }
                )
            }
        }
    }

    fun toggleMod(modId: String) {
        viewModelScope.launch {
            val currentMods = _uiState.value.mods
            val updated = currentMods.map {
                if (it.id == modId) it.copy(enabled = !it.enabled) else it
            }
            _uiState.update { it.copy(mods = updated) }
            val disabledIds = updated.filter { !it.enabled }.map { it.id }.toSet()
            prefsRepo.setDisabledModIds(disabledIds)
        }
    }

    fun moveModOrder(modId: String, delta: Int) {
        val sorted = _uiState.value.mods.sortedBy { it.loadOrder }.toMutableList()
        val index = sorted.indexOfFirst { it.id == modId }
        if (index == -1) return
        val targetIndex = (index + delta).coerceIn(0, sorted.lastIndex)
        if (index == targetIndex) return
        val item = sorted.removeAt(index)
        sorted.add(targetIndex, item)
        val reindexed = sorted.mapIndexed { idx, mod -> mod.copy(loadOrder = idx + 1) }
        _uiState.update { it.copy(mods = reindexed) }
        viewModelScope.launch {
            prefsRepo.setModOrderIds(reindexed.map { it.id })
        }
    }

    fun removeMod(modId: String) {
        val target = _uiState.value.mods.firstOrNull { it.id == modId } ?: return
        if (!target.isCustomAdded) return
        viewModelScope.launch {
            cacheManager.deleteStagedFile(target.stagedFilePath)
            prefsRepo.removeCustomMod(modId)
        }
    }

    fun dismissStatusBanner() {
        _uiState.update { it.copy(statusBanner = null) }
    }

    fun buildShareableDiagnosticReport(): String {
        val state = _uiState.value
        return cacheManager.buildDiagnosticReport(
            telemetry = state.telemetry,
            profile = state.selectedProfile,
            sandbox = state.activeSandbox,
            session = state.launchSession,
            linkedSafSummary = state.linkedMojangSummary
        )
    }

    // Launches the strict 3-stage pipeline:
    // Stage A: Real ELF (>1MB) & DT_NEEDED library verification/extraction
    // Stage B: Launch installed APK via getLaunchIntentForPackage
    // Stage C: In-process load test via createPackageContext(CONTEXT_INCLUDE_CODE) + ordered System.load
    fun startThreeStageLaunch(
        launchStarter: ((Intent) -> Boolean)? = null,
        runStageA: Boolean = true,
        runStageB: Boolean = true,
        runStageC: Boolean = true
    ) {
        launchJob?.cancel()
        launchJob = viewModelScope.launch {
            val startTime = System.currentTimeMillis()
            val state = _uiState.value
            val extraPkgs = latestPrefs.customProfiles.map { it.packageName }
            val telemetry = cacheManager.collectDeviceTelemetry(extraPkgs)
            val profile = state.selectedProfile
            val profileId = profile?.id ?: state.selectedProfileId
            val targetAbi = if (state.targetAbiOverride == "AUTO") telemetry.primaryAbi else state.targetAbiOverride
            val targetPackageName = profile?.packageName ?: "com.mojang.minecraftpe.preview"
            val sandbox = cacheManager.ensureIsolatedSandbox(profileId)
            val enabledMods = state.mods.filter { it.enabled }.sortedBy { it.loadOrder }

            val stages = LaunchStageId.entries.map { id ->
                val existing = state.launchSession.stages.firstOrNull { it.stageId == id }
                if (runStageA && runStageB && runStageC) {
                    LaunchStageStep(id, StageState.PENDING)
                } else {
                    existing ?: LaunchStageStep(id, StageState.PENDING)
                }
            }.toMutableList()

            val logs = if (runStageA && runStageB && runStageC) {
                withContext(Dispatchers.IO) {
                    launchLogger.startNewSession("3-Stage Launch for $targetPackageName ($targetAbi)")
                    launchLogger.readPersistedEntries().toMutableList()
                }
            } else {
                state.launchSession.logs.toMutableList()
            }

            var currentProgress = 0.05f
            var currentRunning = true
            var currentFailure: FailureReason? = null

            fun publish(
                isRunning: Boolean = currentRunning,
                progress: Float = currentProgress,
                failedReason: FailureReason? = currentFailure
            ) {
                currentRunning = isRunning
                currentProgress = progress
                currentFailure = failedReason
                _uiState.update {
                    it.copy(
                        telemetry = telemetry,
                        activeSandbox = sandbox,
                        launchSession = LaunchSessionState(
                            isRunning = isRunning,
                            progress = progress,
                            stages = stages.toList(),
                            logs = logs.toList(),
                            failedReason = failedReason,
                            elapsedMs = System.currentTimeMillis() - startTime,
                            targetPackageName = targetPackageName,
                            persistedLogPath = launchLogger.latestLogFile.absolutePath,
                            crashRecoveryNote = null
                        )
                    )
                }
            }

            fun logAndFlush(level: LogLevel, stageTag: String, msg: String) {
                val entry = launchLogger.append(level, stageTag, msg)
                logs.add(entry)
                publish()
            }

            fun setStage(id: LaunchStageId, st: StageState, detail: String = "", errorDetail: String? = null) {
                val idx = stages.indexOfFirst { it.stageId == id }
                if (idx >= 0) {
                    stages[idx] = LaunchStageStep(id, st, detail, errorDetail)
                }
            }

            var stageAFailed = false
            var latestFailure: FailureReason? = null

            // ---------------- STAGE A: Real Library Verification ----------------
            if (runStageA) {
                setStage(LaunchStageId.STAGE_A_VERIFY_LIB, StageState.RUNNING, "Inspecting $targetPackageName")
                logAndFlush(LogLevel.INFO, "STAGE-A", "Starting Stage A: Real library verification for $targetPackageName (ABI=$targetAbi, supported=${telemetry.supportedAbis.joinToString()})")
                publish(isRunning = true, progress = 0.12f)

                if (targetAbi !in telemetry.supportedAbis) {
                    val errMsg = "Target ABI '$targetAbi' is not supported by device (${telemetry.supportedAbis.joinToString()})"
                    logAndFlush(LogLevel.ERROR, "STAGE-A", errMsg)
                    val reason = FailureReason.AbiMismatch(telemetry.primaryAbi, targetAbi)
                    setStage(LaunchStageId.STAGE_A_VERIFY_LIB, StageState.FAILED, targetAbi, errMsg)
                    latestFailure = reason
                    stageAFailed = true
                    publish(isRunning = false, progress = 0.33f, failedReason = reason)
                } else {
                    val conflictingMods = enabledMods.filter {
                        it.requiredAbi != "universal" && it.requiredAbi != targetAbi
                    }
                    if (conflictingMods.isNotEmpty()) {
                        val errMsg = "Imported native mod ABI mismatch: ${conflictingMods.joinToString { "${it.name} (${it.requiredAbi})" }} != $targetAbi"
                        logAndFlush(LogLevel.ERROR, "STAGE-A", errMsg)
                        val reason = FailureReason.ModConflict(conflictingMods.map { it.name }, targetAbi)
                        setStage(LaunchStageId.STAGE_A_VERIFY_LIB, StageState.FAILED, "Mod ABI conflict", errMsg)
                        latestFailure = reason
                        stageAFailed = true
                        publish(isRunning = false, progress = 0.33f, failedReason = reason)
                    } else {
                        val pkgInstalled = telemetry.installedEditions.firstOrNull { it.packageName == targetPackageName }
                        if (pkgInstalled != null) {
                            logAndFlush(
                                LogLevel.INFO,
                                "STAGE-A",
                                "PackageManager: v${pkgInstalled.versionName} | sourceDir=${pkgInstalled.sourceDir} | splits=${pkgInstalled.splitSourceDirs.size} | nativeLibraryDir=${pkgInstalled.nativeLibraryDir}"
                            )
                        } else {
                            logAndFlush(LogLevel.WARN, "STAGE-A", "Package '$targetPackageName' not found on device via PackageManager.")
                        }

                        var inspectedProfile = cacheManager.inspectProfileCache(
                            profileId = profileId,
                            displayName = profile?.displayName ?: targetPackageName,
                            versionName = pkgInstalled?.versionName ?: profile?.versionName.orEmpty(),
                            packageName = targetPackageName,
                            targetAbi = targetAbi,
                            deviceSupportedAbis = telemetry.supportedAbis,
                            sourceType = profile?.sourceType ?: ProfileSourceType.INSTALLED_PACKAGE,
                            isCustomInstance = profile?.isCustomInstance ?: false,
                            installedNativeLibDir = pkgInstalled?.nativeLibraryDir
                        )

                        if (inspectedProfile.cacheStatus != CacheHealthStatus.VERIFIED && pkgInstalled != null) {
                            logAndFlush(LogLevel.INFO, "STAGE-A", "Not present directly in nativeLibraryDir and cache unverified (${inspectedProfile.verificationNote}); extracting lib/<abi> .so via temp file + rename...")
                            publish(isRunning = true, progress = 0.22f)
                            val extractRes = cacheManager.extractRealLibsFromInstalledPackage(
                                profileId = profileId,
                                packageName = pkgInstalled.packageName,
                                targetAbi = targetAbi
                            )
                            if (extractRes.success) {
                                logAndFlush(
                                    LogLevel.SUCCESS,
                                    "STAGE-A",
                                    "Prepared ${extractRes.extractedFiles.size} .so files across ABIs [${extractRes.extractedAbis.joinToString()}]: ${extractRes.extractedFiles.joinToString()}"
                                )
                            } else {
                                logAndFlush(LogLevel.ERROR, "STAGE-A", "Extraction failed: ${extractRes.failureMessage}")
                            }
                            inspectedProfile = cacheManager.inspectProfileCache(
                                profileId = profileId,
                                displayName = profile?.displayName ?: targetPackageName,
                                versionName = pkgInstalled.versionName,
                                packageName = targetPackageName,
                                targetAbi = targetAbi,
                                deviceSupportedAbis = telemetry.supportedAbis,
                                sourceType = ProfileSourceType.INSTALLED_PACKAGE,
                                isCustomInstance = profile?.isCustomInstance ?: false,
                                installedNativeLibDir = pkgInstalled.nativeLibraryDir
                            )
                            refreshProfiles(telemetry, state.targetAbiOverride)
                        }

                        val libFile = File(inspectedProfile.cachePath)
                        if (inspectedProfile.cacheStatus == CacheHealthStatus.VERIFIED &&
                            inspectedProfile.hasRealElfBinary &&
                            libFile.exists() &&
                            libFile.length() > ElfBinaryInspector.MIN_VERIFIED_LIB_BYTES
                        ) {
                            val mb = libFile.length() / (1024.0 * 1024.0)
                            logAndFlush(
                                LogLevel.SUCCESS,
                                "STAGE-A",
                                "Verified real ELF: ${libFile.absolutePath} (${"%.2f".format(Locale.US, mb)} MB = ${libFile.length()} B, ${inspectedProfile.elfArchLabel}, 16KB=${inspectedProfile.is16KbAligned})"
                            )
                            val loadPlan = withContext(Dispatchers.IO) {
                                ElfBinaryInspector.resolveTopologicalLoadOrder(libFile.parentFile!!, "libminecraftpe.so")
                            }
                            logAndFlush(
                                LogLevel.INFO,
                                "STAGE-A",
                                "ELF DT_NEEDED (${inspectedProfile.neededLibraries.size}): ${inspectedProfile.neededLibraries.joinToString()}"
                            )
                            val localPlanSummary = loadPlan.joinToString(" -> ") { dep ->
                                if (dep.localFilePath != null) "${dep.libraryName}[local]" else "${dep.libraryName}[sys]"
                            }
                            logAndFlush(LogLevel.INFO, "STAGE-A", "Resolved dependency load order: $localPlanSummary")

                            if (state.autoSyncOptionsOnLaunch && state.linkedMojangSummary != null) {
                                val synced = performOptionsSyncToSaf(state.linkedMojangSummary, sandbox)
                                logAndFlush(
                                    if (synced) LogLevel.SUCCESS else LogLevel.WARN,
                                    "STAGE-A",
                                    if (synced) "Synced options.txt to linked SAF tree." else "SAF options.txt not writable; skipped sync."
                                )
                            }

                            setStage(
                                LaunchStageId.STAGE_A_VERIFY_LIB,
                                StageState.PASSED,
                                "${"%.1f".format(Locale.US, mb)} MB ELF • ${inspectedProfile.neededLibraries.size} DT_NEEDED"
                            )
                            publish(isRunning = true, progress = 0.38f)
                        } else {
                            val errMsg = inspectedProfile.verificationNote.ifBlank {
                                "No valid ELF libminecraftpe.so (> 1 MB) found in cache for $targetAbi."
                            }
                            logAndFlush(LogLevel.ERROR, "STAGE-A", "Stage A failed: $errMsg")
                            val reason = FailureReason.MissingMinecraftPeLib(
                                expectedPath = inspectedProfile.cachePath,
                                expectedAbi = targetAbi,
                                availableAbisInCache = inspectedProfile.availableCachedAbis,
                                reasonDetail = errMsg
                            )
                            setStage(LaunchStageId.STAGE_A_VERIFY_LIB, StageState.FAILED, "Not verified", errMsg)
                            latestFailure = reason
                            stageAFailed = true
                            publish(isRunning = false, progress = 0.33f, failedReason = reason)
                        }
                    }
                }
            }

            if (stageAFailed && (runStageB || runStageC)) {
                if (runStageB) setStage(LaunchStageId.STAGE_B_LAUNCH_INSTALLED, StageState.FAILED, "Skipped (Stage A failed)")
                if (runStageC) setStage(LaunchStageId.STAGE_C_IN_PROCESS_LOAD, StageState.FAILED, "Skipped (Stage A failed)")
                publish(isRunning = false, progress = 0.33f, failedReason = latestFailure)
                return@launch
            }

            // ---------------- STAGE B: Launch Installed Game via getLaunchIntentForPackage ----------------
            if (runStageB) {
                setStage(LaunchStageId.STAGE_B_LAUNCH_INSTALLED, StageState.RUNNING, "getLaunchIntentForPackage($targetPackageName)")
                logAndFlush(LogLevel.INFO, "STAGE-B", "Calling PackageManager.getLaunchIntentForPackage(\"$targetPackageName\")...")
                publish(isRunning = true, progress = 0.55f)

                val strictIntent = cacheManager.getStrictLaunchIntentForPackage(targetPackageName)
                if (strictIntent == null) {
                    val errMsg = "getLaunchIntentForPackage(\"$targetPackageName\") returned null (package not installed or no MAIN/LAUNCHER activity)."
                    logAndFlush(LogLevel.ERROR, "STAGE-B", errMsg)
                    val reason = FailureReason.PackageLaunchFailed(targetPackageName, errMsg)
                    setStage(LaunchStageId.STAGE_B_LAUNCH_INSTALLED, StageState.FAILED, "Returned null", errMsg)
                    latestFailure = reason
                } else {
                    if (state.launchInsideTask && launchStarter != null) {
                        strictIntent.flags = strictIntent.flags and Intent.FLAG_ACTIVITY_NEW_TASK.inv()
                    } else {
                        strictIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    logAndFlush(LogLevel.INFO, "STAGE-B", "Resolved launch Intent: component=${strictIntent.component?.flattenToShortString()}, flags=0x${Integer.toHexString(strictIntent.flags)}")
                    val launchError: String? = try {
                        val started = if (state.launchInsideTask && launchStarter != null) {
                            val ok = launchStarter(strictIntent)
                            if (!ok) {
                                logAndFlush(LogLevel.WARN, "STAGE-B", "In-task launch returned false; retrying with FLAG_ACTIVITY_NEW_TASK...")
                                strictIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                getApplication<Application>().startActivity(strictIntent)
                            }
                            true
                        } else {
                            getApplication<Application>().startActivity(strictIntent)
                            true
                        }
                        if (started) null else "Activity startActivity() returned false."
                    } catch (t: Throwable) {
                        "${t.javaClass.simpleName}: ${t.message}"
                    }

                    if (launchError == null) {
                        logAndFlush(LogLevel.SUCCESS, "STAGE-B", "startActivity(launchIntent) succeeded for $targetPackageName.")
                        setStage(LaunchStageId.STAGE_B_LAUNCH_INSTALLED, StageState.PASSED, strictIntent.component?.shortClassName ?: "Launched")
                    } else {
                        logAndFlush(LogLevel.ERROR, "STAGE-B", "startActivity failed: $launchError")
                        val reason = FailureReason.PackageLaunchFailed(targetPackageName, launchError)
                        setStage(LaunchStageId.STAGE_B_LAUNCH_INSTALLED, StageState.FAILED, "Launch error", launchError)
                        latestFailure = reason
                    }
                }
                publish(isRunning = runStageC, progress = 0.68f, failedReason = latestFailure)
            }

            // ---------------- STAGE C: In-Process Load (createPackageContext + System.load) ----------------
            if (runStageC) {
                setStage(LaunchStageId.STAGE_C_IN_PROCESS_LOAD, StageState.RUNNING, "createPackageContext + System.load")
                logAndFlush(LogLevel.INFO, "STAGE-C", "Starting Stage C: In-process load test for $targetPackageName (ABI=$targetAbi)")
                publish(isRunning = true, progress = 0.78f, failedReason = latestFailure)

                withContext(Dispatchers.IO) {
                    val appCtx = getApplication<Application>()
                    var pkgContext: Context? = null
                    var ctxError: String? = null

                    // Step C.1: createPackageContext with CONTEXT_INCLUDE_CODE
                    launchLogger.markPendingRiskyCall("Stage C.1: createPackageContext($targetPackageName, CONTEXT_INCLUDE_CODE)")
                    logAndFlush(LogLevel.INFO, "STAGE-C", "Calling createPackageContext(\"$targetPackageName\", Context.CONTEXT_INCLUDE_CODE)...")
                    try {
                        pkgContext = appCtx.createPackageContext(targetPackageName, Context.CONTEXT_INCLUDE_CODE)
                        logAndFlush(LogLevel.SUCCESS, "STAGE-C", "createPackageContext(CONTEXT_INCLUDE_CODE) succeeded! ClassLoader=${pkgContext.classLoader}")
                    } catch (sec: SecurityException) {
                        val strictMsg = "SecurityException on CONTEXT_INCLUDE_CODE: ${sec.message}"
                        logAndFlush(LogLevel.WARN, "STAGE-C", strictMsg)
                        logAndFlush(LogLevel.INFO, "STAGE-C", "Retrying with CONTEXT_INCLUDE_CODE | CONTEXT_IGNORE_SECURITY...")
                        try {
                            @Suppress("DEPRECATION")
                            pkgContext = appCtx.createPackageContext(
                                targetPackageName,
                                Context.CONTEXT_INCLUDE_CODE or Context.CONTEXT_IGNORE_SECURITY
                            )
                            logAndFlush(
                                LogLevel.INFO,
                                "STAGE-C",
                                "createPackageContext(CONTEXT_INCLUDE_CODE | CONTEXT_IGNORE_SECURITY) returned ClassLoader=${pkgContext.classLoader}"
                            )
                        } catch (t2: Throwable) {
                            ctxError = "Strict: $strictMsg | With IGNORE_SECURITY: ${t2.javaClass.simpleName}: ${t2.message}"
                            logAndFlush(LogLevel.ERROR, "STAGE-C", ctxError)
                        }
                    } catch (t: Throwable) {
                        ctxError = "${t.javaClass.simpleName}: ${t.message}"
                        logAndFlush(LogLevel.ERROR, "STAGE-C", "createPackageContext failed: $ctxError")
                    } finally {
                        launchLogger.clearPendingRiskyCall()
                    }

                    if (pkgContext == null) {
                        val finalErr = ctxError ?: "createPackageContext returned null"
                        setStage(LaunchStageId.STAGE_C_IN_PROCESS_LOAD, StageState.FAILED, "Context failed", finalErr)
                        latestFailure = FailureReason.InProcessLoadFailed(targetPackageName, finalErr)
                    } else {
                        // Step C.2: Load DT_NEEDED dependencies in topological order + libminecraftpe.so via System.load
                        // Prefer direct nativeLibraryDir if present, otherwise extracted cache
                        val pkgInstalled = telemetry.installedEditions.firstOrNull { it.packageName == targetPackageName }
                        val inspectedForLoad = cacheManager.inspectProfileCache(
                            profileId = profileId,
                            displayName = profile?.displayName ?: targetPackageName,
                            versionName = pkgInstalled?.versionName ?: profile?.versionName.orEmpty(),
                            packageName = targetPackageName,
                            targetAbi = targetAbi,
                            deviceSupportedAbis = telemetry.supportedAbis,
                            sourceType = profile?.sourceType ?: ProfileSourceType.INSTALLED_PACKAGE,
                            isCustomInstance = profile?.isCustomInstance ?: false,
                            installedNativeLibDir = pkgInstalled?.nativeLibraryDir
                        )
                        val mainLibFile = File(inspectedForLoad.cachePath)
                        val abiLoadDir = mainLibFile.parentFile ?: File(cacheManager.cacheRootDir, "$profileId/$targetAbi")
                        val mainElf = if (mainLibFile.exists()) ElfBinaryInspector.inspectElfFile(mainLibFile) else null

                        if (!mainLibFile.exists() || mainElf == null || !mainElf.isValidElf || !mainElf.meetsMinSize1Mb) {
                            val errMsg = "Cannot run System.load: verified libminecraftpe.so (> 1 MB ELF) not found in nativeLibraryDir or cache (${mainLibFile.absolutePath})."
                            logAndFlush(LogLevel.ERROR, "STAGE-C", errMsg)
                            setStage(LaunchStageId.STAGE_C_IN_PROCESS_LOAD, StageState.FAILED, "Missing ELF", errMsg)
                            latestFailure = FailureReason.InProcessLoadFailed(targetPackageName, errMsg)
                        } else {
                            logAndFlush(LogLevel.INFO, "STAGE-C", "Using native dir: ${abiLoadDir.absolutePath}")
                            val loadOrder = ElfBinaryInspector.resolveTopologicalLoadOrder(abiLoadDir, "libminecraftpe.so")
                            var loadFailure: String? = null

                            for (dep in loadOrder) {
                                val localPath = dep.localFilePath
                                if (localPath == null) {
                                    logAndFlush(
                                        LogLevel.INFO,
                                        "STAGE-C",
                                        "Dependency ${dep.libraryName} -> system/NDK library (delegated to linker)"
                                    )
                                    continue
                                }
                                launchLogger.markPendingRiskyCall("Stage C.2: System.load($localPath)")
                                logAndFlush(LogLevel.INFO, "STAGE-C", "Calling System.load(\"$localPath\")...")
                                try {
                                    @Suppress("UnsafeDynamicallyLoadedCode")
                                    System.load(localPath)
                                    logAndFlush(LogLevel.SUCCESS, "STAGE-C", "System.load(${dep.libraryName}) succeeded!")
                                } catch (t: Throwable) {
                                    val causeStr = t.cause?.let { " | cause: ${it.javaClass.simpleName}: ${it.message}" }.orEmpty()
                                    val err = "${t.javaClass.simpleName} loading ${dep.libraryName}: ${t.message}$causeStr"
                                    logAndFlush(LogLevel.ERROR, "STAGE-C", err)
                                    loadFailure = err
                                    if (dep.libraryName == "libminecraftpe.so") break
                                } finally {
                                    launchLogger.clearPendingRiskyCall()
                                }
                            }

                            if (loadFailure == null) {
                                logAndFlush(LogLevel.SUCCESS, "STAGE-C", "createPackageContext + System.load(libminecraftpe.so) completed without throwing.")
                                setStage(LaunchStageId.STAGE_C_IN_PROCESS_LOAD, StageState.PASSED, "Loaded in-process")
                            } else {
                                setStage(LaunchStageId.STAGE_C_IN_PROCESS_LOAD, StageState.FAILED, "System.load failed", loadFailure)
                                latestFailure = FailureReason.InProcessLoadFailed(targetPackageName, loadFailure)
                            }
                        }
                    }
                }
            }

            publish(isRunning = false, progress = 1.0f, failedReason = latestFailure)
        }
    }

    fun openPlayStoreForPackage(packageName: String) {
        val intent = cacheManager.createStoreIntent(packageName)
        try {
            getApplication<Application>().startActivity(intent)
        } catch (_: Exception) {
            _uiState.update {
                it.copy(statusBanner = "Unable to open Google Play Store on this device.")
            }
        }
    }

    fun repairCacheAndRetryLaunch(launchStarter: ((Intent) -> Boolean)? = null) {
        val state = _uiState.value
        val profile = state.selectedProfile ?: return
        val targetAbi = state.effectiveTargetAbi
        viewModelScope.launch {
            val extraPkgs = latestPrefs.customProfiles.map { it.packageName }
            val telemetry = cacheManager.collectDeviceTelemetry(extraPkgs)
            val installedPkg = telemetry.installedEditions.firstOrNull { it.packageName == profile.packageName }

            if (installedPkg != null) {
                cacheManager.extractRealLibsFromInstalledPackage(
                    profileId = profile.id,
                    packageName = installedPkg.packageName,
                    targetAbi = targetAbi
                )
            } else if (lastInspectedArchiveUri != null) {
                cacheManager.extractRealLibsFromArchiveUri(
                    uri = lastInspectedArchiveUri!!,
                    profileId = profile.id,
                    targetAbi = targetAbi
                )
            }
            refreshProfiles(telemetry, state.targetAbiOverride)
            startThreeStageLaunch(launchStarter)
        }
    }

    fun reloadPersistedLogFromDisk() {
        viewModelScope.launch(Dispatchers.IO) {
            val entries = launchLogger.readPersistedEntries()
            _uiState.update {
                it.copy(
                    launchSession = it.launchSession.copy(
                        logs = entries,
                        persistedLogPath = launchLogger.latestLogFile.absolutePath
                    )
                )
            }
        }
    }

    fun clearLaunchLog() {
        viewModelScope.launch(Dispatchers.IO) {
            launchLogger.clearLog()
            _uiState.update {
                it.copy(
                    launchSession = it.launchSession.copy(
                        logs = emptyList(),
                        crashRecoveryNote = null,
                        persistedLogPath = launchLogger.latestLogFile.absolutePath
                    )
                )
            }
        }
    }
}

private fun defaultRootCauseGuides(): List<RootCauseGuideItem> = listOf(
    RootCauseGuideItem(
        id = "preview_extract_native_libs",
        titleEn = "Preview v1.26.70.24 Uses Split APKs & extractNativeLibs=false",
        titleAr = "نسخة Preview v1.26.70.24 تستخدم Split APKs و extractNativeLibs=false",
        symptomEn = "Android keeps libminecraftpe.so compressed/stored inside split_config.arm64_v8a.apk and leaves nativeLibraryDir empty.",
        symptomAr = "نظام أندرويد يترك nativeLibraryDir فارغاً ويبقي libminecraftpe.so داخل split_config.arm64_v8a.apk.",
        solutionEn = "Read sourceDir + splitSourceDirs from PackageManager and extract lib/arm64-v8a/*.so via temp file + size check + rename.",
        solutionAr = "اقرأ sourceDir و splitSourceDirs من PackageManager واستخرج كل ملفات lib/arm64-v8a/*.so عبر ملف مؤقت ثم إعادة تسمية.",
        severityTag = "CRITICAL"
    ),
    RootCauseGuideItem(
        id = "in_process_dlopen_limits",
        titleEn = "Why In-Process System.load / createPackageContext Can Fail on Android 13",
        titleAr = "أسباب فشل التحميل داخل العملية (Stage C) على Android 13",
        symptomEn = "Calling System.load on another app's .so from app_data_file or mismatching JNI classes triggers SecurityException, UnsatisfiedLinkError, or JNI_OnLoad failure.",
        symptomAr = "استدعاء System.load على مكتبة خارجية أو اختلاف التوقيع/ClassLoader قد يسبب SecurityException أو UnsatisfiedLinkError أو فشل JNI_OnLoad.",
        solutionEn = "LeviLab records every micro-step to disk with fsync before execution so failures are logged honestly.",
        solutionAr = "يقوم LeviLab بكتابة كل خطوة إلى ملف على الجهاز قبل التنفيذ لعرض السبب الحقيقي بصدق حتى عند الانهيار.",
        severityTag = "HIGH"
    ),
    RootCauseGuideItem(
        id = "dt_needed_order",
        titleEn = "DT_NEEDED Shared Library Preload Order",
        titleAr = "ترتيب تحميل مكتبات DT_NEEDED المرافقة",
        symptomEn = "Loading libminecraftpe.so before libc++_shared.so or libfmod.so fails with dlopen cannot locate symbol/library.",
        symptomAr = "تحميل libminecraftpe.so قبل libc++_shared.so أو libfmod.so يفشل بسبب اعتماديات ELF غير محمّلة.",
        solutionEn = "Parse ELF PT_DYNAMIC DT_NEEDED entries and load companion .so dependencies in topological order first.",
        solutionAr = "افحص قسم DT_NEEDED في ELF وحمّل المكتبات المرافقة بالترتيب الاعتمادي أولاً.",
        severityTag = "HIGH"
    )
)
