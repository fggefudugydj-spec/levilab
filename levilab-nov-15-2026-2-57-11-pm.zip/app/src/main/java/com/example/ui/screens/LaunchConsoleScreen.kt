package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.DeleteSweep
import androidx.compose.material.icons.outlined.FolderZip
import androidx.compose.material.icons.outlined.Healing
import androidx.compose.material.icons.rounded.Build
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.HourglassTop
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Shop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.AppLanguage
import com.example.model.FailureReason
import com.example.model.LaunchStageId
import com.example.model.LogLevel
import com.example.model.StageState
import com.example.ui.LeviStrings
import com.example.ui.LeviUiState
import com.example.ui.components.LeviLeafMark
import com.example.ui.components.StatusPill
import com.example.ui.theme.JetBrainsMonoFamily

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun LaunchConsoleScreen(
    uiState: LeviUiState,
    strings: LeviStrings,
    onBackToLauncher: () -> Unit,
    onRunAllThreeStages: () -> Unit,
    onRunSingleStage: (LaunchStageId) -> Unit,
    onAutoRepairAndRetry: () -> Unit,
    onOpenDiagnostics: () -> Unit,
    onInspectArchiveUri: (Uri) -> Unit,
    onReloadPersistedLog: () -> Unit,
    onClearLog: () -> Unit,
    onOpenPlayStore: (String) -> Unit,
    onShowCopiedFeedback: (String) -> Unit,
    onBuildDiagnosticReport: () -> String,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBackToLauncher)

    val session = uiState.launchSession
    val context = LocalContext.current
    val logListState = rememberLazyListState()

    val archivePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            onInspectArchiveUri(uri)
        }
    }

    LaunchedEffect(session.logs.size) {
        if (session.logs.isNotEmpty()) {
            logListState.animateScrollToItem(session.logs.lastIndex)
        }
    }

    val animatedProgress by animateFloatAsState(
        targetValue = session.progress,
        animationSpec = spring(),
        label = "launch_stage_progress"
    )

    val allPassed = session.stages.all { it.state == StageState.PASSED } && session.failedReason == null
    val anyFailed = session.failedReason != null || session.stages.any { it.state == StageState.FAILED }

    val statusHeadline = when {
        session.isRunning -> strings.launchStartingTitle
        anyFailed -> strings.launchFailedTitle
        allPassed -> strings.launchCompletedTitle
        else -> strings.launchStartingTitle
    }

    val barColor = when {
        anyFailed -> MaterialTheme.colorScheme.error
        allPassed -> MaterialTheme.colorScheme.primary
        else -> MaterialTheme.colorScheme.primary
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 760.dp),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = strings.launchStartingTitle,
                            style = MaterialTheme.typography.displaySmall,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = strings.launchStartingSubtitle,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Spacer(Modifier.width(12.dp))
                    LeviLeafMark(size = 46.dp)
                }
            }

            // Previous Crash Recovery Banner (if a prior run crashed natively mid-step)
            if (!session.crashRecoveryNote.isNullOrBlank()) {
                item {
                    Card(
                        shape = MaterialTheme.shapes.medium,
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, MaterialTheme.colorScheme.error, MaterialTheme.shapes.medium)
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = strings.crashDetectedBannerTitle,
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = session.crashRecoveryNote,
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = JetBrainsMonoFamily,
                                color = MaterialTheme.colorScheme.onErrorContainer
                            )
                        }
                    }
                }
            }

            // Overall Headline & Progress
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = statusHeadline,
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (anyFailed) {
                                MaterialTheme.colorScheme.error
                            } else {
                                MaterialTheme.colorScheme.onBackground
                            }
                        )
                        if (session.elapsedMs > 0L) {
                            Text(
                                text = "${session.elapsedMs} ms",
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = JetBrainsMonoFamily,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    LinearProgressIndicator(
                        progress = { animatedProgress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(50)),
                        color = barColor,
                        trackColor = MaterialTheme.colorScheme.surfaceContainerHigh
                    )

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        StatusPill(
                            text = session.targetPackageName,
                            containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                            contentColor = MaterialTheme.colorScheme.onSurface,
                            leadingDot = false
                        )
                        StatusPill(
                            text = "ABI: ${uiState.effectiveTargetAbi}",
                            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.65f),
                            contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                            leadingDot = false
                        )
                    }
                }
            }

            // 3 Stage Cards (Stage A, Stage B, Stage C) with honest detail & individual Run Step buttons
            items(session.stages, key = { it.stageId.name }) { step ->
                val (title, desc) = when (step.stageId) {
                    LaunchStageId.STAGE_A_VERIFY_LIB -> strings.stageALabel to strings.stageADesc
                    LaunchStageId.STAGE_B_LAUNCH_INSTALLED -> strings.stageBLabel to strings.stageBDesc
                    LaunchStageId.STAGE_C_IN_PROCESS_LOAD -> strings.stageCLabel to strings.stageCDesc
                }
                val (borderColor, badgeBg, badgeFg, icon) = when (step.state) {
                    StageState.PASSED -> listOf(
                        MaterialTheme.colorScheme.primary.copy(alpha = 0.6f),
                        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.65f),
                        MaterialTheme.colorScheme.onPrimaryContainer,
                        Icons.Rounded.CheckCircle
                    )
                    StageState.FAILED -> listOf(
                        MaterialTheme.colorScheme.error.copy(alpha = 0.7f),
                        MaterialTheme.colorScheme.errorContainer,
                        MaterialTheme.colorScheme.onErrorContainer,
                        Icons.Rounded.ErrorOutline
                    )
                    StageState.RUNNING -> listOf(
                        MaterialTheme.colorScheme.secondary,
                        MaterialTheme.colorScheme.secondaryContainer,
                        MaterialTheme.colorScheme.onSecondaryContainer,
                        Icons.Rounded.HourglassTop
                    )
                    StageState.PENDING -> listOf(
                        MaterialTheme.colorScheme.outlineVariant,
                        MaterialTheme.colorScheme.surfaceContainerHigh,
                        MaterialTheme.colorScheme.onSurfaceVariant,
                        Icons.Rounded.HourglassTop
                    )
                }

                @Suppress("UNCHECKED_CAST")
                Card(
                    shape = MaterialTheme.shapes.medium,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, borderColor as androidx.compose.ui.graphics.Color, MaterialTheme.shapes.medium)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(30.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(badgeBg as androidx.compose.ui.graphics.Color),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = icon as androidx.compose.ui.graphics.vector.ImageVector,
                                        contentDescription = null,
                                        tint = badgeFg as androidx.compose.ui.graphics.Color,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Column {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            text = title,
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.SemiBold,
                                            modifier = Modifier.weight(1f, fill = false)
                                        )
                                        if (step.stageId == LaunchStageId.STAGE_C_IN_PROCESS_LOAD) {
                                            StatusPill(
                                                text = strings.experimentalBadge,
                                                containerColor = MaterialTheme.colorScheme.tertiaryContainer,
                                                contentColor = MaterialTheme.colorScheme.onTertiaryContainer,
                                                leadingDot = false
                                            )
                                        }
                                    }
                                    Text(
                                        text = desc,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Spacer(Modifier.width(8.dp))
                            OutlinedButton(
                                onClick = { onRunSingleStage(step.stageId) },
                                enabled = !session.isRunning,
                                modifier = Modifier
                                    .height(48.dp)
                                    .testTag("run_stage_${step.stageId.name.lowercase()}"),
                                shape = MaterialTheme.shapes.small
                            ) {
                                Icon(Icons.Rounded.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text(strings.runStageOnlyCta, style = MaterialTheme.typography.labelMedium)
                            }
                        }

                        if (step.detail.isNotBlank()) {
                            Text(
                                text = step.detail,
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = JetBrainsMonoFamily,
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }
                        if (!step.errorDetail.isNullOrBlank()) {
                            Text(
                                text = step.errorDetail,
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = JetBrainsMonoFamily,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            }

            // Persisted On-Device Log Box
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = strings.launchLogTitle,
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            if (session.persistedLogPath.isNotBlank()) {
                                Text(
                                    text = "${strings.persistedLogPathLabel}: ${session.persistedLogPath}",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontFamily = JetBrainsMonoFamily,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = onReloadPersistedLog,
                                modifier = Modifier
                                    .size(48.dp)
                                    .testTag("reload_disk_log_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Refresh,
                                    contentDescription = "Reload log from disk",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(
                                onClick = onClearLog,
                                modifier = Modifier
                                    .size(48.dp)
                                    .testTag("clear_disk_log_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.DeleteSweep,
                                    contentDescription = strings.clearLogCta,
                                    tint = MaterialTheme.colorScheme.error
                                )
                            }
                            IconButton(
                                onClick = {
                                    val report = onBuildDiagnosticReport()
                                    val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                        type = "text/plain"
                                        putExtra(Intent.EXTRA_SUBJECT, "LeviLab Diagnostic Report")
                                        putExtra(Intent.EXTRA_TEXT, report)
                                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    }
                                    context.startActivity(Intent.createChooser(sendIntent, strings.shareReportCta))
                                },
                                modifier = Modifier
                                    .size(48.dp)
                                    .testTag("share_report_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Share,
                                    contentDescription = strings.shareReportCta,
                                    tint = MaterialTheme.colorScheme.secondary
                                )
                            }
                            IconButton(
                                onClick = {
                                    val text = session.logs.joinToString("\n") {
                                        "[${it.timestamp}] ${it.message}"
                                    }
                                    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    cm.setPrimaryClip(ClipData.newPlainText("LeviLab Launch Log", text))
                                    onShowCopiedFeedback(strings.logCopiedToast)
                                },
                                modifier = Modifier
                                    .size(48.dp)
                                    .testTag("copy_log_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.ContentCopy,
                                    contentDescription = strings.copyLogCta,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }

                    val cursorTransition = rememberInfiniteTransition(label = "terminal_cursor")
                    val cursorAlpha by cursorTransition.animateFloat(
                        initialValue = 1f,
                        targetValue = 0.15f,
                        animationSpec = infiniteRepeatable(
                            animation = tween(durationMillis = 550),
                            repeatMode = RepeatMode.Reverse
                        ),
                        label = "cursor_alpha"
                    )

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(220.dp)
                            .clip(MaterialTheme.shapes.medium)
                            .background(MaterialTheme.colorScheme.surfaceContainerLowest)
                            .border(
                                1.5.dp,
                                if (anyFailed) MaterialTheme.colorScheme.error.copy(alpha = 0.65f)
                                else MaterialTheme.colorScheme.outline,
                                MaterialTheme.shapes.medium
                            )
                            .padding(14.dp)
                    ) {
                        LazyColumn(
                            state = logListState,
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            items(session.logs, key = { it.id }) { entry ->
                                val lineColor = when (entry.level) {
                                    LogLevel.ERROR -> MaterialTheme.colorScheme.error
                                    LogLevel.WARN -> MaterialTheme.colorScheme.tertiary
                                    LogLevel.SUCCESS, LogLevel.FIX -> MaterialTheme.colorScheme.secondary
                                    LogLevel.INFO -> MaterialTheme.colorScheme.onSurface
                                }
                                Text(
                                    text = "[${entry.timestamp}] ${entry.message}",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontFamily = JetBrainsMonoFamily,
                                    color = lineColor
                                )
                            }
                            item(key = "terminal_cursor") {
                                Box(
                                    modifier = Modifier
                                        .padding(top = 2.dp)
                                        .size(width = 7.dp, height = 14.dp)
                                        .background(
                                            MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = cursorAlpha)
                                        )
                                )
                            }
                        }
                    }
                }
            }

            // Honest Failure Report Card
            item {
                val failure = session.failedReason
                AnimatedVisibility(visible = failure != null) {
                    if (failure != null) {
                        val isAr = uiState.language == AppLanguage.AR
                        Card(
                            shape = MaterialTheme.shapes.medium,
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.55f), MaterialTheme.shapes.medium)
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text(
                                    text = strings.recoveryBannerTitle,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.error
                                )

                                val detailMessage = when (failure) {
                                    is FailureReason.MissingMinecraftPeLib -> failure.reasonDetail
                                    is FailureReason.AbiMismatch -> {
                                        if (isAr) {
                                            "المعمارية المختارة (${failure.cachedAbi}) لا يدعمها جهازك (${failure.deviceAbi})."
                                        } else {
                                            "Selected ABI (${failure.cachedAbi}) is not supported on this device (${failure.deviceAbi})."
                                        }
                                    }
                                    is FailureReason.ModConflict -> {
                                        if (isAr) {
                                            "تعارض في معمارية المودات: ${failure.conflictingMods.joinToString()} مع ${failure.targetAbi}."
                                        } else {
                                            "Mod ABI conflict for ${failure.conflictingMods.joinToString()} on ${failure.targetAbi}."
                                        }
                                    }
                                    is FailureReason.PackageLaunchFailed -> {
                                        if (isAr) {
                                            "تعذّر تشغيل الحزمة ${failure.packageName}: ${failure.reasonDetail}"
                                        } else {
                                            "Failed to launch package ${failure.packageName}: ${failure.reasonDetail}"
                                        }
                                    }
                                    is FailureReason.InProcessLoadFailed -> {
                                        if (isAr) {
                                            "فشل التحميل داخل العملية للحزمة ${failure.packageName}: ${failure.reasonDetail}"
                                        } else {
                                            "In-process load failed for ${failure.packageName}: ${failure.reasonDetail}"
                                        }
                                    }
                                }

                                Text(
                                    text = detailMessage,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontFamily = JetBrainsMonoFamily,
                                    color = MaterialTheme.colorScheme.onSurface
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Button(
                                        onClick = onAutoRepairAndRetry,
                                        enabled = !session.isRunning,
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(48.dp)
                                            .testTag("auto_repair_retry_button"),
                                        shape = MaterialTheme.shapes.small
                                    ) {
                                        Icon(Icons.Outlined.Healing, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text(strings.autoRepairAndRetryCta, maxLines = 1)
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    OutlinedButton(
                                        onClick = { archivePickerLauncher.launch(arrayOf("*/*")) },
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(48.dp),
                                        shape = MaterialTheme.shapes.small
                                    ) {
                                        Icon(Icons.Outlined.FolderZip, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text(strings.inspectApkCta, maxLines = 1)
                                    }

                                    OutlinedButton(
                                        onClick = onOpenDiagnostics,
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(48.dp)
                                            .testTag("launch_open_diagnostics_button"),
                                        shape = MaterialTheme.shapes.small
                                    ) {
                                        Icon(Icons.Rounded.Build, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text(strings.openDiagnosticsCta, maxLines = 1)
                                    }
                                }

                                if (failure is FailureReason.PackageLaunchFailed) {
                                    TextButton(
                                        onClick = { onOpenPlayStore(failure.packageName) },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(48.dp)
                                    ) {
                                        Icon(Icons.Rounded.Shop, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text(strings.openOnPlayStoreCta)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Primary Console Actions
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onBackToLauncher,
                        modifier = Modifier
                            .weight(0.75f)
                            .height(50.dp)
                            .testTag("back_to_launcher_button"),
                        shape = MaterialTheme.shapes.medium
                    ) {
                        Text(
                            text = strings.backToLauncherCta,
                            style = MaterialTheme.typography.labelLarge
                        )
                    }

                    Button(
                        onClick = onRunAllThreeStages,
                        enabled = !session.isRunning,
                        modifier = Modifier
                            .weight(1.45f)
                            .height(50.dp)
                            .testTag("retry_preflight_button"),
                        shape = MaterialTheme.shapes.medium,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.PlayArrow,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(
                            text = strings.runAll3StagesCta,
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                }
            }
        }
    }
}
