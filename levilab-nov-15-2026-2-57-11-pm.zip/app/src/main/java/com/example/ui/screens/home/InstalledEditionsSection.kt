package com.example.ui.screens.home

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Launch
import androidx.compose.material.icons.outlined.FolderZip
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.model.AppLanguage
import com.example.ui.LeviStrings
import com.example.ui.LeviUiState
import com.example.ui.components.StatusPill
import com.example.ui.theme.JetBrainsMonoFamily
import java.util.Locale

@Composable
fun InstalledEditionsSection(
    uiState: LeviUiState,
    strings: LeviStrings,
    onRescanPackages: () -> Unit,
    onBindInstalledPackage: (String) -> Unit,
    onLaunchPackageDirect: (String) -> Unit,
    onPickArchiveToInspect: () -> Unit,
    onApplyInspectedArchive: () -> Unit,
    modifier: Modifier = Modifier
) {
    val editions = uiState.telemetry?.installedEditions.orEmpty()
    val selectedProfile = uiState.selectedProfile

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Live Installed Minecraft APKs Scanner Card
        Card(
            shape = MaterialTheme.shapes.medium,
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
            modifier = Modifier
                .fillMaxWidth()
                .border(
                    1.dp,
                    if (editions.isNotEmpty()) MaterialTheme.colorScheme.primary.copy(alpha = 0.55f)
                    else MaterialTheme.colorScheme.outlineVariant,
                    MaterialTheme.shapes.medium
                )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = strings.installedApksTitle,
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.weight(1f)
                    )
                    TextButton(
                        onClick = onRescanPackages,
                        enabled = !uiState.isScanningSplits,
                        modifier = Modifier
                            .height(48.dp)
                            .testTag("rescan_apks_button")
                    ) {
                        if (uiState.isScanningSplits) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                strokeWidth = 2.dp
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Rounded.Refresh,
                                contentDescription = strings.rescanApksCta,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(Modifier.width(4.dp))
                        Text(strings.rescanApksCta)
                    }
                }

                if (editions.isEmpty()) {
                    Text(
                        text = strings.noInstalledApkWarning,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    editions.forEach { edition ->
                        val isBound = selectedProfile?.packageName == edition.packageName
                        val mainSo = edition.embeddedNativeLibs.firstOrNull {
                            it.abi == uiState.effectiveTargetAbi
                        } ?: edition.embeddedNativeLibs.firstOrNull()
                        val sizeMb = if (mainSo != null && mainSo.uncompressedSize > 0L) {
                            "${"%.1f".format(Locale.US, mainSo.uncompressedSize / (1024.0 * 1024.0))} MB"
                        } else null

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(MaterialTheme.shapes.small)
                                .background(MaterialTheme.colorScheme.surfaceContainerLowest)
                                .border(
                                    1.dp,
                                    if (isBound) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                                    MaterialTheme.shapes.small
                                )
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "${edition.appLabel} • v${edition.versionName}",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = edition.packageName,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontFamily = JetBrainsMonoFamily,
                                        color = MaterialTheme.colorScheme.secondary
                                    )
                                }
                                if (isBound) {
                                    StatusPill(
                                        text = strings.installedBadge,
                                        containerColor = MaterialTheme.colorScheme.primaryContainer,
                                        contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                }
                            }

                            Text(
                                text = buildString {
                                    append("extractNativeLibs=${edition.extractNativeLibsEnabled}")
                                    if (mainSo != null) {
                                        append(" • ${mainSo.abi}")
                                        if (sizeMb != null) append(" ($sizeMb)")
                                    }
                                    if (edition.splitNames.isNotEmpty()) {
                                        append(" • ${edition.splitNames.size} splits")
                                    }
                                },
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = JetBrainsMonoFamily,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = buildString {
                                    appendLine("sourceDir: ${edition.sourceDir.ifBlank { "n/a" }}")
                                    appendLine("splitSourceDirs (${edition.splitSourceDirs.size}): ${edition.splitSourceDirs.joinToString().ifBlank { "none" }}")
                                    append("nativeLibraryDir: ${edition.nativeLibraryDir.ifBlank { "n/a" }}")
                                },
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = JetBrainsMonoFamily,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            if (edition.targetSdkVersion > 0 || edition.signingCertSha256.isNotBlank()) {
                                Text(
                                    text = buildString {
                                        append("${strings.apkSdkAndSigLabel}: ")
                                        if (edition.minSdkVersion > 0) append("minSdk=${edition.minSdkVersion} ")
                                        if (edition.targetSdkVersion > 0) append("targetSdk=${edition.targetSdkVersion}")
                                        if (edition.signingCertSha256.isNotBlank()) {
                                            append(" • cert:${edition.signingCertSha256}")
                                        }
                                    },
                                    style = MaterialTheme.typography.labelSmall,
                                    fontFamily = JetBrainsMonoFamily,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                if (!isBound) {
                                    OutlinedButton(
                                        onClick = { onBindInstalledPackage(edition.packageName) },
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(48.dp),
                                        shape = MaterialTheme.shapes.small
                                    ) {
                                        Text(strings.bindAndUseCta)
                                    }
                                }
                                Button(
                                    onClick = { onLaunchPackageDirect(edition.packageName) },
                                    enabled = edition.isLaunchable,
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp)
                                        .testTag("direct_launch_${edition.packageName}"),
                                    shape = MaterialTheme.shapes.small
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.PlayArrow,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(Modifier.width(4.dp))
                                    Text(strings.launchApkDirectCta)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Load Game Build / Library Cache from APK / APKS / XAPK
        Card(
            shape = MaterialTheme.shapes.medium,
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, MaterialTheme.shapes.medium)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.FolderZip,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = strings.apkInspectionTitle,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                val inspection = uiState.apkInspectionResult
                if (inspection == null && !uiState.isInspectingApk) {
                    Text(
                        text = strings.noApkInspectedHint,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                AnimatedVisibility(visible = uiState.isInspectingApk || uiState.isExtractingRealLib) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.padding(vertical = 8.dp)
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(22.dp),
                            strokeWidth = 2.5.dp
                        )
                        Text(
                            text = if (uiState.isExtractingRealLib) {
                                strings.extractingRealLibLabel
                            } else if (uiState.language == AppLanguage.AR) {
                                "جاري فحص حزمة اللعبة..."
                            } else {
                                "Scanning game build..."
                            },
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }

                if (inspection != null && !uiState.isInspectingApk) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(MaterialTheme.shapes.small)
                            .background(MaterialTheme.colorScheme.surfaceContainerLowest)
                            .border(
                                1.dp,
                                if (inspection.compatibleWithDevice) MaterialTheme.colorScheme.outline
                                else MaterialTheme.colorScheme.error.copy(alpha = 0.5f),
                                MaterialTheme.shapes.small
                            )
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = inspection.fileName,
                                style = MaterialTheme.typography.titleSmall,
                                fontFamily = JetBrainsMonoFamily,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                            Icon(
                                imageVector = if (inspection.compatibleWithDevice) Icons.Rounded.CheckCircle else Icons.Rounded.ErrorOutline,
                                contentDescription = null,
                                tint = if (inspection.compatibleWithDevice) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        if (!inspection.archivePackageName.isNullOrBlank()) {
                            Text(
                                text = "${inspection.archivePackageName} • v${inspection.archiveVersionName ?: "?"}",
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = JetBrainsMonoFamily,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Text(
                            text = if (uiState.language == AppLanguage.AR) inspection.diagnosisSummaryAr else inspection.diagnosisSummaryEn,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        if (inspection.foundNativeLibs.isNotEmpty()) {
                            Text(
                                text = inspection.foundNativeLibs.joinToString("\n") { lib ->
                                    val elfPart = if (lib.elfArchLabel.isNotBlank()) " [${lib.elfArchLabel}]" else ""
                                    val shaPart = if (lib.sha256Short.isNotBlank()) " sha256:${lib.sha256Short}" else ""
                                    "• ${lib.sourceApkName} -> ${lib.entryPath}$elfPart$shaPart"
                                },
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = JetBrainsMonoFamily,
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }
                        if (inspection.compatibleWithDevice) {
                            Button(
                                onClick = onApplyInspectedArchive,
                                enabled = !uiState.isExtractingRealLib,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .padding(top = 4.dp)
                                    .testTag("sync_inspected_apk_button"),
                                shape = MaterialTheme.shapes.small
                            ) {
                                Text(
                                    text = if (uiState.language == AppLanguage.AR) {
                                        "استخراج وتثبيت المكتبة في كاش المشغّل"
                                    } else {
                                        "Extract & Sync Library to Launcher"
                                    },
                                    style = MaterialTheme.typography.labelLarge
                                )
                            }
                        }
                    }
                }

                OutlinedButton(
                    onClick = onPickArchiveToInspect,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("inspect_apk_button"),
                    shape = MaterialTheme.shapes.medium
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.Launch,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = strings.inspectApkCta,
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            }
        }
    }
}
