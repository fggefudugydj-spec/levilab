package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Build
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Dns
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.CacheHealthStatus
import com.example.ui.LeviStrings
import com.example.ui.LeviUiState
import com.example.ui.components.LeviLeafMark
import com.example.ui.components.StatusPill
import com.example.ui.screens.home.AddBedrockServerDialog
import com.example.ui.screens.home.BedrockServersSection
import com.example.ui.screens.home.CreateIsolatedInstanceDialog
import com.example.ui.screens.home.InstalledEditionsSection
import com.example.ui.screens.home.SandboxOptionsSection
import com.example.ui.theme.JetBrainsMonoFamily

private enum class HomeSectionTab {
    EDITIONS,
    WORKSPACE,
    SERVERS
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun LauncherHomeScreen(
    uiState: LeviUiState,
    strings: LeviStrings,
    onSelectProfile: (String) -> Unit,
    onCreateIsolatedInstance: (String, String, String) -> Unit,
    onDeleteCustomInstance: (String) -> Unit,
    onUpdateSandboxOptions: (String, Boolean, Boolean, Boolean, Boolean, Int, Int) -> Unit,
    onToggleLaunchInsideTask: (Boolean) -> Unit,
    onToggleAutoSyncOptions: (Boolean) -> Unit,
    onLaunchClick: () -> Unit,
    onOpenLaunchLog: () -> Unit,
    onOpenDiagnostics: () -> Unit,
    onInspectArchiveUri: (Uri) -> Unit,
    onApplyInspectedArchive: () -> Unit,
    onRescanPackages: () -> Unit,
    onBindInstalledPackage: (String) -> Unit,
    onLaunchPackageDirect: (String) -> Unit,
    onConnectServer: (String, Int) -> Unit,
    onAddServer: (String, String, Int) -> Unit,
    onRemoveServer: (String) -> Unit,
    onPingServer: (String, String, Int) -> Unit,
    onAddServerToMinecraft: (String, String, Int) -> Unit,
    onLinkMojangTree: (Uri) -> Unit,
    onUnlinkMojangTree: () -> Unit,
    onSyncOptionsToSaf: () -> Unit,
    modifier: Modifier = Modifier
) {
    val archivePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            onInspectArchiveUri(uri)
        }
    }

    val mojangTreeLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { uri: Uri? ->
        if (uri != null) {
            onLinkMojangTree(uri)
        }
    }

    var showCreateInstanceDialog by remember { mutableStateOf(false) }
    var showAddServerDialog by remember { mutableStateOf(false) }
    var activeTab by rememberSaveable { mutableStateOf(HomeSectionTab.EDITIONS) }

    val selectedProfile = uiState.selectedProfile
    val effectiveStatus = selectedProfile?.cacheStatus ?: CacheHealthStatus.MISSING_LIB

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 760.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (!uiState.launchSession.crashRecoveryNote.isNullOrBlank()) {
                item {
                    Card(
                        shape = MaterialTheme.shapes.medium,
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, MaterialTheme.colorScheme.error, MaterialTheme.shapes.medium)
                            .testTag("home_crash_recovery_card")
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = strings.crashDetectedBannerTitle,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onErrorContainer
                            )
                            Text(
                                text = uiState.launchSession.crashRecoveryNote,
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = JetBrainsMonoFamily,
                                color = MaterialTheme.colorScheme.onErrorContainer
                            )
                            Button(
                                onClick = onOpenLaunchLog,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("open_crash_log_button"),
                                shape = MaterialTheme.shapes.small
                            ) {
                                Text(strings.openCrashLogCta)
                            }
                        }
                    }
                }
            }

            // Hero Game Launcher Card
            item {
                Card(
                    shape = MaterialTheme.shapes.large,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outline, MaterialTheme.shapes.large)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(210.dp)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.img_launcher_hero_1794645563979),
                            contentDescription = strings.appTitle,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.horizontalGradient(
                                        colors = listOf(
                                            MaterialTheme.colorScheme.background.copy(alpha = 0.94f),
                                            MaterialTheme.colorScheme.background.copy(alpha = 0.72f),
                                            MaterialTheme.colorScheme.background.copy(alpha = 0.25f)
                                        )
                                    )
                                )
                        )

                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(20.dp),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    val (pillText, pillBg, pillFg) = when (effectiveStatus) {
                                        CacheHealthStatus.VERIFIED -> Triple(
                                            strings.cacheVerifiedBadge,
                                            MaterialTheme.colorScheme.primaryContainer,
                                            MaterialTheme.colorScheme.onPrimaryContainer
                                        )
                                        CacheHealthStatus.ABI_MISMATCH -> Triple(
                                            strings.cacheMismatchBadge,
                                            MaterialTheme.colorScheme.tertiaryContainer,
                                            MaterialTheme.colorScheme.onTertiaryContainer
                                        )
                                        else -> Triple(
                                            strings.cacheMissingBadge,
                                            MaterialTheme.colorScheme.errorContainer,
                                            MaterialTheme.colorScheme.onErrorContainer
                                        )
                                    }
                                    StatusPill(
                                        text = pillText,
                                        containerColor = pillBg,
                                        contentColor = pillFg
                                    )
                                    StatusPill(
                                        text = if (uiState.launchInsideTask) {
                                            strings.launchModeEmbeddedBadge
                                        } else {
                                            strings.launchModeSeparateBadge
                                        },
                                        containerColor = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.9f),
                                        contentColor = MaterialTheme.colorScheme.secondary,
                                        leadingDot = false
                                    )
                                }
                                LeviLeafMark(size = 36.dp)
                            }

                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                val installStatus = if (selectedProfile?.isInstalledOnDevice == true) {
                                    strings.installedBadge
                                } else {
                                    strings.notInstalledBadge
                                }
                                Text(
                                    text = "${strings.activeProfileLabel} • $installStatus",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.secondary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = selectedProfile?.displayName ?: "Bedrock Preview v1.26.70.24",
                                    style = MaterialTheme.typography.headlineSmall,
                                    color = MaterialTheme.colorScheme.onBackground,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "v${selectedProfile?.versionName ?: "1.26.70.24"}  •  ABI: ${uiState.effectiveTargetAbi}  •  ${selectedProfile?.packageName ?: "com.mojang.minecraftpe.preview"}",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontFamily = JetBrainsMonoFamily,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }

                    // Version Switcher + Readiness Strip + Primary Play Button
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            uiState.profiles.forEach { profile ->
                                val isSelected = profile.id == uiState.selectedProfileId
                                val isHealthy = profile.cacheStatus == CacheHealthStatus.VERIFIED && profile.hasRealElfBinary
                                FilterChip(
                                    selected = isSelected,
                                    onClick = { onSelectProfile(profile.id) },
                                    modifier = Modifier.testTag("profile_chip_${profile.id}"),
                                    label = {
                                        Text(
                                            text = if (profile.isCustomInstance) {
                                                "${profile.displayName} (${profile.versionName})"
                                            } else {
                                                profile.versionName
                                            },
                                            style = MaterialTheme.typography.labelMedium
                                        )
                                    },
                                    leadingIcon = {
                                        Icon(
                                            imageVector = if (isHealthy) Icons.Rounded.CheckCircle else Icons.Rounded.WarningAmber,
                                            contentDescription = null,
                                            modifier = Modifier.size(16.dp),
                                            tint = if (isHealthy) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                                        )
                                    },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                        selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                )
                            }
                            AssistChip(
                                onClick = { showCreateInstanceDialog = true },
                                modifier = Modifier.testTag("create_isolated_instance_button"),
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Rounded.Add,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp),
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                },
                                label = {
                                    Text(
                                        text = strings.newInstanceCta,
                                        style = MaterialTheme.typography.labelMedium
                                    )
                                }
                            )
                        }

                        if (selectedProfile?.isCustomInstance == true) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                TextButton(
                                    onClick = { onDeleteCustomInstance(selectedProfile.id) },
                                    modifier = Modifier
                                        .height(48.dp)
                                        .testTag("delete_custom_instance_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Outlined.DeleteOutline,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp),
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                    Spacer(Modifier.width(4.dp))
                                    Text(
                                        text = strings.deleteInstanceCta,
                                        color = MaterialTheme.colorScheme.error
                                    )
                                }
                            }
                        }

                        val sandbox = uiState.activeSandbox
                        val libStateText = when (effectiveStatus) {
                            CacheHealthStatus.VERIFIED -> selectedProfile?.elfArchLabel?.takeIf { it.isNotBlank() } ?: strings.readyBadge
                            CacheHealthStatus.ABI_MISMATCH -> "ABI Mismatch"
                            else -> "Missing .so"
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            ReadinessChip(
                                label = strings.readinessVersionLabel,
                                value = selectedProfile?.versionName ?: "1.26.70.24",
                                isHealthy = true,
                                modifier = Modifier.weight(0.95f)
                            )
                            ReadinessChip(
                                label = strings.readinessLibraryLabel,
                                value = libStateText,
                                isHealthy = effectiveStatus == CacheHealthStatus.VERIFIED,
                                modifier = Modifier.weight(1.25f)
                            )
                            ReadinessChip(
                                label = strings.readinessSandboxLabel,
                                value = if (sandbox?.isolatedEnabled == true) "${sandbox.maxFramerate} FPS" else "Shared",
                                isHealthy = sandbox?.isolatedEnabled == true,
                                modifier = Modifier.weight(0.9f)
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = onLaunchClick,
                                modifier = Modifier
                                    .weight(1.35f)
                                    .height(52.dp)
                                    .testTag("launch_minecraft_button"),
                                shape = MaterialTheme.shapes.medium,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.primary,
                                    contentColor = MaterialTheme.colorScheme.onPrimary
                                )
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.PlayArrow,
                                    contentDescription = null,
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(Modifier.width(6.dp))
                                val launchBtnText = if (selectedProfile?.packageName == "com.mojang.minecraftpe.preview") {
                                    strings.launchPreviewCta
                                } else {
                                    strings.launchMinecraftCta
                                }
                                Text(
                                    text = launchBtnText,
                                    style = MaterialTheme.typography.labelLarge,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }

                            OutlinedButton(
                                onClick = onOpenDiagnostics,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(52.dp)
                                    .testTag("open_diagnostics_button"),
                                shape = MaterialTheme.shapes.medium
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Build,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(Modifier.width(6.dp))
                                Text(
                                    text = strings.openDiagnosticsCta,
                                    style = MaterialTheme.typography.labelLarge,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }

            // Segmented Section Bar to switch cleanly between Editions, Workspace, and Servers
            item {
                val tabItems = listOf(
                    Triple(HomeSectionTab.EDITIONS, strings.homeTabEditions, Icons.Rounded.Layers),
                    Triple(HomeSectionTab.WORKSPACE, strings.homeTabWorkspace, Icons.Rounded.Tune),
                    Triple(HomeSectionTab.SERVERS, strings.homeTabServers, Icons.Rounded.Dns)
                )
                SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                    tabItems.forEachIndexed { index, (tab, label, icon) ->
                        SegmentedButton(
                            selected = activeTab == tab,
                            onClick = { activeTab = tab },
                            shape = SegmentedButtonDefaults.itemShape(index = index, count = tabItems.size),
                            modifier = Modifier
                                .height(48.dp)
                                .testTag("home_section_tab_${tab.name.lowercase()}"),
                            icon = {
                                SegmentedButtonDefaults.Icon(active = activeTab == tab) {
                                    Icon(
                                        imageVector = icon,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            },
                            label = {
                                Text(
                                    text = label,
                                    style = MaterialTheme.typography.labelMedium,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        )
                    }
                }
            }

            // Active Tab Content
            item {
                AnimatedContent(
                    targetState = activeTab,
                    transitionSpec = { fadeIn() togetherWith fadeOut() },
                    label = "home_section_content"
                ) { tab ->
                    when (tab) {
                        HomeSectionTab.EDITIONS -> {
                            InstalledEditionsSection(
                                uiState = uiState,
                                strings = strings,
                                onRescanPackages = onRescanPackages,
                                onBindInstalledPackage = onBindInstalledPackage,
                                onLaunchPackageDirect = onLaunchPackageDirect,
                                onPickArchiveToInspect = {
                                    archivePickerLauncher.launch(
                                        arrayOf(
                                            "application/vnd.android.package-archive",
                                            "application/zip",
                                            "application/octet-stream",
                                            "*/*"
                                        )
                                    )
                                },
                                onApplyInspectedArchive = onApplyInspectedArchive
                            )
                        }
                        HomeSectionTab.WORKSPACE -> {
                            SandboxOptionsSection(
                                uiState = uiState,
                                strings = strings,
                                onUpdateSandboxOptions = onUpdateSandboxOptions,
                                onToggleLaunchInsideTask = onToggleLaunchInsideTask,
                                onToggleAutoSyncOptions = onToggleAutoSyncOptions,
                                onLinkMojangTreeClick = { mojangTreeLauncher.launch(null) },
                                onUnlinkMojangTree = onUnlinkMojangTree,
                                onSyncOptionsToSaf = onSyncOptionsToSaf
                            )
                        }
                        HomeSectionTab.SERVERS -> {
                            BedrockServersSection(
                                uiState = uiState,
                                strings = strings,
                                onAddServerClick = { showAddServerDialog = true },
                                onRemoveServer = onRemoveServer,
                                onPingServer = onPingServer,
                                onAddServerToMinecraft = onAddServerToMinecraft,
                                onConnectServer = onConnectServer
                            )
                        }
                    }
                }
            }

            item { Spacer(Modifier.height(12.dp)) }
        }
    }

    if (showCreateInstanceDialog) {
        CreateIsolatedInstanceDialog(
            strings = strings,
            onDismiss = { showCreateInstanceDialog = false },
            onCreate = { name, version, pkg ->
                onCreateIsolatedInstance(name, version, pkg)
                showCreateInstanceDialog = false
            }
        )
    }

    if (showAddServerDialog) {
        AddBedrockServerDialog(
            strings = strings,
            onDismiss = { showAddServerDialog = false },
            onSave = { name, host, port ->
                onAddServer(name, host, port)
                showAddServerDialog = false
            }
        )
    }
}

@Composable
private fun ReadinessChip(
    label: String,
    value: String,
    isHealthy: Boolean,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(MaterialTheme.shapes.small)
            .background(MaterialTheme.colorScheme.surfaceContainerLowest)
            .border(
                1.dp,
                if (isHealthy) MaterialTheme.colorScheme.outline else MaterialTheme.colorScheme.outlineVariant,
                MaterialTheme.shapes.small
            )
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = value,
            style = MaterialTheme.typography.labelSmall,
            fontFamily = JetBrainsMonoFamily,
            fontWeight = FontWeight.SemiBold,
            color = if (isHealthy) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.tertiary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
