package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

// Custom Canvas emblem echoing LeviLauncher's signature emerald leaf motif
// paired with a clean geometric accent.
@Composable
fun LeviLeafMark(
    modifier: Modifier = Modifier,
    size: Dp = 40.dp,
    primaryColor: Color = MaterialTheme.colorScheme.primary,
    secondaryColor: Color = MaterialTheme.colorScheme.secondary
) {
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height

        // Main large leaf
        val mainLeaf = Path().apply {
            moveTo(w * 0.78f, h * 0.14f)
            cubicTo(w * 0.42f, h * 0.16f, w * 0.24f, h * 0.42f, w * 0.34f, h * 0.72f)
            cubicTo(w * 0.62f, h * 0.76f, w * 0.84f, h * 0.50f, w * 0.78f, h * 0.14f)
            close()
        }
        drawPath(
            path = mainLeaf,
            brush = Brush.linearGradient(
                colors = listOf(secondaryColor, primaryColor),
                start = Offset(w * 0.3f, h * 0.2f),
                end = Offset(w * 0.8f, h * 0.75f)
            )
        )

        // Central vein
        drawLine(
            color = Color(0xFF061913),
            start = Offset(w * 0.73f, h * 0.20f),
            end = Offset(w * 0.31f, h * 0.79f),
            strokeWidth = w * 0.055f,
            cap = StrokeCap.Round
        )

        // Secondary small leaf on the left
        val smallLeaf = Path().apply {
            moveTo(w * 0.16f, h * 0.44f)
            cubicTo(w * 0.14f, h * 0.64f, w * 0.26f, h * 0.72f, w * 0.36f, h * 0.68f)
            cubicTo(w * 0.36f, h * 0.52f, w * 0.26f, h * 0.44f, w * 0.16f, h * 0.44f)
            close()
        }
        drawPath(
            path = smallLeaf,
            color = primaryColor.copy(alpha = 0.85f)
        )
        drawPath(
            path = smallLeaf,
            color = secondaryColor.copy(alpha = 0.6f),
            style = Stroke(width = w * 0.025f)
        )
    }
}

@Composable
fun StatusPill(
    text: String,
    containerColor: Color,
    contentColor: Color,
    borderColor: Color = contentColor.copy(alpha = 0.35f),
    leadingDot: Boolean = true,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .background(containerColor)
            .border(1.dp, borderColor, RoundedCornerShape(50))
            .padding(horizontal = 10.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        if (leadingDot) {
            Box(
                modifier = Modifier
                    .size(7.dp)
                    .clip(RoundedCornerShape(50))
                    .background(contentColor)
            )
        }
        Text(
            text = text,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.SemiBold,
            color = contentColor
        )
    }
}
