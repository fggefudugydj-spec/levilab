package com.example.ui.screens.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.ui.LeviStrings
import com.example.ui.theme.JetBrainsMonoFamily

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CreateIsolatedInstanceDialog(
    strings: LeviStrings,
    onDismiss: () -> Unit,
    onCreate: (String, String, String) -> Unit
) {
    var name by remember { mutableStateOf("Bedrock Preview Lab") }
    var version by remember { mutableStateOf("1.26.70.24") }
    var pkgName by remember { mutableStateOf("com.mojang.minecraftpe.preview") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(strings.newInstanceDialogTitle) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text(strings.instanceNameLabel) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("instance_name_input")
                )
                OutlinedTextField(
                    value = version,
                    onValueChange = { version = it },
                    label = { Text(strings.instanceVersionLabel) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("instance_version_input")
                )
                OutlinedTextField(
                    value = pkgName,
                    onValueChange = { pkgName = it },
                    label = { Text(strings.instancePackageLabel) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("instance_package_input")
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(
                        "com.mojang.minecraftpe.preview",
                        "com.mojang.minecraftpe",
                        "com.mojang.minecraftpe.beta"
                    ).forEach { preset ->
                        FilterChip(
                            selected = pkgName == preset,
                            onClick = { pkgName = preset },
                            label = {
                                Text(preset, fontFamily = JetBrainsMonoFamily, style = MaterialTheme.typography.labelSmall)
                            }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onCreate(name, version, pkgName) },
                enabled = name.isNotBlank() && version.isNotBlank() && pkgName.isNotBlank(),
                modifier = Modifier
                    .heightIn(min = 48.dp)
                    .testTag("confirm_create_instance_button")
            ) {
                Text(strings.createLabel)
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.heightIn(min = 48.dp)
            ) {
                Text(strings.cancelLabel)
            }
        }
    )
}

@Composable
fun AddBedrockServerDialog(
    strings: LeviStrings,
    onDismiss: () -> Unit,
    onSave: (String, String, Int) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var host by remember { mutableStateOf("") }
    var portText by remember { mutableStateOf("19132") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(strings.serverConnectTitle) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text(strings.serverNameLabel) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = host,
                    onValueChange = { host = it },
                    label = { Text(strings.serverHostLabel) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("server_host_input")
                )
                OutlinedTextField(
                    value = portText,
                    onValueChange = { portText = it.filter { ch -> ch.isDigit() } },
                    label = { Text(strings.serverPortLabel) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val port = portText.toIntOrNull()?.coerceIn(1, 65535) ?: 19132
                    onSave(name, host, port)
                },
                enabled = host.isNotBlank(),
                modifier = Modifier.heightIn(min = 48.dp)
            ) {
                Text(strings.addServerCta)
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.heightIn(min = 48.dp)
            ) {
                Text(strings.cancelLabel)
            }
        }
    )
}
