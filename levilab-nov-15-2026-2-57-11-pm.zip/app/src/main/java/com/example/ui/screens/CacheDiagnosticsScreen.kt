package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.DeleteSweep
import androidx.compose.material.icons.outlined.FolderOpen
import androidx.compose.material.icons.outlined.Healing
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.AppLanguage
import com.example.model.CacheHealthStatus
import com.example.model.SplitCategory
import com.example.ui.LeviStrings
import com.example.ui.LeviUiState
import com.example.ui.components.StatusPill
import com.example.ui.theme.JetBrainsMonoFamily
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CacheDiagnosticsScreen(
    uiState: LeviUiState,
    strings: LeviStrings,
    onSelectAbiOverride: (String) -> Unit,
    onRepairCache: () -> Unit,
    onClearCache: () -> Unit,
    onSyncFromInstalled: () -> Unit,
    onTestLaunch: () -> Unit,
    onOpenReferenceCode: () -> Unit,
    modifier: Modifier = Modifier
) {
    val profile = uiState.selectedProfile
    val isHealthy = profile?.cacheStatus == CacheHealthStatus.VERIFIED && profile.hasRealElfBinary

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 720.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = strings.diagnosticsTitle,
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = strings.diagnosticsSubtitle,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Target ABI Override Selector
            item {
                Card(
                    shape = MaterialTheme.shapes.medium,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, MaterialTheme.shapes.medium)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = strings.targetAbiLabel,
                            style = MaterialTheme.typography.titleSmall
                        )
                        val primaryAbi = uiState.telemetry?.primaryAbi ?: "arm64-v8a"
                        val options = listOf("AUTO", "arm64-v8a", "armeabi-v7a", "x86_64")
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            options.forEach { abi ->
                                val selected = uiState.targetAbiOverride == abi
                                FilterChip(
                                    selected = selected,
                                    onClick = { onSelectAbiOverride(abi) },
                                    modifier = Modifier.testTag("abi_chip_$abi"),
                                    label = {
                                        Text(
                                            text = if (abi == "AUTO") "${strings.autoAbiOption} ($primaryAbi)" else abi,
                                            style = MaterialTheme.typography.labelMedium,
                                            fontFamily = JetBrainsMonoFamily
                                        )
                                    },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                        selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                )
                            }
                        }
                    }
                }
            }

            // Internal Cache Inspector Card
            item {
                Card(
                    shape = MaterialTheme.shapes.medium,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(
                            1.dp,
                            if (isHealthy) MaterialTheme.colorScheme.outline else MaterialTheme.colorScheme.error.copy(alpha = 0.55f),
                            MaterialTheme.shapes.medium
                        )
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.FolderOpen,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = strings.cacheInspectorTitle,
                                    style = MaterialTheme.typography.titleMedium
                                )
                            }
                            Icon(
                                imageVector = if (isHealthy) Icons.Rounded.CheckCircle else Icons.Rounded.ErrorOutline,
                                contentDescription = null,
                                tint = if (isHealthy) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                            )
                        }

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(MaterialTheme.shapes.small)
                                .background(MaterialTheme.colorScheme.surfaceContainerLowest)
                                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, MaterialTheme.shapes.small)
                                .padding(12.dp)
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = strings.expectedPathLabel,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = profile?.cachePath ?: "—",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontFamily = JetBrainsMonoFamily,
                                    color = if (isHealthy) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.error
                                )
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    text = strings.availableAbisInCacheLabel,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                val cachedAbis = profile?.availableCachedAbis.orEmpty()
                                Text(
                                    text = if (cachedAbis.isEmpty()) strings.noneFoundLabel else cachedAbis.joinToString(", "),
                                    style = MaterialTheme.typography.labelSmall,
                                    fontFamily = JetBrainsMonoFamily,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                if (profile != null && profile.cachedLibSizeBytes > 0L) {
                                    val sizeLabel = if (profile.cachedLibSizeBytes >= 1024L * 1024L) {
                                        "${"%.2f".format(java.util.Locale.US, profile.cachedLibSizeBytes / (1024.0 * 1024.0))} MB (${profile.cachedLibSizeBytes} B)"
                                    } else {
                                        "${profile.cachedLibSizeBytes} B"
                                    }
                                    Text(
                                        text = "Size: $sizeLabel  |  SHA-256: ${profile.cachedLibSha256}",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontFamily = JetBrainsMonoFamily,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                                if (profile?.hasRealElfBinary == true) {
                                    FlowRow(
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        StatusPill(
                                            text = strings.realElfBadge,
                                            containerColor = MaterialTheme.colorScheme.primaryContainer,
                                            contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                                        )
                                        val alignText = if (profile.is16KbAligned) {
                                            strings.elf16KbAlignedLabel
                                        } else {
                                            "${strings.elf4KbWarningLabel} (${profile.maxLoadAlignBytes}B)"
                                        }
                                        StatusPill(
                                            text = alignText,
                                            containerColor = if (profile.is16KbAligned) {
                                                MaterialTheme.colorScheme.secondaryContainer
                                            } else {
                                                MaterialTheme.colorScheme.tertiaryContainer
                                            },
                                            contentColor = if (profile.is16KbAligned) {
                                                MaterialTheme.colorScheme.onSecondaryContainer
                                            } else {
                                                MaterialTheme.colorScheme.onTertiaryContainer
                                            }
                                        )
                                    }
                                }
                                if (profile != null && profile.elfArchLabel.isNotBlank()) {
                                    Text(
                                        text = "ELF: ${profile.elfArchLabel}",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontFamily = JetBrainsMonoFamily,
                                        color = MaterialTheme.colorScheme.secondary
                                    )
                                }
                                if (profile != null && profile.neededLibraries.isNotEmpty()) {
                                    Text(
                                        text = "${strings.dtNeededLibsLabel}: ${profile.neededLibraries.joinToString()}",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontFamily = JetBrainsMonoFamily,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                                if (profile != null && profile.companionLibsFound.isNotEmpty()) {
                                    Text(
                                        text = "${strings.companionLibsTitle}: ${profile.companionLibsFound.joinToString()}",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontFamily = JetBrainsMonoFamily,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                                if (profile != null && profile.cacheSourceSummary.isNotBlank()) {
                                    Text(
                                        text = "Source: ${profile.cacheSourceSummary}",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontFamily = JetBrainsMonoFamily,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                if (profile != null && profile.verificationNote.isNotBlank()) {
                                    Text(
                                        text = profile.verificationNote,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontFamily = JetBrainsMonoFamily,
                                        color = if (isHealthy) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                                    )
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = onRepairCache,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("repair_cache_button"),
                                shape = MaterialTheme.shapes.small
                            ) {
                                Icon(Icons.Outlined.Healing, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text(strings.repairCacheCta, maxLines = 1)
                            }

                            OutlinedButton(
                                onClick = onClearCache,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("clear_cache_button"),
                                shape = MaterialTheme.shapes.small,
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = MaterialTheme.colorScheme.error
                                )
                            ) {
                                Icon(Icons.Outlined.DeleteSweep, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text(strings.clearCacheCta, maxLines = 1)
                            }
                        }

                        OutlinedButton(
                            onClick = onTestLaunch,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("diagnostics_test_launch_button"),
                            shape = MaterialTheme.shapes.small
                        ) {
                            Icon(Icons.Rounded.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(strings.launchMinecraftCta)
                        }
                    }
                }
            }

            // Live v1.26.70.24 Package & extractNativeLibs=false Probe Card
            item {
                val installedEditions = uiState.telemetry?.installedEditions.orEmpty()
                val isAr = uiState.language == AppLanguage.AR
                Card(
                    shape = MaterialTheme.shapes.medium,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, MaterialTheme.shapes.medium)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = strings.extractNativeLibsProbeTitle,
                            style = MaterialTheme.typography.titleMedium
                        )
                        if (installedEditions.isEmpty()) {
                            Text(
                                text = if (isAr) {
                                    "لم يتم العثور على com.mojang.minecraftpe.preview أو com.mojang.minecraftpe مثبّتاً على هذا الجهاز. عند التثبيت سيقرأ الفاحص مسارات sourceDir و splitSourceDirs و nativeLibraryDir تلقائياً."
                                } else {
                                    "Neither com.mojang.minecraftpe.preview nor com.mojang.minecraftpe is installed on this device. Once installed, this extractor reads sourceDir, splitSourceDirs, and nativeLibraryDir automatically."
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        } else {
                            installedEditions.forEach { edition ->
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(MaterialTheme.shapes.small)
                                        .background(MaterialTheme.colorScheme.surfaceContainerLowest)
                                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, MaterialTheme.shapes.small)
                                        .padding(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text(
                                        text = "${edition.packageName} • v${edition.versionName}",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontFamily = JetBrainsMonoFamily,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Text(
                                        text = "extractNativeLibs=${edition.extractNativeLibsEnabled}  |  diskLib=${edition.hasNativeLibInSystemDir}",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontFamily = JetBrainsMonoFamily,
                                        color = if (edition.hasNativeLibInSystemDir || edition.embeddedNativeLibs.isNotEmpty()) {
                                            MaterialTheme.colorScheme.secondary
                                        } else {
                                            MaterialTheme.colorScheme.error
                                        }
                                    )
                                    if (edition.targetSdkVersion > 0 || edition.signingCertSha256.isNotBlank()) {
                                        Text(
                                            text = "minSdk=${edition.minSdkVersion} • targetSdk=${edition.targetSdkVersion} • sig=${edition.signingCertSha256.ifBlank { "n/a" }}",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontFamily = JetBrainsMonoFamily,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    edition.embeddedNativeLibs.forEach { lib ->
                                        Text(
                                            text = "• ${lib.sourceApkName} -> ${lib.entryPath} (${lib.elfArchLabel})",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontFamily = JetBrainsMonoFamily,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                            }
                            Button(
                                onClick = onSyncFromInstalled,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("sync_from_installed_button"),
                                shape = MaterialTheme.shapes.small
                            ) {
                                Icon(Icons.Outlined.Healing, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text(strings.syncFromInstalledCta)
                            }
                        }
                    }
                }
            }

            // Installed Split APKs Breakdown Card
            item {
                val splitsReport = uiState.installedSplitsReport
                Card(
                    shape = MaterialTheme.shapes.medium,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, MaterialTheme.shapes.medium)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = strings.splitBreakdownTitle,
                            style = MaterialTheme.typography.titleMedium
                        )
                        if (splitsReport == null || !splitsReport.isInstalled) {
                            Text(
                                text = strings.splitNoSplitsHint,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        } else {
                            fun formatMb(bytes: Long): String =
                                "${"%.1f".format(Locale.US, bytes / (1024.0 * 1024.0))} MB"

                            Text(
                                text = "${splitsReport.packageName} • v${splitsReport.versionName}",
                                style = MaterialTheme.typography.labelMedium,
                                fontFamily = JetBrainsMonoFamily,
                                color = MaterialTheme.colorScheme.primary
                            )
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                StatusPill(
                                    text = "${strings.splitBaseApkLabel}: ${formatMb(splitsReport.baseApkSizeBytes)}",
                                    containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                                    contentColor = MaterialTheme.colorScheme.onSurface,
                                    leadingDot = false
                                )
                                StatusPill(
                                    text = "${strings.splitResourceLangLabel}: ${formatMb(splitsReport.resourceAndLanguageTotalBytes)}",
                                    containerColor = MaterialTheme.colorScheme.secondaryContainer,
                                    contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
                                    leadingDot = false
                                )
                                StatusPill(
                                    text = "${strings.splitTotalDiskLabel}: ${formatMb(splitsReport.totalPackageDiskBytes)}",
                                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                                    contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                                    leadingDot = false
                                )
                            }

                            if (splitsReport.splitFragments.isEmpty()) {
                                Text(
                                    text = strings.splitNoSplitsHint,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            } else {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(MaterialTheme.shapes.small)
                                        .background(MaterialTheme.colorScheme.surfaceContainerLowest)
                                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, MaterialTheme.shapes.small)
                                        .padding(10.dp),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    splitsReport.splitFragments.forEach { frag ->
                                        val catTag = when (frag.category) {
                                            SplitCategory.NATIVE_ABI -> "ABI"
                                            SplitCategory.RESOURCE_DENSITY -> "RES"
                                            SplitCategory.LANGUAGE -> "LANG"
                                            SplitCategory.FEATURE_MODULE -> "MOD"
                                            SplitCategory.BASE_APK -> "BASE"
                                            SplitCategory.OTHER -> "OTHER"
                                        }
                                        Text(
                                            text = "[$catTag] ${frag.splitName} • ${formatMb(frag.sizeBytes)}",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontFamily = JetBrainsMonoFamily,
                                            color = if (frag.category == SplitCategory.NATIVE_ABI) {
                                                MaterialTheme.colorScheme.primary
                                            } else {
                                                MaterialTheme.colorScheme.onSurfaceVariant
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            item {
                Text(
                    text = strings.rootCausesTitle,
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }

            items(uiState.rootCauseGuides, key = { it.id }) { guide ->
                val isAr = uiState.language == AppLanguage.AR
                Card(
                    shape = MaterialTheme.shapes.medium,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, MaterialTheme.shapes.medium)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (isAr) guide.titleAr else guide.titleEn,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(Modifier.width(8.dp))
                            StatusPill(
                                text = guide.severityTag,
                                containerColor = if (guide.severityTag == "CRITICAL") {
                                    MaterialTheme.colorScheme.errorContainer
                                } else {
                                    MaterialTheme.colorScheme.tertiaryContainer
                                },
                                contentColor = if (guide.severityTag == "CRITICAL") {
                                    MaterialTheme.colorScheme.onErrorContainer
                                } else {
                                    MaterialTheme.colorScheme.onTertiaryContainer
                                },
                                leadingDot = false
                            )
                        }
                        Text(
                            text = if (isAr) guide.symptomAr else guide.symptomEn,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(MaterialTheme.shapes.small)
                                .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f))
                                .padding(10.dp)
                        ) {
                            Text(
                                text = if (isAr) guide.solutionAr else guide.solutionEn,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                    }
                }
            }

            item {
                OutlinedButton(
                    onClick = onOpenReferenceCode,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("open_reference_code_button"),
                    shape = MaterialTheme.shapes.small
                ) {
                    Text(strings.openPatchCodeCta)
                }
            }

            item { Spacer(Modifier.height(12.dp)) }
        }
    }
}
