package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Code
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.AppLanguage
import com.example.ui.LeviStrings
import com.example.ui.LeviUiState
import com.example.ui.components.StatusPill
import com.example.ui.theme.JetBrainsMonoFamily

private data class PatchSnippet(
    val id: String,
    val titleEn: String,
    val titleAr: String,
    val fileName: String,
    val languageBadge: String,
    val code: String
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun LeviLaunchroidPatchScreen(
    uiState: LeviUiState,
    strings: LeviStrings,
    onShowCopiedFeedback: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val isAr = uiState.language == AppLanguage.AR

    var selectedPackage by remember(uiState.selectedProfile?.packageName) {
        mutableStateOf(uiState.selectedProfile?.packageName ?: "com.mojang.minecraftpe.preview")
    }
    var selectedAbi by remember(uiState.effectiveTargetAbi) {
        mutableStateOf(uiState.effectiveTargetAbi)
    }

    val packagePresets = listOf(
        "com.mojang.minecraftpe.preview",
        "com.mojang.minecraftpe",
        "com.mojang.minecraftpe.beta"
    )
    val abiPresets = listOf("arm64-v8a", "armeabi-v7a")

    val patches = remember(selectedPackage, selectedAbi) {
        buildLeviLaunchroidPatches(selectedPackage, selectedAbi)
    }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 760.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = strings.patchScreenTitle,
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = strings.patchScreenSubtitle,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Honest Policy & Local Build Notice Card
            item {
                Card(
                    shape = MaterialTheme.shapes.medium,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.tertiary.copy(alpha = 0.55f), MaterialTheme.shapes.medium)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Info,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.tertiary,
                            modifier = Modifier.size(22.dp)
                        )
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = strings.patchPolicyNoteTitle,
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.tertiary
                            )
                            Text(
                                text = strings.patchPolicyNoteBody,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }

            // Target Package & Cloned Package Customizer
            item {
                Card(
                    shape = MaterialTheme.shapes.medium,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, MaterialTheme.shapes.medium)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = selectedPackage,
                            onValueChange = { selectedPackage = it },
                            label = { Text(strings.customPkgPatchLabel) },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("patch_custom_package_input")
                        )

                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            packagePresets.forEach { pkg ->
                                FilterChip(
                                    selected = selectedPackage == pkg,
                                    onClick = { selectedPackage = pkg },
                                    label = {
                                        Text(
                                            text = pkg,
                                            fontFamily = JetBrainsMonoFamily,
                                            style = MaterialTheme.typography.labelSmall
                                        )
                                    },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                        selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                )
                            }
                        }

                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            abiPresets.forEach { abi ->
                                FilterChip(
                                    selected = selectedAbi == abi,
                                    onClick = { selectedAbi = abi },
                                    label = {
                                        Text(
                                            text = abi,
                                            fontFamily = JetBrainsMonoFamily,
                                            style = MaterialTheme.typography.labelMedium
                                        )
                                    }
                                )
                            }
                        }
                    }
                }
            }

            // Patch Snippets
            items(patches, key = { it.id }) { patch ->
                Card(
                    shape = MaterialTheme.shapes.medium,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, MaterialTheme.shapes.medium)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.Code,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                                Column {
                                    Text(
                                        text = if (isAr) patch.titleAr else patch.titleEn,
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = patch.fileName,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontFamily = JetBrainsMonoFamily,
                                        color = MaterialTheme.colorScheme.secondary
                                    )
                                }
                            }
                            StatusPill(
                                text = patch.languageBadge,
                                containerColor = MaterialTheme.colorScheme.primaryContainer,
                                contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                                leadingDot = false
                            )
                        }

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(MaterialTheme.shapes.small)
                                .background(MaterialTheme.colorScheme.surfaceContainerLowest)
                                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, MaterialTheme.shapes.small)
                                .horizontalScroll(rememberScrollState())
                                .padding(12.dp)
                        ) {
                            Text(
                                text = patch.code,
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = JetBrainsMonoFamily,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Button(
                                onClick = {
                                    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    cm.setPrimaryClip(ClipData.newPlainText(patch.fileName, patch.code))
                                    onShowCopiedFeedback(strings.codeCopiedToast)
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("copy_patch_${patch.id}"),
                                shape = MaterialTheme.shapes.small
                            ) {
                                Icon(Icons.Outlined.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text(strings.copyCodeCta)
                            }
                            IconButton(
                                onClick = {
                                    val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                        type = "text/plain"
                                        putExtra(Intent.EXTRA_SUBJECT, patch.fileName)
                                        putExtra(Intent.EXTRA_TEXT, patch.code)
                                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    }
                                    context.startActivity(Intent.createChooser(sendIntent, strings.shareReportCta))
                                },
                                modifier = Modifier.size(48.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Share,
                                    contentDescription = strings.shareReportCta,
                                    tint = MaterialTheme.colorScheme.secondary
                                )
                            }
                        }
                    }
                }
            }

            item { Spacer(Modifier.height(12.dp)) }
        }
    }
}

private fun buildLeviLaunchroidPatches(packageName: String, abi: String): List<PatchSnippet> {
    val cleanPkg = packageName.trim().ifEmpty { "com.mojang.minecraftpe.preview" }
    val splitSuffix = abi.replace('-', '_')
    return listOf(
        PatchSnippet(
            id = "split_extractor",
            titleEn = "1. Extract libminecraftpe.so from v1.26.70.24 Split APKs",
            titleAr = "1. استخراج libminecraftpe.so من Split APKs لإصدار v1.26.70.24",
            fileName = "SplitLibExtractor.kt",
            languageBadge = "Kotlin",
            code = """
                // Fix for extractNativeLibs=false in Bedrock Preview v1.26.70.24
                fun prepareMinecraftLibraryCache(context: Context, cacheDir: File): File {
                    val targetPackages = listOf(
                        "$cleanPkg",
                        "com.mojang.minecraftpe.preview",
                        "com.mojang.minecraftpe"
                    ).distinct()
                    val pm = context.packageManager
                    val appInfo = targetPackages.firstNotNullOfOrNull { pkg ->
                        runCatching { pm.getApplicationInfo(pkg, 0) }.getOrNull()
                    } ?: error("Minecraft package not found")

                    val outAbiDir = File(cacheDir, "minecraft_library_cache/$abi").apply { mkdirs() }
                    val sysLib = appInfo.nativeLibraryDir?.let { File(it, "libminecraftpe.so") }
                    if (sysLib?.exists() == true) return outAbiDir

                    // Probe base.apk + split_config.$splitSuffix.apk when extractNativeLibs=false
                    val apkPaths = buildList {
                        appInfo.sourceDir?.let(::add)
                        appInfo.splitSourceDirs?.let { addAll(it) }
                    }
                    val requiredLibs = setOf("libminecraftpe.so", "libc++_shared.so", "libfmod.so")
                    for (path in apkPaths) {
                        ZipFile(path).use { zip ->
                            zip.entries().asSequence()
                                .filter { !it.isDirectory && it.name.startsWith("lib/$abi/") }
                                .filter { it.name.substringAfterLast('/') in requiredLibs }
                                .forEach { entry ->
                                    val dest = File(outAbiDir, entry.name.substringAfterLast('/'))
                                    zip.getInputStream(entry).use { input ->
                                        dest.outputStream().use { output -> input.copyTo(output) }
                                    }
                                }
                        }
                    }
                    return outAbiDir
                }
            """.trimIndent()
        ),
        PatchSnippet(
            id = "classloader_hook",
            titleEn = "2. Bind Cache & Split APKs into Host ClassLoader",
            titleAr = "2. ربط الكاش وتقسيمات APK داخل مشغّل LeviLaunchroid",
            fileName = "LauncherClassLoaderFix.kt",
            languageBadge = "Kotlin",
            code = """
                // In LeviLaunchroid host Activity before instantiating com.mojang.minecraftpe.MainActivity
                fun buildGameClassLoader(
                    context: Context,
                    appInfo: ApplicationInfo,
                    extractedAbiDir: File
                ): ClassLoader {
                    val dexPaths = buildList {
                        appInfo.sourceDir?.let(::add)
                        appInfo.splitSourceDirs?.let { addAll(it) }
                    }.joinToString(File.pathSeparator)

                    val nativeLibSearchPath = listOfNotNull(
                        extractedAbiDir.absolutePath,
                        appInfo.nativeLibraryDir
                    ).joinToString(File.pathSeparator)

                    return PathClassLoader(
                        dexPaths,
                        nativeLibSearchPath,
                        context.classLoader.parent
                    )
                }
            """.trimIndent()
        ),
        PatchSnippet(
            id = "ndk_preload",
            titleEn = "3. C++ NDK Preload Order for Android 14/15/16",
            titleAr = "3. ترتيب تحميل المكتبات في C++ NDK لأندرويد 14/15/16",
            fileName = "levi_v126_hook.cpp",
            languageBadge = "C++ NDK",
            code = """
                #include <dlfcn.h>
                #include <string>

                bool preload_bedrock_libraries(const std::string& abi_cache_dir) {
                    const char* load_order[] = {
                        "libc++_shared.so",
                        "libfmod.so",
                        "libMediaDecoders_Android.so",
                        "libminecraftpe.so"
                    };
                    for (const char* lib : load_order) {
                        std::string full_path = abi_cache_dir + "/" + lib;
                        void* handle = dlopen(full_path.c_str(), RTLD_NOW | RTLD_GLOBAL);
                        if (!handle && std::string(lib) == "libminecraftpe.so") {
                            return false; // Log dlerror() to LeviLaunchroid launch console
                        }
                    }
                    return true;
                }
            """.trimIndent()
        ),
        PatchSnippet(
            id = "split_assets",
            titleEn = "4. Mount Split-APK Resources & Assets (v1.26.70.24)",
            titleAr = "4. ربط موارد وملفات Split APKs داخل AssetManager",
            fileName = "SplitAssetPatch.kt",
            languageBadge = "Kotlin",
            code = """
                // Fixes Resources${'$'}NotFoundException / black screen when launching Split APKs
                fun mountMinecraftAssets(hostAssets: AssetManager, appInfo: ApplicationInfo) {
                    val addAssetPath = AssetManager::class.java.getMethod(
                        "addAssetPath",
                        String::class.java
                    )
                    appInfo.sourceDir?.let { addAssetPath.invoke(hostAssets, it) }
                    appInfo.splitSourceDirs?.forEach { splitPath ->
                        if (splitPath.endsWith(".apk")) {
                            addAssetPath.invoke(hostAssets, splitPath)
                        }
                    }
                }
            """.trimIndent()
        ),
        PatchSnippet(
            id = "manifest_queries",
            titleEn = "5. AndroidManifest Queries for All 4 Package Types",
            titleAr = "5. تصاريح AndroidManifest لدعم جميع النسخ الأربع",
            fileName = "AndroidManifest.xml",
            languageBadge = "XML",
            code = """
                <queries>
                    <package android:name="com.mojang.minecraftpe.preview" />
                    <package android:name="com.mojang.minecraftpe" />
                    <package android:name="$cleanPkg" />
                </queries>
            """.trimIndent()
        )
    )
}
