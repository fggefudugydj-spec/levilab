package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.AppLanguage
import com.example.model.BedrockServerPreset
import com.example.model.CustomProfileSpec
import com.example.model.ModItem
import com.example.model.ModType
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "levilab_prefs")

data class LauncherPersistedPrefs(
    val selectedProfileId: String = "bedrock_preview_1_26_70_24",
    val targetAbiOverride: String = "AUTO",
    val language: AppLanguage = AppLanguage.AR,
    val disabledModIds: Set<String> = emptySet(),
    val customProfiles: List<CustomProfileSpec> = emptyList(),
    val customMods: List<ModItem> = emptyList(),
    val modOrderIds: List<String> = emptyList(),
    val savedServers: List<BedrockServerPreset> = defaultServers(),
    val linkedMojangTreeUri: String? = null,
    val launchInsideTask: Boolean = true,
    val autoSyncOptionsOnLaunch: Boolean = true
)

private fun defaultServers(): List<BedrockServerPreset> = listOf(
    BedrockServerPreset(
        id = "local_lan",
        name = "Localhost / LAN Bedrock",
        host = "127.0.0.1",
        port = 19132
    )
)

class LauncherPreferencesRepository(private val context: Context) {

    private object Keys {
        val SELECTED_PROFILE_ID = stringPreferencesKey("selected_profile_id")
        val TARGET_ABI_OVERRIDE = stringPreferencesKey("target_abi_override")
        val LANGUAGE = stringPreferencesKey("app_language")
        val DISABLED_MOD_IDS = stringSetPreferencesKey("disabled_mod_ids")
        val CUSTOM_PROFILES_JSON = stringPreferencesKey("custom_profiles_json")
        val CUSTOM_MODS_JSON = stringPreferencesKey("custom_mods_json")
        val MOD_ORDER_JSON = stringPreferencesKey("mod_order_json")
        val SAVED_SERVERS_JSON = stringPreferencesKey("saved_servers_json")
        val LINKED_MOJANG_TREE_URI = stringPreferencesKey("linked_mojang_tree_uri")
        val LAUNCH_INSIDE_TASK = booleanPreferencesKey("launch_inside_task")
        val AUTO_SYNC_OPTIONS_ON_LAUNCH = booleanPreferencesKey("auto_sync_options_on_launch")
    }

    val prefsFlow: Flow<LauncherPersistedPrefs> = context.dataStore.data.map { prefs ->
        val langCode = prefs[Keys.LANGUAGE] ?: AppLanguage.AR.code
        val serversRaw = prefs[Keys.SAVED_SERVERS_JSON]
        LauncherPersistedPrefs(
            selectedProfileId = prefs[Keys.SELECTED_PROFILE_ID] ?: "bedrock_preview_1_26_70_24",
            targetAbiOverride = prefs[Keys.TARGET_ABI_OVERRIDE] ?: "AUTO",
            language = if (langCode == AppLanguage.EN.code) AppLanguage.EN else AppLanguage.AR,
            disabledModIds = prefs[Keys.DISABLED_MOD_IDS] ?: emptySet(),
            customProfiles = parseCustomProfiles(prefs[Keys.CUSTOM_PROFILES_JSON]),
            customMods = parseCustomMods(prefs[Keys.CUSTOM_MODS_JSON]),
            modOrderIds = parseStringList(prefs[Keys.MOD_ORDER_JSON]),
            savedServers = if (serversRaw.isNullOrBlank()) defaultServers() else parseSavedServers(serversRaw),
            linkedMojangTreeUri = prefs[Keys.LINKED_MOJANG_TREE_URI],
            launchInsideTask = prefs[Keys.LAUNCH_INSIDE_TASK] ?: true,
            autoSyncOptionsOnLaunch = prefs[Keys.AUTO_SYNC_OPTIONS_ON_LAUNCH] ?: true
        )
    }

    suspend fun setLinkedMojangTreeUri(uriString: String?) {
        context.dataStore.edit {
            if (uriString == null) {
                it.remove(Keys.LINKED_MOJANG_TREE_URI)
            } else {
                it[Keys.LINKED_MOJANG_TREE_URI] = uriString
            }
        }
    }

    suspend fun setSelectedProfile(profileId: String) {
        context.dataStore.edit { it[Keys.SELECTED_PROFILE_ID] = profileId }
    }

    suspend fun setTargetAbiOverride(abi: String) {
        context.dataStore.edit { it[Keys.TARGET_ABI_OVERRIDE] = abi }
    }

    suspend fun setLanguage(language: AppLanguage) {
        context.dataStore.edit { it[Keys.LANGUAGE] = language.code }
    }

    suspend fun setDisabledModIds(disabledIds: Set<String>) {
        context.dataStore.edit { it[Keys.DISABLED_MOD_IDS] = disabledIds }
    }

    suspend fun addCustomProfile(spec: CustomProfileSpec, selectNow: Boolean = true) {
        context.dataStore.edit { prefs ->
            val current = parseCustomProfiles(prefs[Keys.CUSTOM_PROFILES_JSON]).toMutableList()
            current.removeAll { it.id == spec.id }
            current.add(spec)
            prefs[Keys.CUSTOM_PROFILES_JSON] = serializeCustomProfiles(current)
            if (selectNow) {
                prefs[Keys.SELECTED_PROFILE_ID] = spec.id
            }
        }
    }

    suspend fun removeCustomProfile(profileId: String) {
        context.dataStore.edit { prefs ->
            val current = parseCustomProfiles(prefs[Keys.CUSTOM_PROFILES_JSON]).filterNot { it.id == profileId }
            prefs[Keys.CUSTOM_PROFILES_JSON] = serializeCustomProfiles(current)
            if (prefs[Keys.SELECTED_PROFILE_ID] == profileId) {
                prefs[Keys.SELECTED_PROFILE_ID] = "bedrock_preview_1_26_70_24"
            }
        }
    }

    suspend fun setLaunchInsideTask(enabled: Boolean) {
        context.dataStore.edit { it[Keys.LAUNCH_INSIDE_TASK] = enabled }
    }

    suspend fun setAutoSyncOptionsOnLaunch(enabled: Boolean) {
        context.dataStore.edit { it[Keys.AUTO_SYNC_OPTIONS_ON_LAUNCH] = enabled }
    }

    suspend fun setModOrderIds(orderIds: List<String>) {
        context.dataStore.edit { prefs ->
            prefs[Keys.MOD_ORDER_JSON] = JSONArray(orderIds).toString()
        }
    }

    suspend fun addCustomMod(mod: ModItem) {
        context.dataStore.edit { prefs ->
            val current = parseCustomMods(prefs[Keys.CUSTOM_MODS_JSON]).toMutableList()
            current.add(mod)
            prefs[Keys.CUSTOM_MODS_JSON] = serializeCustomMods(current)
        }
    }

    suspend fun removeCustomMod(modId: String) {
        context.dataStore.edit { prefs ->
            val current = parseCustomMods(prefs[Keys.CUSTOM_MODS_JSON]).filterNot { it.id == modId }
            prefs[Keys.CUSTOM_MODS_JSON] = serializeCustomMods(current)
            val disabled = (prefs[Keys.DISABLED_MOD_IDS] ?: emptySet()) - modId
            prefs[Keys.DISABLED_MOD_IDS] = disabled
            val order = parseStringList(prefs[Keys.MOD_ORDER_JSON]).filterNot { it == modId }
            prefs[Keys.MOD_ORDER_JSON] = JSONArray(order).toString()
        }
    }

    suspend fun addSavedServer(server: BedrockServerPreset) {
        context.dataStore.edit { prefs ->
            val current = (if (prefs[Keys.SAVED_SERVERS_JSON].isNullOrBlank()) {
                defaultServers()
            } else {
                parseSavedServers(prefs[Keys.SAVED_SERVERS_JSON])
            }).toMutableList()
            current.removeAll { it.id == server.id || (it.host == server.host && it.port == server.port) }
            current.add(0, server)
            prefs[Keys.SAVED_SERVERS_JSON] = serializeSavedServers(current)
        }
    }

    suspend fun removeSavedServer(serverId: String) {
        context.dataStore.edit { prefs ->
            val current = parseSavedServers(prefs[Keys.SAVED_SERVERS_JSON]).filterNot { it.id == serverId }
            prefs[Keys.SAVED_SERVERS_JSON] = serializeSavedServers(current)
        }
    }

    private fun serializeCustomProfiles(list: List<CustomProfileSpec>): String {
        val arr = JSONArray()
        list.forEach { item ->
            arr.put(
                JSONObject().apply {
                    put("id", item.id)
                    put("displayName", item.displayName)
                    put("versionName", item.versionName)
                    put("packageName", item.packageName)
                    put("isolatedDataEnabled", item.isolatedDataEnabled)
                }
            )
        }
        return arr.toString()
    }

    private fun parseCustomProfiles(raw: String?): List<CustomProfileSpec> {
        if (raw.isNullOrBlank()) return emptyList()
        return try {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    add(
                        CustomProfileSpec(
                            id = obj.getString("id"),
                            displayName = obj.getString("displayName"),
                            versionName = obj.getString("versionName"),
                            packageName = obj.getString("packageName"),
                            isolatedDataEnabled = obj.optBoolean("isolatedDataEnabled", true)
                        )
                    )
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun serializeCustomMods(list: List<ModItem>): String {
        val arr = JSONArray()
        list.forEach { mod ->
            arr.put(
                JSONObject().apply {
                    put("id", mod.id)
                    put("name", mod.name)
                    put("author", mod.author)
                    put("version", mod.version)
                    put("type", mod.type.name)
                    put("requiredAbi", mod.requiredAbi)
                    put("enabled", mod.enabled)
                    put("loadOrder", mod.loadOrder)
                    put("descriptionEn", mod.descriptionEn)
                    put("descriptionAr", mod.descriptionAr)
                    mod.stagedFilePath?.let { put("stagedFilePath", it) }
                    mod.minEngineVersion?.let { put("minEngineVersion", it) }
                    put("isCustomAdded", mod.isCustomAdded)
                    mod.is16KbAligned?.let { put("is16KbAligned", it) }
                    if (mod.neededLibraries.isNotEmpty()) {
                        put("neededLibraries", JSONArray(mod.neededLibraries))
                    }
                }
            )
        }
        return arr.toString()
    }

    private fun parseCustomMods(raw: String?): List<ModItem> {
        if (raw.isNullOrBlank()) return emptyList()
        return try {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val modType = runCatching { ModType.valueOf(obj.getString("type")) }.getOrDefault(ModType.NATIVE_SO)
                    val aligned = if (obj.has("is16KbAligned")) obj.optBoolean("is16KbAligned") else null
                    val neededArr = obj.optJSONArray("neededLibraries")
                    val neededList = buildList {
                        if (neededArr != null) {
                            for (j in 0 until neededArr.length()) {
                                neededArr.optString(j).takeIf { it.isNotBlank() }?.let { add(it) }
                            }
                        }
                    }
                    add(
                        ModItem(
                            id = obj.getString("id"),
                            name = obj.getString("name"),
                            author = obj.optString("author", "Local"),
                            version = obj.optString("version", "1.0.0"),
                            type = modType,
                            requiredAbi = obj.optString("requiredAbi", "arm64-v8a"),
                            enabled = obj.optBoolean("enabled", true),
                            loadOrder = obj.optInt("loadOrder", 10 + i),
                            descriptionEn = obj.optString("descriptionEn", ""),
                            descriptionAr = obj.optString("descriptionAr", ""),
                            stagedFilePath = obj.optString("stagedFilePath").takeIf { it.isNotBlank() },
                            minEngineVersion = obj.optString("minEngineVersion").takeIf { it.isNotBlank() },
                            isCustomAdded = obj.optBoolean("isCustomAdded", true),
                            is16KbAligned = aligned,
                            neededLibraries = neededList
                        )
                    )
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun parseStringList(raw: String?): List<String> {
        if (raw.isNullOrBlank()) return emptyList()
        return try {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    arr.optString(i).takeIf { it.isNotBlank() }?.let { add(it) }
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun serializeSavedServers(list: List<BedrockServerPreset>): String {
        val arr = JSONArray()
        list.forEach { s ->
            arr.put(
                JSONObject().apply {
                    put("id", s.id)
                    put("name", s.name)
                    put("host", s.host)
                    put("port", s.port)
                }
            )
        }
        return arr.toString()
    }

    private fun parseSavedServers(raw: String?): List<BedrockServerPreset> {
        if (raw.isNullOrBlank()) return emptyList()
        return try {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    add(
                        BedrockServerPreset(
                            id = obj.getString("id"),
                            name = obj.getString("name"),
                            host = obj.getString("host"),
                            port = obj.optInt("port", 19132)
                        )
                    )
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }
}
