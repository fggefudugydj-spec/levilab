package com.example.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.nio.ByteBuffer
import java.nio.ByteOrder

data class RakNetPongResult(
    val host: String,
    val port: Int,
    val isOnline: Boolean,
    val latencyMs: Long = -1L,
    val edition: String = "",
    val motd: String = "",
    val protocolVersion: Int = 0,
    val gameVersion: String = "",
    val playerCount: Int = 0,
    val maxPlayers: Int = 0,
    val worldName: String = "",
    val gameMode: String = "",
    val errorMessage: String? = null
)

object BedrockRakNetPinger {

    private val RAKNET_OFFLINE_MAGIC = byteArrayOf(
        0x00, 0xff.toByte(), 0xff.toByte(), 0x00,
        0xfe.toByte(), 0xfe.toByte(), 0xfe.toByte(), 0xfe.toByte(),
        0xfd.toByte(), 0xfd.toByte(), 0xfd.toByte(), 0xfd.toByte(),
        0x12, 0x34, 0x56, 0x78
    )

    private const val ID_UNCONNECTED_PING: Byte = 0x01
    private const val ID_UNCONNECTED_PONG: Byte = 0x1c

    fun buildUnconnectedPingPacket(timestampMs: Long = System.currentTimeMillis(), clientGuid: Long = 0x4C6576694C6162L): ByteArray {
        val buf = ByteBuffer.allocate(1 + 8 + 16 + 8).order(ByteOrder.BIG_ENDIAN)
        buf.put(ID_UNCONNECTED_PING)
        buf.putLong(timestampMs)
        buf.put(RAKNET_OFFLINE_MAGIC)
        buf.putLong(clientGuid)
        return buf.array()
    }

    fun parseUnconnectedPongPacket(host: String, port: Int, packetBytes: ByteArray, length: Int, latencyMs: Long): RakNetPongResult? {
        if (length < 35) return null
        if (packetBytes[0] != ID_UNCONNECTED_PONG) return null
        val buf = ByteBuffer.wrap(packetBytes, 0, length).order(ByteOrder.BIG_ENDIAN)
        buf.get() // packet id 0x1c
        buf.getLong() // ping time
        buf.getLong() // server guid
        buf.position(buf.position() + 16) // magic
        if (buf.remaining() < 2) return null
        val strLen = buf.short.toInt() and 0xFFFF
        if (strLen <= 0 || buf.remaining() < strLen) return null
        val strBytes = ByteArray(strLen)
        buf.get(strBytes)
        val payload = strBytes.decodeToString()
        return parseMotdString(host, port, payload, latencyMs)
    }

    fun parseMotdString(host: String, port: Int, payload: String, latencyMs: Long): RakNetPongResult {
        val parts = payload.split(';')
        return RakNetPongResult(
            host = host,
            port = port,
            isOnline = true,
            latencyMs = latencyMs.coerceAtLeast(1L),
            edition = parts.getOrElse(0) { "MCPE" },
            motd = cleanMinecraftFormatting(parts.getOrElse(1) { "Bedrock Server" }),
            protocolVersion = parts.getOrNull(2)?.toIntOrNull() ?: 0,
            gameVersion = parts.getOrElse(3) { "" },
            playerCount = parts.getOrNull(4)?.toIntOrNull() ?: 0,
            maxPlayers = parts.getOrNull(5)?.toIntOrNull() ?: 0,
            worldName = cleanMinecraftFormatting(parts.getOrElse(7) { "" }),
            gameMode = parts.getOrElse(8) { "" }
        )
    }

    private fun cleanMinecraftFormatting(input: String): String {
        return input.replace(Regex("§."), "").trim()
    }

    suspend fun pingServer(host: String, port: Int, timeoutMs: Int = 2200): RakNetPongResult =
        withContext(Dispatchers.IO) {
            val cleanHost = host.trim()
            if (cleanHost.isEmpty()) {
                return@withContext RakNetPongResult(cleanHost, port, false, errorMessage = "Empty host")
            }
            var socket: DatagramSocket? = null
            try {
                val address = InetAddress.getByName(cleanHost)
                socket = DatagramSocket().apply {
                    soTimeout = timeoutMs
                }
                val pingData = buildUnconnectedPingPacket()
                val sendPacket = DatagramPacket(pingData, pingData.size, address, port)
                val recvBuf = ByteArray(2048)
                val recvPacket = DatagramPacket(recvBuf, recvBuf.size)

                val t0 = System.nanoTime()
                socket.send(sendPacket)
                socket.receive(recvPacket)
                val rttMs = (System.nanoTime() - t0) / 1_000_000L

                parseUnconnectedPongPacket(cleanHost, port, recvPacket.data, recvPacket.length, rttMs)
                    ?: RakNetPongResult(cleanHost, port, false, errorMessage = "Invalid RakNet pong payload")
            } catch (e: Exception) {
                RakNetPongResult(
                    host = cleanHost,
                    port = port,
                    isOnline = false,
                    errorMessage = e.message ?: "Timeout"
                )
            } finally {
                runCatching { socket?.close() }
            }
        }
}
