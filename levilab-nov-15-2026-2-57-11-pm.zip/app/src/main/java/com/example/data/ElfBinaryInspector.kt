package com.example.data

import java.io.ByteArrayOutputStream
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

data class ElfBinaryReport(
    val isValidElf: Boolean,
    val archLabel: String,
    val is64Bit: Boolean = false,
    val elfMachine: Int = 0,
    val fileSizeBytes: Long = 0L,
    val meetsMinSize1Mb: Boolean = false,
    val maxLoadAlignBytes: Long = 0L,
    val is16KbAligned: Boolean = false,
    val neededLibraries: List<String> = emptyList(),
    val jniSymbols: List<String> = emptyList(),
    val totalJniSymbolCount: Int = 0
)

data class OrderedNativeDependency(
    val libraryName: String,
    val localFilePath: String?,
    val isSystemLibrary: Boolean,
    val neededBy: List<String>
)

object ElfBinaryInspector {

    const val MIN_VERIFIED_LIB_BYTES: Long = 1L * 1024L * 1024L

    private const val PT_LOAD = 1
    private const val PT_DYNAMIC = 2
    private const val DT_NULL = 0L
    private const val DT_NEEDED = 1L
    private const val DT_HASH = 4L
    private const val DT_STRTAB = 5L
    private const val DT_SYMTAB = 6L
    private const val DT_STRSZ = 10L
    private const val DT_SYMENT = 11L

    private const val SHT_STRTAB = 3
    private const val SHT_DYNSYM = 11

    private val SYSTEM_NDK_LIBS = setOf(
        "libc.so",
        "libm.so",
        "libdl.so",
        "liblog.so",
        "libandroid.so",
        "libEGL.so",
        "libGLESv1_CM.so",
        "libGLESv2.so",
        "libGLESv3.so",
        "libOpenSLES.so",
        "libz.so",
        "libjnigraphics.so",
        "libvulkan.so",
        "libaaudio.so",
        "libmediandk.so",
        "libcamera2ndk.so",
        "libnativewindow.so",
        "libstdc++.so",
        "libneuralnetworks.so",
        "libsync.so",
        "libbinder_ndk.so"
    )

    fun expectedMachineForAbi(abi: String): Int? = when (abi) {
        "arm64-v8a" -> 183
        "armeabi-v7a" -> 40
        "x86_64" -> 62
        "x86" -> 3
        else -> null
    }

    fun matchesAbi(report: ElfBinaryReport, targetAbi: String): Boolean {
        if (!report.isValidElf) return false
        val expectedMachine = expectedMachineForAbi(targetAbi) ?: return true
        return report.elfMachine == expectedMachine
    }

    fun inspectHeaderOnly(bytes: ByteArray): ElfBinaryReport {
        if (bytes.size < 20) return ElfBinaryReport(false, "Unknown Binary")
        val isElf = bytes[0] == 0x7F.toByte() &&
            bytes[1] == 'E'.code.toByte() &&
            bytes[2] == 'L'.code.toByte() &&
            bytes[3] == 'F'.code.toByte()
        if (!isElf) return ElfBinaryReport(false, "Non-ELF")

        val eiClass = bytes[4].toInt() and 0xFF
        val is64 = eiClass == 2
        val bitness = when (eiClass) {
            1 -> "ELF32"
            2 -> "ELF64"
            else -> "ELF?"
        }
        val machine = ((bytes[19].toInt() and 0xFF) shl 8) or (bytes[18].toInt() and 0xFF)
        val archName = when (machine) {
            183 -> "AArch64 (arm64-v8a)"
            40 -> "ARM (armeabi-v7a)"
            62 -> "x86-64"
            3 -> "x86"
            else -> "Machine#$machine"
        }
        return ElfBinaryReport(
            isValidElf = true,
            archLabel = "$bitness $archName",
            is64Bit = is64,
            elfMachine = machine
        )
    }

    // Inspects an ELF32/ELF64 binary via RandomAccessFile without loading large .so files into heap.
    // Extracts PT_LOAD alignment, DT_NEEDED dependencies, and JNI symbols (Java_* / JNI_OnLoad*).
    fun inspectElfFile(file: File, includeJniSymbols: Boolean = false, maxJniSymbols: Int = 600): ElfBinaryReport {
        if (!file.exists() || !file.canRead() || file.length() < 64L) {
            return ElfBinaryReport(false, "Unreadable", fileSizeBytes = if (file.exists()) file.length() else 0L)
        }
        val fileLen = file.length()
        return runCatching {
            RandomAccessFile(file, "r").use { raf ->
                val ehdr = ByteArray(64)
                val read = raf.read(ehdr)
                if (read < 52) return ElfBinaryReport(false, "Truncated ELF", fileSizeBytes = fileLen)

                val basic = inspectHeaderOnly(ehdr).copy(
                    fileSizeBytes = fileLen,
                    meetsMinSize1Mb = fileLen > MIN_VERIFIED_LIB_BYTES
                )
                if (!basic.isValidElf) return basic

                val buf = ByteBuffer.wrap(ehdr).order(ByteOrder.LITTLE_ENDIAN)
                val is64 = basic.is64Bit
                val phoff: Long
                val shoff: Long
                val phentsize: Int
                val phnum: Int
                val shentsize: Int
                val shnum: Int

                if (is64) {
                    if (read < 64) return basic
                    phoff = buf.getLong(32)
                    shoff = buf.getLong(40)
                    phentsize = buf.getShort(54).toInt() and 0xFFFF
                    phnum = buf.getShort(56).toInt() and 0xFFFF
                    shentsize = buf.getShort(58).toInt() and 0xFFFF
                    shnum = buf.getShort(60).toInt() and 0xFFFF
                } else {
                    phoff = buf.getInt(28).toLong() and 0xFFFFFFFFL
                    shoff = buf.getInt(32).toLong() and 0xFFFFFFFFL
                    phentsize = buf.getShort(42).toInt() and 0xFFFF
                    phnum = buf.getShort(44).toInt() and 0xFFFF
                    shentsize = buf.getShort(46).toInt() and 0xFFFF
                    shnum = buf.getShort(48).toInt() and 0xFFFF
                }

                if (phoff <= 0L || phnum <= 0 || phnum > 256 || phentsize < 32) {
                    return basic
                }

                data class LoadSeg(val vaddr: Long, val offset: Long, val filesz: Long)
                val loadSegments = mutableListOf<LoadSeg>()
                var maxLoadAlign = 0L
                var dynamicOffset = -1L
                var dynamicSize = 0L

                val phTableBytes = ByteArray(phentsize * phnum)
                raf.seek(phoff)
                raf.readFully(phTableBytes)
                val phBuf = ByteBuffer.wrap(phTableBytes).order(ByteOrder.LITTLE_ENDIAN)

                for (i in 0 until phnum) {
                    val base = i * phentsize
                    val pType = phBuf.getInt(base)
                    if (is64 && phentsize >= 56) {
                        val pOffset = phBuf.getLong(base + 8)
                        val pVaddr = phBuf.getLong(base + 16)
                        val pFilesz = phBuf.getLong(base + 32)
                        val pAlign = phBuf.getLong(base + 48)
                        if (pType == PT_LOAD) {
                            if (pAlign > maxLoadAlign) maxLoadAlign = pAlign
                            loadSegments.add(LoadSeg(pVaddr, pOffset, pFilesz))
                        } else if (pType == PT_DYNAMIC) {
                            dynamicOffset = pOffset
                            dynamicSize = pFilesz
                        }
                    } else if (!is64 && phentsize >= 32) {
                        val pOffset = phBuf.getInt(base + 4).toLong() and 0xFFFFFFFFL
                        val pVaddr = phBuf.getInt(base + 8).toLong() and 0xFFFFFFFFL
                        val pFilesz = phBuf.getInt(base + 16).toLong() and 0xFFFFFFFFL
                        val pAlign = phBuf.getInt(base + 28).toLong() and 0xFFFFFFFFL
                        if (pType == PT_LOAD) {
                            if (pAlign > maxLoadAlign) maxLoadAlign = pAlign
                            loadSegments.add(LoadSeg(pVaddr, pOffset, pFilesz))
                        } else if (pType == PT_DYNAMIC) {
                            dynamicOffset = pOffset
                            dynamicSize = pFilesz
                        }
                    }
                }

                fun vaddrToFileOffset(vaddr: Long): Long? {
                    val seg = loadSegments.firstOrNull {
                        vaddr >= it.vaddr && vaddr < (it.vaddr + it.filesz)
                    } ?: return null
                    return seg.offset + (vaddr - seg.vaddr)
                }

                val neededOffsets = mutableListOf<Long>()
                var strtabVaddr = -1L
                var strtabSize = 0L
                var symtabVaddr = -1L
                var symentSize = if (is64) 24L else 16L
                var hashVaddr = -1L

                if (dynamicOffset > 0L && dynamicSize in 16L..(2 * 1024 * 1024L)) {
                    val dynBytes = ByteArray(dynamicSize.toInt())
                    raf.seek(dynamicOffset)
                    raf.readFully(dynBytes)
                    val dynBuf = ByteBuffer.wrap(dynBytes).order(ByteOrder.LITTLE_ENDIAN)
                    val entrySize = if (is64) 16 else 8
                    var pos = 0
                    while (pos + entrySize <= dynBytes.size) {
                        val tag = if (is64) dynBuf.getLong(pos) else dynBuf.getInt(pos).toLong()
                        val value = if (is64) dynBuf.getLong(pos + 8) else (dynBuf.getInt(pos + 4).toLong() and 0xFFFFFFFFL)
                        if (tag == DT_NULL) break
                        when (tag) {
                            DT_NEEDED -> neededOffsets.add(value)
                            DT_STRTAB -> strtabVaddr = value
                            DT_STRSZ -> strtabSize = value
                            DT_SYMTAB -> symtabVaddr = value
                            DT_SYMENT -> if (value > 0L) symentSize = value
                            DT_HASH -> hashVaddr = value
                        }
                        pos += entrySize
                    }
                }

                val neededLibs = mutableListOf<String>()
                var strtabFileOffset = if (strtabVaddr >= 0L) vaddrToFileOffset(strtabVaddr) else null

                // Fallback to section headers if PT_DYNAMIC didn't resolve strtab
                var dynsymFileOffset: Long? = if (symtabVaddr >= 0L) vaddrToFileOffset(symtabVaddr) else null
                var dynsymCount = 0L
                if ((strtabFileOffset == null || strtabSize <= 0L || dynsymFileOffset == null) &&
                    shoff > 0L && shnum in 1..256 && shentsize >= 40 && shoff + shentsize.toLong() * shnum <= fileLen
                ) {
                    val shBytes = ByteArray(shentsize * shnum)
                    raf.seek(shoff)
                    raf.readFully(shBytes)
                    val shBuf = ByteBuffer.wrap(shBytes).order(ByteOrder.LITTLE_ENDIAN)
                    val secTypes = IntArray(shnum)
                    val secOffsets = LongArray(shnum)
                    val secSizes = LongArray(shnum)
                    val secLinks = IntArray(shnum)
                    val secEntSizes = LongArray(shnum)
                    for (i in 0 until shnum) {
                        val b = i * shentsize
                        secTypes[i] = shBuf.getInt(b + 4)
                        if (is64 && shentsize >= 64) {
                            secOffsets[i] = shBuf.getLong(b + 24)
                            secSizes[i] = shBuf.getLong(b + 32)
                            secLinks[i] = shBuf.getInt(b + 40)
                            secEntSizes[i] = shBuf.getLong(b + 56)
                        } else if (!is64 && shentsize >= 40) {
                            secOffsets[i] = shBuf.getInt(b + 16).toLong() and 0xFFFFFFFFL
                            secSizes[i] = shBuf.getInt(b + 20).toLong() and 0xFFFFFFFFL
                            secLinks[i] = shBuf.getInt(b + 24)
                            secEntSizes[i] = shBuf.getInt(b + 36).toLong() and 0xFFFFFFFFL
                        }
                    }
                    val dynsymIdx = secTypes.indexOfFirst { it == SHT_DYNSYM }
                    if (dynsymIdx >= 0) {
                        dynsymFileOffset = secOffsets[dynsymIdx]
                        val es = secEntSizes[dynsymIdx].takeIf { it > 0L } ?: symentSize
                        symentSize = es
                        dynsymCount = secSizes[dynsymIdx] / es
                        val linkedStrIdx = secLinks[dynsymIdx]
                        if (linkedStrIdx in 0 until shnum && secTypes[linkedStrIdx] == SHT_STRTAB) {
                            if (strtabFileOffset == null) strtabFileOffset = secOffsets[linkedStrIdx]
                            if (strtabSize <= 0L) strtabSize = secSizes[linkedStrIdx]
                        }
                    }
                }

                // Read each DT_NEEDED string directly by seeking to strtabFileOffset + off (no 4MB limit)
                if (strtabFileOffset != null) {
                    for (off in neededOffsets) {
                        if (off >= 0L && (strtabSize <= 0L || off < strtabSize)) {
                            val name = readCStringAt(raf, strtabFileOffset + off, fileLen)
                            if (name.isNotBlank()) neededLibs.add(name)
                        }
                    }
                }

                val jniList = mutableListOf<String>()
                var jniTotal = 0
                if (includeJniSymbols && strtabFileOffset != null && strtabSize > 0L) {
                    if (dynsymCount <= 0L && hashVaddr >= 0L) {
                        val hashOff = vaddrToFileOffset(hashVaddr)
                        if (hashOff != null && hashOff + 8L <= fileLen) {
                            val hBuf = ByteArray(8)
                            raf.seek(hashOff)
                            raf.readFully(hBuf)
                            dynsymCount = ByteBuffer.wrap(hBuf).order(ByteOrder.LITTLE_ENDIAN).getInt(4).toLong() and 0xFFFFFFFFL
                        }
                    }

                    if (dynsymFileOffset != null && dynsymCount in 1L..2_000_000L && symentSize >= 16L) {
                        val result = scanDynsymForJni(
                            raf = raf,
                            dynsymOffset = dynsymFileOffset,
                            dynsymCount = dynsymCount,
                            symentSize = symentSize,
                            is64 = is64,
                            strtabOffset = strtabFileOffset,
                            strtabSize = strtabSize,
                            fileLen = fileLen,
                            maxCollect = maxJniSymbols
                        )
                        jniList.addAll(result.first)
                        jniTotal = result.second
                    }
                    if (jniList.isEmpty()) {
                        val result = scanDynstrForJni(
                            raf = raf,
                            strtabOffset = strtabFileOffset,
                            strtabSize = strtabSize,
                            fileLen = fileLen,
                            maxCollect = maxJniSymbols
                        )
                        jniList.addAll(result.first)
                        jniTotal = result.second
                    }
                }

                basic.copy(
                    maxLoadAlignBytes = maxLoadAlign,
                    is16KbAligned = maxLoadAlign >= 16384L,
                    neededLibraries = neededLibs.distinct(),
                    jniSymbols = jniList,
                    totalJniSymbolCount = jniTotal
                )
            }
        }.getOrElse {
            ElfBinaryReport(false, "Error: ${it.message}", fileSizeBytes = fileLen)
        }
    }

    private fun isJniSymbolName(name: String): Boolean {
        return name.startsWith("Java_") || name == "JNI_OnLoad" || name == "JNI_OnUnload"
    }

    private fun scanDynsymForJni(
        raf: RandomAccessFile,
        dynsymOffset: Long,
        dynsymCount: Long,
        symentSize: Long,
        is64: Boolean,
        strtabOffset: Long,
        strtabSize: Long,
        fileLen: Long,
        maxCollect: Int
    ): Pair<List<String>, Int> {
        val collected = LinkedHashSet<String>()
        var totalCount = 0
        val batchEntries = 1024
        val esInt = symentSize.toInt()
        val buf = ByteArray(batchEntries * esInt)
        var index = 0L
        while (index < dynsymCount) {
            val remaining = (dynsymCount - index).coerceAtMost(batchEntries.toLong()).toInt()
            val byteOffset = dynsymOffset + index * symentSize
            if (byteOffset + remaining * symentSize > fileLen) break
            raf.seek(byteOffset)
            raf.readFully(buf, 0, remaining * esInt)
            val bb = ByteBuffer.wrap(buf, 0, remaining * esInt).order(ByteOrder.LITTLE_ENDIAN)
            for (i in 0 until remaining) {
                val base = i * esInt
                val stName = bb.getInt(base).toLong() and 0xFFFFFFFFL
                val stShndx = if (is64) {
                    bb.getShort(base + 6).toInt() and 0xFFFF
                } else {
                    bb.getShort(base + 14).toInt() and 0xFFFF
                }
                if (stShndx != 0 && stName in 1L until strtabSize) {
                    val symName = readCStringAt(raf, strtabOffset + stName, fileLen, maxLen = 512)
                    if (isJniSymbolName(symName)) {
                        totalCount++
                        if (collected.size < maxCollect) collected.add(symName)
                    }
                }
            }
            index += remaining
        }
        return collected.toList() to totalCount
    }

    private fun scanDynstrForJni(
        raf: RandomAccessFile,
        strtabOffset: Long,
        strtabSize: Long,
        fileLen: Long,
        maxCollect: Int
    ): Pair<List<String>, Int> {
        val collected = LinkedHashSet<String>()
        var totalCount = 0
        val safeEnd = (strtabOffset + strtabSize).coerceAtMost(fileLen)
        if (safeEnd <= strtabOffset) return emptyList<String>() to 0

        val chunk = ByteArray(64 * 1024)
        val currentWord = ByteArrayOutputStream(256)
        var cursor = strtabOffset
        raf.seek(cursor)
        while (cursor < safeEnd) {
            val toRead = (safeEnd - cursor).coerceAtMost(chunk.size.toLong()).toInt()
            val n = raf.read(chunk, 0, toRead)
            if (n <= 0) break
            for (i in 0 until n) {
                val b = chunk[i]
                if (b == 0.toByte()) {
                    if (currentWord.size() > 0) {
                        val s = currentWord.toString("UTF-8")
                        if (isJniSymbolName(s)) {
                            totalCount++
                            if (collected.size < maxCollect) collected.add(s)
                        }
                        currentWord.reset()
                    }
                } else if (currentWord.size() < 512) {
                    currentWord.write(b.toInt())
                }
            }
            cursor += n
        }
        return collected.toList() to totalCount
    }

    private fun readCStringAt(raf: RandomAccessFile, offset: Long, fileLen: Long, maxLen: Int = 512): String {
        if (offset < 0L || offset >= fileLen) return ""
        val savedPos = raf.filePointer
        return try {
            raf.seek(offset)
            val bytes = ByteArray(maxLen.coerceAtMost((fileLen - offset).toInt()))
            val read = raf.read(bytes)
            if (read <= 0) return ""
            var end = 0
            while (end < read && bytes[end] != 0.toByte()) end++
            String(bytes, 0, end, Charsets.UTF_8)
        } finally {
            raf.seek(savedPos)
        }
    }

    // Resolves DT_NEEDED dependencies recursively across extracted local .so files in [abiDir]
    // and returns them in topological load order (leaves first, target library last).
    fun resolveTopologicalLoadOrder(
        abiDir: File,
        targetLibName: String = "libminecraftpe.so"
    ): List<OrderedNativeDependency> {
        val localSoFiles = abiDir.listFiles()
            ?.filter { it.isFile && it.name.endsWith(".so") }
            ?.associateBy { it.name }
            .orEmpty()

        val visited = mutableSetOf<String>()
        val visiting = mutableSetOf<String>()
        val ordered = mutableListOf<OrderedNativeDependency>()
        val neededByMap = mutableMapOf<String, MutableSet<String>>()

        fun dfs(libName: String) {
            if (libName in visited || libName in visiting) return
            visiting.add(libName)
            val localFile = localSoFiles[libName]
            if (localFile != null) {
                val report = inspectElfFile(localFile, includeJniSymbols = false)
                for (dep in report.neededLibraries) {
                    neededByMap.getOrPut(dep) { linkedSetOf() }.add(libName)
                    dfs(dep)
                }
            }
            visiting.remove(libName)
            visited.add(libName)
            val isSys = localFile == null && (libName in SYSTEM_NDK_LIBS || !localSoFiles.containsKey(libName))
            ordered.add(
                OrderedNativeDependency(
                    libraryName = libName,
                    localFilePath = localFile?.absolutePath,
                    isSystemLibrary = isSys,
                    neededBy = neededByMap[libName]?.toList().orEmpty()
                )
            )
        }

        dfs(targetLibName)
        return ordered
    }
}
