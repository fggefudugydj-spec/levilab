package com.example.data

import android.content.Context
import com.example.model.LaunchLogEntry
import com.example.model.LogLevel
import java.io.File
import java.io.FileOutputStream
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class PersistentLaunchLogger(private val context: Context) {

    private val logsDir: File
        get() = File(context.filesDir, "launch_logs").apply {
            if (!exists()) mkdirs()
        }

    val latestLogFile: File
        get() = File(logsDir, "launch_session_latest.log")

    private val activeMarkerFile: File
        get() = File(logsDir, "launch_active_marker.txt")

    private val lock = Any()

    fun recoverInterruptedRiskyStepIfAny(): String? = synchronized(lock) {
        if (!activeMarkerFile.exists()) return@synchronized null
        val pendingStep = runCatching { activeMarkerFile.readText().trim() }.getOrNull()
        runCatching { activeMarkerFile.delete() }
        if (!pendingStep.isNullOrBlank()) {
            appendRawLine(
                level = LogLevel.ERROR,
                stage = "CRASH",
                message = "Previous process terminated abruptly (likely native SIGSEGV/SIGABRT or process kill) during: $pendingStep"
            )
        }
        pendingStep
    }

    fun startNewSession(sessionTitle: String) = synchronized(lock) {
        runCatching { activeMarkerFile.delete() }
        // Trim only if log file grew past 512 KB to keep disk bounded while preserving crash history
        runCatching {
            if (latestLogFile.exists() && latestLogFile.length() > 512 * 1024L) {
                val tailLines = latestLogFile.readLines(Charsets.UTF_8).takeLast(400)
                latestLogFile.writeText(tailLines.joinToString("\n", postfix = "\n"), Charsets.UTF_8)
            }
        }
        val header = buildString {
            append("=== LeviLab Session @ ")
            append(fullDateFormat().format(Date()))
            append(" | ")
            append(sessionTitle)
            appendLine(" ===")
        }
        runCatching {
            FileOutputStream(latestLogFile, true).use { fos ->
                fos.write(header.toByteArray(Charsets.UTF_8))
                fos.flush()
                runCatching { fos.fd.sync() }
            }
        }
    }

    fun clearLog() = synchronized(lock) {
        runCatching { activeMarkerFile.delete() }
        runCatching {
            if (latestLogFile.exists()) {
                latestLogFile.writeText("", Charsets.UTF_8)
            }
        }
    }

    fun append(level: LogLevel, stage: String, message: String): LaunchLogEntry = synchronized(lock) {
        val ts = timeFormat().format(Date())
        appendFormattedLine("[$ts] [$stage] [${level.name}] $message")
        LaunchLogEntry(
            id = System.nanoTime(),
            timestamp = ts,
            level = level,
            message = "[$stage] $message"
        )
    }

    fun markPendingRiskyCall(stepDescription: String) = synchronized(lock) {
        runCatching {
            FileOutputStream(activeMarkerFile, false).use { fos ->
                fos.write(stepDescription.toByteArray(Charsets.UTF_8))
                fos.flush()
                runCatching { fos.fd.sync() }
            }
        }
    }

    fun clearPendingRiskyCall() = synchronized(lock) {
        runCatching {
            if (activeMarkerFile.exists()) activeMarkerFile.delete()
        }
    }

    fun recordUncaughtCrash(threadName: String, throwable: Throwable) = synchronized(lock) {
        val sw = StringWriter()
        throwable.printStackTrace(PrintWriter(sw))
        val pending = if (activeMarkerFile.exists()) {
            runCatching { activeMarkerFile.readText().trim() }.getOrNull()
        } else null
        runCatching { activeMarkerFile.delete() }
        val ts = timeFormat().format(Date())
        val block = buildString {
            appendLine("[$ts] [CRASH] [ERROR] Uncaught exception on thread '$threadName'${if (!pending.isNullOrBlank()) " during '$pending'" else ""}:")
            appendLine(sw.toString().trimEnd())
        }
        runCatching {
            FileOutputStream(latestLogFile, true).use { fos ->
                fos.write(block.toByteArray(Charsets.UTF_8))
                fos.flush()
                runCatching { fos.fd.sync() }
            }
        }
    }

    fun readFullLogText(): String = synchronized(lock) {
        if (!latestLogFile.exists()) return@synchronized ""
        runCatching { latestLogFile.readText(Charsets.UTF_8) }.getOrDefault("")
    }

    fun readPersistedEntries(): List<LaunchLogEntry> = synchronized(lock) {
        if (!latestLogFile.exists()) return@synchronized emptyList()
        val lines = runCatching { latestLogFile.readLines(Charsets.UTF_8) }.getOrDefault(emptyList())
        lines.mapIndexedNotNull { idx, raw ->
            val trimmed = raw.trimEnd()
            if (trimmed.isBlank()) return@mapIndexedNotNull null
            val level = when {
                trimmed.contains("[ERROR]") || trimmed.contains("Exception") || trimmed.contains("Error") -> LogLevel.ERROR
                trimmed.contains("[WARN]") -> LogLevel.WARN
                trimmed.contains("[SUCCESS]") -> LogLevel.SUCCESS
                trimmed.contains("[FIX]") -> LogLevel.FIX
                else -> LogLevel.INFO
            }
            val tsMatch = Regex("^\\[(\\d{2}:\\d{2}:\\d{2})]").find(trimmed)
            val ts = tsMatch?.groupValues?.getOrNull(1) ?: "--:--:--"
            val body = if (tsMatch != null) {
                trimmed.removePrefix(tsMatch.value).trimStart()
            } else {
                trimmed
            }
            LaunchLogEntry(
                id = idx.toLong() + 1L,
                timestamp = ts,
                level = level,
                message = body
            )
        }
    }

    private fun appendRawLine(level: LogLevel, stage: String, message: String) {
        val ts = timeFormat().format(Date())
        appendFormattedLine("[$ts] [$stage] [${level.name}] $message")
    }

    private fun appendFormattedLine(line: String) {
        runCatching {
            FileOutputStream(latestLogFile, true).use { fos ->
                fos.write((line + "\n").toByteArray(Charsets.UTF_8))
                fos.flush()
                runCatching { fos.fd.sync() }
            }
        }
    }

    private fun timeFormat(): SimpleDateFormat = SimpleDateFormat("HH:mm:ss", Locale.US)
    private fun fullDateFormat(): SimpleDateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
}
