package com.example.data

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.lang.reflect.Modifier
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.zip.ZipFile

data class NativeMethodProbeInfo(
    val className: String,
    val methodName: String,
    val signature: String,
    val source: String
)

data class PackageProbeReport(
    val packageName: String,
    val isInstalled: Boolean,
    val versionName: String = "",
    val sourceDir: String = "",
    val splitSourceDirs: List<String> = emptyList(),
    val nativeLibraryDir: String = "",
    val dexFilesScanned: List<String> = emptyList(),
    val mojangClasses: List<String> = emptyList(),
    val mainActivityInheritanceChain: List<String> = emptyList(),
    val mainActivityNativeMethods: List<NativeMethodProbeInfo> = emptyList(),
    val runtimeContextStatus: String = "",
    val runtimeReflectionMethods: List<NativeMethodProbeInfo> = emptyList(),
    val inspectedSoPath: String = "",
    val inspectedSoSizeBytes: Long = 0L,
    val neededLibraries: List<String> = emptyList(),
    val jniSymbols: List<String> = emptyList(),
    val totalJniSymbolCount: Int = 0,
    val errors: List<String> = emptyList(),
    val probedAtMs: Long = System.currentTimeMillis()
) {
    fun toCopyableText(): String = buildString {
        appendLine("=== LeviLab Package & ELF Probe Report ===")
        appendLine("Package: $packageName | Installed: $isInstalled | Version: $versionName")
        appendLine("sourceDir: $sourceDir")
        appendLine("splitSourceDirs (${splitSourceDirs.size}): ${splitSourceDirs.joinToString()}")
        appendLine("nativeLibraryDir: $nativeLibraryDir")
        appendLine("DEX files scanned: ${dexFilesScanned.joinToString()}")
        appendLine()
        appendLine("--- Runtime createPackageContext(CONTEXT_INCLUDE_CODE) ---")
        appendLine(runtimeContextStatus)
        if (runtimeReflectionMethods.isNotEmpty()) {
            runtimeReflectionMethods.forEach { m ->
                appendLine("  [REFLECT] ${m.className}.${m.methodName}${m.signature}")
            }
        }
        appendLine()
        appendLine("--- MainActivity Inheritance Chain (${mainActivityInheritanceChain.size}) ---")
        if (mainActivityInheritanceChain.isEmpty()) {
            appendLine("  (none resolved)")
        } else {
            mainActivityInheritanceChain.forEachIndexed { idx, cls ->
                appendLine("  ${idx + 1}. $cls")
            }
        }
        appendLine()
        appendLine("--- MainActivity Native Methods (${mainActivityNativeMethods.size}) ---")
        if (mainActivityNativeMethods.isEmpty()) {
            appendLine("  (none found)")
        } else {
            mainActivityNativeMethods.forEach { m ->
                appendLine("  [${m.source}] ${m.className}.${m.methodName}${m.signature}")
            }
        }
        appendLine()
        appendLine("--- Classes under com.mojang (${mojangClasses.size}) ---")
        mojangClasses.forEach { cls ->
            appendLine("  $cls")
        }
        appendLine()
        appendLine("--- libminecraftpe.so ELF Probe ---")
        appendLine("Path: ${inspectedSoPath.ifBlank { "(not found)" }} ($inspectedSoSizeBytes bytes)")
        appendLine("DT_NEEDED (${neededLibraries.size}):")
        neededLibraries.forEach { dep -> appendLine("  - $dep") }
        appendLine("JNI Symbols from dynstr/dynsym (showing ${jniSymbols.size} of $totalJniSymbolCount):")
        jniSymbols.forEach { sym -> appendLine("  - $sym") }
        if (errors.isNotEmpty()) {
            appendLine()
            appendLine("--- Errors / Notes ---")
            errors.forEach { err -> appendLine("  ! $err") }
        }
    }
}

class PackageProbeManager(private val context: Context) {

    @Suppress("DEPRECATION")
    suspend fun probePackage(
        packageName: String,
        cachedLibPath: String? = null
    ): PackageProbeReport = withContext(Dispatchers.IO) {
        val pm = context.packageManager
        val errors = mutableListOf<String>()

        val pkgInfo = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getPackageInfo(packageName, PackageManager.PackageInfoFlags.of(0))
            } else {
                pm.getPackageInfo(packageName, 0)
            }
        } catch (e: PackageManager.NameNotFoundException) {
            return@withContext PackageProbeReport(
                packageName = packageName,
                isInstalled = false,
                errors = listOf("Package '$packageName' is not installed on this device (${e.message}).")
            )
        } catch (e: Exception) {
            return@withContext PackageProbeReport(
                packageName = packageName,
                isInstalled = false,
                errors = listOf("Failed querying PackageManager for '$packageName': ${e.javaClass.simpleName}: ${e.message}")
            )
        }

        val appInfo = pkgInfo.applicationInfo
            ?: return@withContext PackageProbeReport(
                packageName = packageName,
                isInstalled = false,
                errors = listOf("ApplicationInfo is null for '$packageName'.")
            )

        val sourceDir = appInfo.sourceDir.orEmpty()
        val splitDirs = appInfo.splitSourceDirs?.toList().orEmpty()
        val nativeLibDir = appInfo.nativeLibraryDir.orEmpty()
        val launcherClassName = pm.getLaunchIntentForPackage(packageName)?.component?.className

        // 1. Scan classes*.dex in sourceDir + splitSourceDirs for com.mojang.* classes, superclass links, and MainActivity native methods
        val dexFilesScanned = mutableListOf<String>()
        val mojangClassesSet = sortedSetOf<String>()
        val dexNativeMethods = mutableListOf<NativeMethodProbeInfo>()
        val dexSuperclassMap = mutableMapOf<String, String>()

        val apkPaths = (listOf(sourceDir) + splitDirs).filter { it.isNotBlank() }.distinct()
        for (apkPath in apkPaths) {
            val apkFile = File(apkPath)
            if (!apkFile.exists() || !apkFile.canRead()) {
                errors.add("Cannot read APK path: $apkPath")
                continue
            }
            runCatching {
                ZipFile(apkFile).use { zip ->
                    val entries = zip.entries()
                    while (entries.hasMoreElements()) {
                        val entry = entries.nextElement()
                        if (!entry.isDirectory && entry.name.endsWith(".dex") && !entry.name.contains("/")) {
                            dexFilesScanned.add("${apkFile.name}!/${entry.name}")
                            val dexBytes = zip.getInputStream(entry).use { it.readBytes() }
                            val dexRes = DexInspector.inspectDex(dexBytes)
                            mojangClassesSet.addAll(dexRes.mojangClasses)
                            dexNativeMethods.addAll(dexRes.mainActivityNativeMethods)
                            dexSuperclassMap.putAll(dexRes.superclassMap)
                        }
                    }
                }
            }.onFailure { err ->
                errors.add("DEX scan failed for ${apkFile.name}: ${err.javaClass.simpleName}: ${err.message}")
            }
        }

        val discoveredActivityCandidates = buildList {
            launcherClassName?.takeIf { it.isNotBlank() }?.let { add(it) }
            add("com.mojang.minecraftpe.MainActivity")
            add("com.mojang.android.MainActivity")
            mojangClassesSet.filter { it.endsWith(".MainActivity") || it.contains("MainActivity") }.forEach { add(it) }
        }.distinct()

        // 2. Try createPackageContext with CONTEXT_INCLUDE_CODE (and fallback with CONTEXT_IGNORE_SECURITY)
        val runtimeMethods = mutableListOf<NativeMethodProbeInfo>()
        val runtimeInheritanceChain = mutableListOf<String>()
        val runtimeStatus = buildString {
            try {
                val strictCtx = context.createPackageContext(packageName, Context.CONTEXT_INCLUDE_CODE)
                append("CONTEXT_INCLUDE_CODE succeeded (ClassLoader=${strictCtx.classLoader?.javaClass?.simpleName}). ")
                collectRuntimeMainActivityInfo(
                    loader = strictCtx.classLoader,
                    candidates = discoveredActivityCandidates,
                    outMethods = runtimeMethods,
                    outChain = runtimeInheritanceChain,
                    errors = errors
                )
            } catch (sec: SecurityException) {
                append("CONTEXT_INCLUDE_CODE threw SecurityException: ${sec.message}. ")
                try {
                    val relaxedCtx = context.createPackageContext(
                        packageName,
                        Context.CONTEXT_INCLUDE_CODE or Context.CONTEXT_IGNORE_SECURITY
                    )
                    append("With CONTEXT_IGNORE_SECURITY: succeeded (ClassLoader=${relaxedCtx.classLoader?.javaClass?.simpleName}).")
                    collectRuntimeMainActivityInfo(
                        loader = relaxedCtx.classLoader,
                        candidates = discoveredActivityCandidates,
                        outMethods = runtimeMethods,
                        outChain = runtimeInheritanceChain,
                        errors = errors
                    )
                } catch (e2: Throwable) {
                    append("With CONTEXT_IGNORE_SECURITY failed: ${e2.javaClass.simpleName}: ${e2.message}")
                }
            } catch (t: Throwable) {
                append("createPackageContext failed: ${t.javaClass.simpleName}: ${t.message}")
            }
        }

        val resolvedChain = if (runtimeInheritanceChain.isNotEmpty()) {
            runtimeInheritanceChain
        } else {
            DexInspector.resolveInheritanceChain(
                startCandidates = discoveredActivityCandidates,
                superclassMap = dexSuperclassMap
            )
        }

        // Merge DEX + runtime native methods cleanly
        val combinedMethods = (dexNativeMethods + runtimeMethods)
            .distinctBy { "${it.className}.${it.methodName}${it.signature}:${it.source}" }
            .sortedWith(compareBy({ it.className }, { it.methodName }))

        // 3. Inspect libminecraftpe.so (nativeLibraryDir direct copy or cached extracted copy)
        val sysSoFile = nativeLibDir.takeIf { it.isNotBlank() }?.let { File(it, "libminecraftpe.so") }
            ?.takeIf { it.exists() && it.canRead() && it.length() > ElfBinaryInspector.MIN_VERIFIED_LIB_BYTES }
        val cachedSoFile = cachedLibPath?.takeIf { it.isNotBlank() }?.let { File(it) }
            ?.takeIf { it.exists() && it.canRead() && it.length() > ElfBinaryInspector.MIN_VERIFIED_LIB_BYTES }

        val targetSo = sysSoFile ?: cachedSoFile
        var neededLibs = emptyList<String>()
        var jniSyms = emptyList<String>()
        var jniTotal = 0
        var soPathOut = ""
        var soSizeOut = 0L

        if (targetSo != null) {
            soPathOut = targetSo.absolutePath
            soSizeOut = targetSo.length()
            val elf = ElfBinaryInspector.inspectElfFile(targetSo, includeJniSymbols = true, maxJniSymbols = 600)
            if (elf.isValidElf) {
                neededLibs = elf.neededLibraries
                jniSyms = elf.jniSymbols
                jniTotal = elf.totalJniSymbolCount
            } else {
                errors.add("File at $soPathOut is not a valid ELF binary (${elf.archLabel}).")
            }
        } else {
            errors.add("libminecraftpe.so not yet extracted to cache and not readable in nativeLibraryDir ($nativeLibDir). Extract libraries first to read DT_NEEDED and JNI symbols.")
        }

        PackageProbeReport(
            packageName = packageName,
            isInstalled = true,
            versionName = pkgInfo.versionName ?: "Unknown",
            sourceDir = sourceDir,
            splitSourceDirs = splitDirs,
            nativeLibraryDir = nativeLibDir,
            dexFilesScanned = dexFilesScanned,
            mojangClasses = mojangClassesSet.toList(),
            mainActivityInheritanceChain = resolvedChain,
            mainActivityNativeMethods = combinedMethods,
            runtimeContextStatus = runtimeStatus,
            runtimeReflectionMethods = runtimeMethods,
            inspectedSoPath = soPathOut,
            inspectedSoSizeBytes = soSizeOut,
            neededLibraries = neededLibs,
            jniSymbols = jniSyms,
            totalJniSymbolCount = jniTotal,
            errors = errors
        )
    }

    private fun collectRuntimeMainActivityInfo(
        loader: ClassLoader?,
        candidates: List<String>,
        outMethods: MutableList<NativeMethodProbeInfo>,
        outChain: MutableList<String>,
        errors: MutableList<String>
    ) {
        if (loader == null) return
        for (clsName in candidates) {
            try {
                // Class.forName with initialize = false avoids running static initializers (e.g., System.loadLibrary)
                val cls = Class.forName(clsName, false, loader)
                if (outChain.isEmpty()) {
                    var cur: Class<*>? = cls
                    while (cur != null) {
                        outChain.add(cur.name)
                        cur = cur.superclass
                    }
                }
                cls.declaredMethods
                    .filter { Modifier.isNative(it.modifiers) }
                    .forEach { m ->
                        val params = m.parameterTypes.joinToString(", ") { it.simpleName }
                        outMethods.add(
                            NativeMethodProbeInfo(
                                className = clsName,
                                methodName = m.name,
                                signature = "($params) -> ${m.returnType.simpleName}",
                                source = "Class.forName"
                            )
                        )
                    }
            } catch (_: ClassNotFoundException) {
                // Class may live in a split or different name
            } catch (t: Throwable) {
                errors.add("Class.forName($clsName, false) inspect failed: ${t.javaClass.simpleName}: ${t.message}")
            }
        }
    }
}

object DexInspector {

    private const val ACC_NATIVE = 0x0100

    data class DexInspectResult(
        val mojangClasses: List<String>,
        val mainActivityNativeMethods: List<NativeMethodProbeInfo>,
        val superclassMap: Map<String, String> = emptyMap()
    )

    fun resolveInheritanceChain(
        startCandidates: List<String>,
        superclassMap: Map<String, String>
    ): List<String> {
        val start = startCandidates.firstOrNull { it in superclassMap } ?: return emptyList()
        val chain = mutableListOf<String>()
        val visited = mutableSetOf<String>()
        var current: String? = start
        while (current != null && current.isNotBlank() && visited.add(current)) {
            chain.add(current)
            current = superclassMap[current]
        }
        return chain
    }

    fun inspectDex(bytes: ByteArray): DexInspectResult {
        if (bytes.size < 112) return DexInspectResult(emptyList(), emptyList())
        if (bytes[0] != 'd'.code.toByte() || bytes[1] != 'e'.code.toByte() ||
            bytes[2] != 'x'.code.toByte() || bytes[3] != '\n'.code.toByte()
        ) {
            return DexInspectResult(emptyList(), emptyList())
        }

        val buf = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        val stringIdsSize = buf.getInt(56)
        val stringIdsOff = buf.getInt(60)
        val typeIdsSize = buf.getInt(64)
        val typeIdsOff = buf.getInt(68)
        val protoIdsSize = buf.getInt(72)
        val protoIdsOff = buf.getInt(76)
        val methodIdsSize = buf.getInt(88)
        val methodIdsOff = buf.getInt(92)
        val classDefsSize = buf.getInt(96)
        val classDefsOff = buf.getInt(100)

        if (stringIdsSize <= 0 || typeIdsSize <= 0 || classDefsSize <= 0) {
            return DexInspectResult(emptyList(), emptyList())
        }

        val stringsCache = arrayOfNulls<String>(stringIdsSize)
        fun getString(idx: Int): String {
            if (idx !in 0 until stringIdsSize) return ""
            stringsCache[idx]?.let { return it }
            val dataOff = buf.getInt(stringIdsOff + idx * 4)
            if (dataOff !in 0 until bytes.size) return ""
            var pos = dataOff
            // Skip uleb128 utf16_size
            while (pos < bytes.size) {
                val b = bytes[pos].toInt() and 0xFF
                pos++
                if ((b and 0x80) == 0) break
            }
            val start = pos
            while (pos < bytes.size && bytes[pos] != 0.toByte()) pos++
            val decoded = String(bytes, start, pos - start, Charsets.UTF_8)
            stringsCache[idx] = decoded
            return decoded
        }

        fun getTypeDescriptor(typeIdx: Int): String {
            if (typeIdx !in 0 until typeIdsSize) return ""
            val strIdx = buf.getInt(typeIdsOff + typeIdx * 4)
            return getString(strIdx)
        }

        fun descriptorToJava(desc: String): String {
            return when {
                desc.startsWith("L") && desc.endsWith(";") -> desc.substring(1, desc.length - 1).replace('/', '.')
                desc == "V" -> "void"
                desc == "Z" -> "boolean"
                desc == "B" -> "byte"
                desc == "S" -> "short"
                desc == "C" -> "char"
                desc == "I" -> "int"
                desc == "J" -> "long"
                desc == "F" -> "float"
                desc == "D" -> "double"
                desc.startsWith("[") -> "${descriptorToJava(desc.substring(1))}[]"
                else -> desc
            }
        }

        fun getProtoSignature(protoIdx: Int): String {
            if (protoIdx !in 0 until protoIdsSize || protoIdsOff <= 0) return "()"
            val base = protoIdsOff + protoIdx * 12
            if (base + 12 > bytes.size) return "()"
            val returnTypeIdx = buf.getInt(base + 4)
            val parametersOff = buf.getInt(base + 8)
            val retType = descriptorToJava(getTypeDescriptor(returnTypeIdx)).substringAfterLast('.')
            val params = if (parametersOff > 0 && parametersOff + 4 <= bytes.size) {
                val count = buf.getInt(parametersOff)
                buildList {
                    for (p in 0 until count.coerceIn(0, 32)) {
                        val pOff = parametersOff + 4 + p * 2
                        if (pOff + 2 <= bytes.size) {
                            val tIdx = buf.getShort(pOff).toInt() and 0xFFFF
                            add(descriptorToJava(getTypeDescriptor(tIdx)).substringAfterLast('.'))
                        }
                    }
                }
            } else emptyList()
            return "(${params.joinToString(", ")}) -> $retType"
        }

        val mojangClasses = mutableListOf<String>()
        val mainActivityNativeMethods = mutableListOf<NativeMethodProbeInfo>()
        val superclassMap = mutableMapOf<String, String>()

        for (i in 0 until classDefsSize) {
            val base = classDefsOff + i * 32
            if (base + 32 > bytes.size) break
            val classIdx = buf.getInt(base)
            val superclassIdx = buf.getInt(base + 8)
            val classDataOff = buf.getInt(base + 24)
            val desc = getTypeDescriptor(classIdx)
            val javaName = descriptorToJava(desc)
            if (superclassIdx != -1) {
                val superDesc = getTypeDescriptor(superclassIdx)
                if (superDesc.isNotBlank()) {
                    superclassMap[javaName] = descriptorToJava(superDesc)
                }
            }
            if (desc.startsWith("Lcom/mojang/")) {
                mojangClasses.add(javaName)
                if (classDataOff > 0 && classDataOff < bytes.size &&
                    (javaName.endsWith(".MainActivity") || javaName.contains("MainActivity"))
                ) {
                    parseClassNativeMethods(
                        bytes = bytes,
                        startOffset = classDataOff,
                        className = javaName,
                        methodIdsSize = methodIdsSize,
                        methodIdsOff = methodIdsOff,
                        buf = buf,
                        getString = ::getString,
                        getProtoSignature = ::getProtoSignature,
                        out = mainActivityNativeMethods
                    )
                }
            }
        }

        return DexInspectResult(mojangClasses, mainActivityNativeMethods, superclassMap)
    }

    private fun parseClassNativeMethods(
        bytes: ByteArray,
        startOffset: Int,
        className: String,
        methodIdsSize: Int,
        methodIdsOff: Int,
        buf: ByteBuffer,
        getString: (Int) -> String,
        getProtoSignature: (Int) -> String,
        out: MutableList<NativeMethodProbeInfo>
    ) {
        var pos = startOffset
        fun readUleb128(): Int {
            var result = 0
            var shift = 0
            while (pos < bytes.size) {
                val b = bytes[pos].toInt() and 0xFF
                pos++
                result = result or ((b and 0x7F) shl shift)
                if ((b and 0x80) == 0) break
                shift += 7
            }
            return result
        }

        val staticFieldsSize = readUleb128()
        val instanceFieldsSize = readUleb128()
        val directMethodsSize = readUleb128()
        val virtualMethodsSize = readUleb128()

        // Skip fields
        repeat(staticFieldsSize + instanceFieldsSize) {
            readUleb128()
            readUleb128()
        }

        fun readEncodedMethods(count: Int) {
            var methodIdx = 0
            repeat(count) {
                val diff = readUleb128()
                val accessFlags = readUleb128()
                readUleb128() // code_off
                methodIdx += diff
                if ((accessFlags and ACC_NATIVE) != 0 && methodIdx in 0 until methodIdsSize && methodIdsOff > 0) {
                    val mBase = methodIdsOff + methodIdx * 8
                    if (mBase + 8 <= bytes.size) {
                        val protoIdx = buf.getShort(mBase + 2).toInt() and 0xFFFF
                        val nameIdx = buf.getInt(mBase + 4)
                        val methodName = getString(nameIdx)
                        val sig = getProtoSignature(protoIdx)
                        out.add(
                            NativeMethodProbeInfo(
                                className = className,
                                methodName = methodName,
                                signature = sig,
                                source = "DEX"
                            )
                        )
                    }
                }
            }
        }

        readEncodedMethods(directMethodsSize)
        readEncodedMethods(virtualMethodsSize)
    }
}
