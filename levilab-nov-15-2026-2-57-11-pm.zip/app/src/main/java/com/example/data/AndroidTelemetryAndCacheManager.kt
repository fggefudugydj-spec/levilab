package com.example.data

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import androidx.core.content.FileProvider
import com.example.model.ApkInspectionResult
import com.example.model.CacheHealthStatus
import com.example.model.DeviceTelemetry
import com.example.model.GameProfile
import com.example.model.InstalledMinecraftInfo
import com.example.model.InstalledPackageSplitsReport
import com.example.model.InstalledSplitFragment
import com.example.model.IsolatedSandboxConfig
import com.example.model.LaunchSessionState
import com.example.model.ModItem
import com.example.model.ModType
import com.example.model.NativeLibEntry
import com.example.model.ProfileSourceType
import com.example.model.SplitCategory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.security.MessageDigest
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipInputStream

data class RealExtractionResult(
    val success: Boolean,
    val mainLib: NativeLibEntry?,
    val extractedFiles: List<String>,
    val extractedAbis: List<String>,
    val failureMessage: String? = null
)

class AndroidTelemetryAndCacheManager(private val context: Context) {

    val cacheRootDir: File
        get() = File(context.filesDir, "minecraft_library_cache").apply {
            if (!exists()) mkdirs()
        }

    private val isolatedInstancesRootDir: File
        get() = File(context.filesDir, "isolated_instances").apply {
            if (!exists()) mkdirs()
        }

    private val importedPacksDir: File
        get() = File(context.filesDir, "imported_packs").apply {
            if (!exists()) mkdirs()
        }

    // Remove any non-ELF or <= 1MB files named libminecraftpe.so left from previous runs.
    suspend fun cleanupInvalidCacheFiles() = withContext(Dispatchers.IO) {
        cacheRootDir.walkTopDown().forEach { file ->
            if (file.isFile && file.name == "libminecraftpe.so") {
                val report = ElfBinaryInspector.inspectElfFile(file)
                if (!report.isValidElf || !report.meetsMinSize1Mb) {
                    runCatching { file.delete() }
                    runCatching { File(file.parentFile, "libminecraftpe.levimeta").delete() }
                }
            }
            if (file.isFile && file.name.endsWith(".tmp")) {
                runCatching { file.delete() }
            }
        }
    }

    suspend fun collectDeviceTelemetry(extraPackages: List<String> = emptyList()): DeviceTelemetry =
        withContext(Dispatchers.IO) {
            val supportedAbis = Build.SUPPORTED_ABIS?.toList().orEmpty().ifEmpty { listOf("arm64-v8a") }
            val primaryAbi = supportedAbis.firstOrNull() ?: "arm64-v8a"
            val installedEditions = queryAllInstalledMinecraftEditions(extraPackages)
            val primaryInstalled = installedEditions.firstOrNull {
                it.packageName == "com.mojang.minecraftpe.preview"
            } ?: installedEditions.firstOrNull {
                it.versionName.contains("1.26.70")
            } ?: installedEditions.firstOrNull {
                it.packageName == "com.mojang.minecraftpe"
            } ?: installedEditions.firstOrNull()
            DeviceTelemetry(
                deviceModel = "${Build.MANUFACTURER.replaceFirstChar { it.uppercase() }} ${Build.MODEL}",
                androidVersion = Build.VERSION.RELEASE ?: "13",
                sdkInt = Build.VERSION.SDK_INT,
                supportedAbis = supportedAbis,
                primaryAbi = primaryAbi,
                installedMinecraftPackage = primaryInstalled,
                installedEditions = installedEditions
            )
        }

    // Strict getLaunchIntentForPackage for Stage B
    fun getStrictLaunchIntentForPackage(packageName: String): Intent? {
        return context.packageManager.getLaunchIntentForPackage(packageName)
    }

    @Suppress("DEPRECATION")
    fun createLaunchIntent(packageName: String, insideCurrentTask: Boolean = false): Intent? {
        val pm = context.packageManager
        fun applyTaskFlag(intent: Intent): Intent {
            if (!insideCurrentTask) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            return intent
        }

        pm.getLaunchIntentForPackage(packageName)?.let { intent ->
            if (insideCurrentTask) {
                intent.flags = intent.flags and Intent.FLAG_ACTIVITY_NEW_TASK.inv()
            } else {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            return intent
        }

        val launcherIntent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
            setPackage(packageName)
        }
        val launcherMatches = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.queryIntentActivities(launcherIntent, PackageManager.ResolveInfoFlags.of(0))
        } else {
            pm.queryIntentActivities(launcherIntent, 0)
        }
        launcherMatches.firstOrNull()?.activityInfo?.let { info ->
            return applyTaskFlag(
                Intent(Intent.ACTION_MAIN).apply {
                    addCategory(Intent.CATEGORY_LAUNCHER)
                    component = ComponentName(info.packageName, info.name)
                }
            )
        }
        return null
    }

    fun createServerConnectIntent(
        packageName: String?,
        host: String,
        port: Int,
        insideCurrentTask: Boolean = false
    ): Intent {
        val cleanHost = host.trim()
        val safePort = port.coerceIn(1, 65535)
        val uri = Uri.parse("minecraft://connect/?serverUrl=${Uri.encode(cleanHost)}&serverPort=$safePort")
        return Intent(Intent.ACTION_VIEW, uri).apply {
            if (!packageName.isNullOrBlank()) {
                setPackage(packageName)
            }
            if (!insideCurrentTask) {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
        }
    }

    fun createAddExternalServerIntent(
        packageName: String?,
        serverName: String,
        host: String,
        port: Int
    ): Intent {
        val cleanName = serverName.trim().ifEmpty { host.trim() }
        val cleanHost = host.trim()
        val safePort = port.coerceIn(1, 65535)
        val uri = Uri.parse("minecraft://?addExternalServer=${Uri.encode(cleanName)}|${Uri.encode(cleanHost)}:$safePort")
        return Intent(Intent.ACTION_VIEW, uri).apply {
            if (!packageName.isNullOrBlank()) {
                setPackage(packageName)
            }
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }

    fun createOpenPackIntent(stagedFilePath: String, targetPackageName: String?): Intent? {
        val file = File(stagedFilePath)
        if (!file.exists()) return null
        val contentUri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val mime = when {
            file.name.endsWith(".mcpack", true) ||
                file.name.endsWith(".mcaddon", true) ||
                file.name.endsWith(".mcworld", true) ||
                file.name.endsWith(".mctemplate", true) -> "application/zip"
            else -> "*/*"
        }
        return Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(contentUri, mime)
            if (!targetPackageName.isNullOrBlank()) {
                setPackage(targetPackageName)
            }
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }

    fun createStoreIntent(packageName: String): Intent {
        return Intent(
            Intent.ACTION_VIEW,
            Uri.parse("https://play.google.com/store/apps/details?id=$packageName")
        ).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }

    suspend fun ensureIsolatedSandbox(
        profileId: String,
        isolatedEnabled: Boolean = true
    ): IsolatedSandboxConfig = withContext(Dispatchers.IO) {
        val instanceDir = File(isolatedInstancesRootDir, profileId)
        val mojangDir = File(instanceDir, "games/com.mojang")
        val worldsDir = File(mojangDir, "minecraftWorlds").apply { if (!exists()) mkdirs() }
        val resPacksDir = File(mojangDir, "resource_packs").apply { if (!exists()) mkdirs() }
        val behPacksDir = File(mojangDir, "behavior_packs").apply { if (!exists()) mkdirs() }
        val peDir = File(mojangDir, "minecraftpe").apply { if (!exists()) mkdirs() }
        val optionsFile = File(peDir, "options.txt")

        if (!optionsFile.exists()) {
            writeOptionsFile(
                optionsFile = optionsFile,
                playerName = "BetaPlayer",
                gfxVsync = true,
                devEnableProfiler = false,
                devShowChunkMap = false,
                maxFramerate = 60,
                gfxViewDistance = 12,
                isolatedEnabled = isolatedEnabled
            )
        }

        val parsed = parseOptionsFile(optionsFile)
        IsolatedSandboxConfig(
            profileId = profileId,
            sandboxRootPath = mojangDir.absolutePath,
            optionsTxtPath = optionsFile.absolutePath,
            playerName = parsed["mp_username"]?.takeIf { it.isNotBlank() } ?: "BetaPlayer",
            isolatedEnabled = parsed["levilab_isolated_storage"] != "0",
            gfxVsync = parsed["gfx_vsync"] != "0",
            devEnableProfiler = parsed["dev_enable_profiler"] == "1",
            devShowChunkMap = parsed["dev_show_chunk_map"] == "1",
            maxFramerate = parsed["gfx_max_framerate"]?.toIntOrNull() ?: 60,
            gfxViewDistance = parsed["gfx_viewdistance"]?.toIntOrNull() ?: 12,
            resourcePackCount = resPacksDir.listFiles()?.count() ?: 0,
            behaviorPackCount = behPacksDir.listFiles()?.count() ?: 0,
            worldsCount = worldsDir.listFiles()?.count { it.isDirectory } ?: 0
        )
    }

    suspend fun updateSandboxOptions(
        profileId: String,
        playerName: String,
        isolatedEnabled: Boolean,
        gfxVsync: Boolean,
        devEnableProfiler: Boolean,
        devShowChunkMap: Boolean,
        maxFramerate: Int,
        gfxViewDistance: Int = 12
    ): IsolatedSandboxConfig = withContext(Dispatchers.IO) {
        val config = ensureIsolatedSandbox(profileId, isolatedEnabled)
        val optionsFile = File(config.optionsTxtPath)
        writeOptionsFile(
            optionsFile = optionsFile,
            playerName = playerName.trim().ifEmpty { "BetaPlayer" },
            gfxVsync = gfxVsync,
            devEnableProfiler = devEnableProfiler,
            devShowChunkMap = devShowChunkMap,
            maxFramerate = maxFramerate,
            gfxViewDistance = gfxViewDistance,
            isolatedEnabled = isolatedEnabled
        )
        ensureIsolatedSandbox(profileId, isolatedEnabled)
    }

    private fun writeOptionsFile(
        optionsFile: File,
        playerName: String,
        gfxVsync: Boolean,
        devEnableProfiler: Boolean,
        devShowChunkMap: Boolean,
        maxFramerate: Int,
        gfxViewDistance: Int,
        isolatedEnabled: Boolean
    ) {
        val content = buildString {
            append("mp_username:$playerName\n")
            append("gfx_vsync:${if (gfxVsync) 1 else 0}\n")
            append("gfx_max_framerate:$maxFramerate\n")
            append("gfx_viewdistance:$gfxViewDistance\n")
            append("dev_enable_profiler:${if (devEnableProfiler) 1 else 0}\n")
            append("dev_show_chunk_map:${if (devShowChunkMap) 1 else 0}\n")
            append("mp_server_visible_default:1\n")
            append("levilab_isolated_storage:${if (isolatedEnabled) 1 else 0}\n")
        }
        optionsFile.writeText(content)
    }

    private fun parseOptionsFile(optionsFile: File): Map<String, String> {
        if (!optionsFile.exists()) return emptyMap()
        val map = mutableMapOf<String, String>()
        optionsFile.readLines().forEach { line ->
            val idx = line.indexOf(':')
            if (idx > 0) {
                map[line.substring(0, idx).trim()] = line.substring(idx + 1).trim()
            }
        }
        return map
    }

    suspend fun inspectAndStageModUri(
        uri: Uri,
        profileId: String,
        fallbackAbi: String
    ): ModItem? = withContext(Dispatchers.IO) {
        val fileName = resolveFileName(uri)
        val lowerName = fileName.lowercase()
        val sandbox = ensureIsolatedSandbox(profileId)
        val mojangDir = File(sandbox.sandboxRootPath)

        if (lowerName.endsWith(".so")) {
            val safeFileName = fileName.replace(Regex("[^A-Za-z0-9._-]"), "_")
            val stagedSo = File(importedPacksDir, "${System.currentTimeMillis()}_$safeFileName")
            val tmpSo = File(importedPacksDir, "${stagedSo.name}.tmp")
            runCatching {
                context.contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(tmpSo).use { output ->
                        input.copyTo(output, bufferSize = 32 * 1024)
                        output.flush()
                    }
                }
                if (tmpSo.exists() && tmpSo.length() > 0L) {
                    if (stagedSo.exists()) stagedSo.delete()
                    tmpSo.renameTo(stagedSo)
                }
            }.onFailure { tmpSo.delete() }

            val elfReport = if (stagedSo.exists() && stagedSo.length() >= 64L) {
                ElfBinaryInspector.inspectElfFile(stagedSo)
            } else {
                ElfBinaryInspector.inspectHeaderOnly(ByteArray(0))
            }
            if (!elfReport.isValidElf) {
                stagedSo.delete()
                return@withContext null
            }
            val elfArch = elfReport.archLabel
            val detectedAbi = when {
                elfArch.contains("arm64-v8a") -> "arm64-v8a"
                elfArch.contains("armeabi-v7a") -> "armeabi-v7a"
                elfArch.contains("x86-64") -> "x86_64"
                elfArch.contains("x86") -> "x86"
                else -> fallbackAbi
            }
            return@withContext ModItem(
                id = "imported_so_${System.currentTimeMillis()}",
                name = fileName.removeSuffix(".so"),
                author = "Imported Native .so",
                version = "${stagedSo.length() / 1024} KB",
                type = ModType.NATIVE_SO,
                requiredAbi = detectedAbi,
                enabled = true,
                loadOrder = 50,
                descriptionEn = "ELF binary verified ($elfArch)",
                descriptionAr = "مكتبة أصلية حقيقية مفحوصة ($elfArch)",
                stagedFilePath = stagedSo.absolutePath,
                isCustomAdded = true,
                is16KbAligned = if (elfReport.maxLoadAlignBytes > 0L) elfReport.is16KbAligned else null,
                neededLibraries = elfReport.neededLibraries
            )
        }

        // Handle .mcpack / .mcaddon / .mcworld / .zip
        var packName = fileName.substringBeforeLast('.')
        var packDesc = "Imported Bedrock addon pack"
        var packVersion = "1.0.0"
        var minEngineVersion: String? = null
        var modType = when {
            lowerName.endsWith(".mcworld") || lowerName.endsWith(".mctemplate") -> ModType.WORLD_TEMPLATE
            lowerName.endsWith(".mcaddon") -> ModType.BEHAVIOR_PACK
            else -> ModType.RESOURCE_PACK
        }

        val safeFileName = fileName.replace(Regex("[^A-Za-z0-9._-]"), "_")
        val stagedFile = File(importedPacksDir, "${System.currentTimeMillis()}_$safeFileName")
        val tmpPack = File(importedPacksDir, "${stagedFile.name}.tmp")
        try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(tmpPack).use { output ->
                    input.copyTo(output, bufferSize = 32 * 1024)
                    output.flush()
                }
            }
            if (tmpPack.exists() && tmpPack.length() > 0L) {
                if (stagedFile.exists()) stagedFile.delete()
                tmpPack.renameTo(stagedFile)
            }
        } catch (_: Exception) {
            tmpPack.delete()
        }

        if (!stagedFile.exists() || stagedFile.length() == 0L) return@withContext null

        try {
            stagedFile.inputStream().use { raw ->
                ZipInputStream(BufferedInputStream(raw)).use { zis ->
                    var entry = zis.nextEntry
                    while (entry != null) {
                        if (!entry.isDirectory && entry.name.endsWith("manifest.json", ignoreCase = true)) {
                            val jsonBytes = zis.readBytes()
                            val json = JSONObject(jsonBytes.decodeToString())
                            val headerObj = json.optJSONObject("header")
                            if (headerObj != null) {
                                headerObj.optString("name").takeIf { it.isNotBlank() }?.let { packName = it }
                                headerObj.optString("description").takeIf { it.isNotBlank() }?.let { packDesc = it }
                                val verArr = headerObj.optJSONArray("version")
                                if (verArr != null && verArr.length() >= 3) {
                                    packVersion = "${verArr.optInt(0)}.${verArr.optInt(1)}.${verArr.optInt(2)}"
                                }
                                val minEngArr = headerObj.optJSONArray("min_engine_version")
                                if (minEngArr != null && minEngArr.length() >= 3) {
                                    minEngineVersion = "${minEngArr.optInt(0)}.${minEngArr.optInt(1)}.${minEngArr.optInt(2)}"
                                }
                            }
                            val modulesArr = json.optJSONArray("modules")
                            if (modulesArr != null && modulesArr.length() > 0) {
                                val firstType = modulesArr.getJSONObject(0).optString("type").lowercase()
                                if (firstType == "data" || firstType == "script") {
                                    modType = ModType.BEHAVIOR_PACK
                                } else if (firstType == "resources") {
                                    modType = ModType.RESOURCE_PACK
                                } else if (firstType == "world_template") {
                                    modType = ModType.WORLD_TEMPLATE
                                }
                            }
                            break
                        }
                        zis.closeEntry()
                        entry = zis.nextEntry
                    }
                }
            }
        } catch (_: Exception) {
            // Keep filename fallback
        }

        val targetSubDir = when (modType) {
            ModType.BEHAVIOR_PACK -> "behavior_packs"
            ModType.WORLD_TEMPLATE -> "minecraftWorlds"
            else -> "resource_packs"
        }
        val packDir = File(File(mojangDir, targetSubDir), packName.replace(Regex("[^A-Za-z0-9._-]"), "_"))
        if (!packDir.exists()) packDir.mkdirs()

        ModItem(
            id = "imported_pack_${System.currentTimeMillis()}",
            name = packName,
            author = "Bedrock Pack",
            version = packVersion,
            type = modType,
            requiredAbi = "universal",
            enabled = true,
            loadOrder = 50,
            descriptionEn = "$packDesc ($fileName)",
            descriptionAr = "حزمة مستوردة جاهزة للإرسال إلى ماينكرافت ($fileName)",
            stagedFilePath = stagedFile.absolutePath,
            minEngineVersion = minEngineVersion,
            isCustomAdded = true
        )
    }

    fun deleteStagedFile(path: String?) {
        if (path.isNullOrBlank()) return
        runCatching {
            val file = File(path)
            if (file.exists() && file.absolutePath.startsWith(importedPacksDir.absolutePath)) {
                file.delete()
            }
        }
    }

    @Suppress("DEPRECATION")
    suspend fun inspectInstalledMinecraftSplits(
        preferredPackageName: String? = null
    ): InstalledPackageSplitsReport =
        withContext(Dispatchers.IO) {
            val baseCandidates = listOf(
                "com.mojang.minecraftpe.preview",
                "com.mojang.minecraftpe",
                "com.mojang.minecrafttrialpe",
                "com.mojang.minecraftpe.beta"
            )
            val candidates = if (!preferredPackageName.isNullOrBlank()) {
                (listOf(preferredPackageName) + baseCandidates).distinct()
            } else {
                baseCandidates
            }
            val pm = context.packageManager
            for (pkg in candidates) {
                try {
                    val pkgInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        pm.getPackageInfo(pkg, PackageManager.PackageInfoFlags.of(0))
                    } else {
                        pm.getPackageInfo(pkg, 0)
                    }
                    val appInfo = pkgInfo.applicationInfo ?: continue
                    val basePath = appInfo.sourceDir.orEmpty()
                    val baseSize = if (basePath.isNotEmpty()) {
                        File(basePath).takeIf { it.exists() }?.length() ?: 0L
                    } else 0L

                    val splitNames = appInfo.splitNames?.toList().orEmpty()
                    val splitDirs = appInfo.splitSourceDirs?.toList().orEmpty()

                    val fragments = splitNames.mapIndexed { index, rawName ->
                        val path = splitDirs.getOrNull(index).orEmpty()
                        val file = if (path.isNotEmpty()) File(path) else null
                        val exists = file?.exists() == true
                        val size = if (exists) file?.length() ?: 0L else 0L
                        InstalledSplitFragment(
                            splitName = rawName,
                            category = classifySplitApkName(rawName),
                            sourcePath = path,
                            sizeBytes = size,
                            existsOnDisk = exists
                        )
                    }

                    val extraFragments = if (splitDirs.size > splitNames.size) {
                        splitDirs.drop(splitNames.size).map { path ->
                            val file = File(path)
                            val inferredName = file.nameWithoutExtension
                            val exists = file.exists()
                            InstalledSplitFragment(
                                splitName = inferredName,
                                category = classifySplitApkName(inferredName),
                                sourcePath = path,
                                sizeBytes = if (exists) file.length() else 0L,
                                existsOnDisk = exists
                            )
                        }
                    } else emptyList()

                    val allSplits = fragments + extraFragments
                    val resAndLang = allSplits.filter {
                        it.category == SplitCategory.RESOURCE_DENSITY || it.category == SplitCategory.LANGUAGE
                    }
                    val resAndLangTotal = resAndLang.sumOf { it.sizeBytes }
                    val totalDisk = baseSize + allSplits.sumOf { it.sizeBytes }

                    return@withContext InstalledPackageSplitsReport(
                        packageName = pkg,
                        versionName = pkgInfo.versionName ?: "Unknown",
                        isInstalled = true,
                        baseApkPath = basePath,
                        baseApkSizeBytes = baseSize,
                        splitFragments = allSplits,
                        resourceAndLanguageSplits = resAndLang,
                        resourceAndLanguageTotalBytes = resAndLangTotal,
                        totalPackageDiskBytes = totalDisk
                    )
                } catch (_: PackageManager.NameNotFoundException) {
                    // Check next candidate
                } catch (_: Exception) {
                    // Continue safely
                }
            }

            InstalledPackageSplitsReport(
                packageName = "com.mojang.minecraftpe.preview",
                versionName = "",
                isInstalled = false,
                baseApkPath = "",
                baseApkSizeBytes = 0L,
                splitFragments = emptyList(),
                resourceAndLanguageSplits = emptyList(),
                resourceAndLanguageTotalBytes = 0L,
                totalPackageDiskBytes = 0L
            )
        }

    fun classifySplitApkName(splitName: String): SplitCategory {
        val normalized = splitName
            .lowercase()
            .removeSuffix(".apk")
            .removePrefix("split_")

        if (normalized == "base") return SplitCategory.BASE_APK

        val configSuffix = when {
            normalized.startsWith("config.") -> normalized.removePrefix("config.")
            normalized.contains(".config.") -> normalized.substringAfterLast(".config.")
            else -> return SplitCategory.FEATURE_MODULE
        }

        return when {
            configSuffix in setOf(
                "arm64_v8a", "armeabi_v7a", "armeabi", "x86", "x86_64", "mips", "mips64"
            ) -> SplitCategory.NATIVE_ABI

            configSuffix in setOf(
                "ldpi", "mdpi", "tvdpi", "hdpi", "xhdpi", "xxhdpi", "xxxhdpi", "anydpi", "nodpi"
            ) -> SplitCategory.RESOURCE_DENSITY

            isLanguageSplitToken(configSuffix) -> SplitCategory.LANGUAGE

            else -> SplitCategory.OTHER
        }
    }

    private fun isLanguageSplitToken(token: String): Boolean {
        if (token.matches(Regex("^[a-z]{2,3}$"))) return true
        if (token.matches(Regex("^[a-z]{2,3}[_-]r?[a-z]{2,4}$"))) return true
        if (token.startsWith("b+")) return true
        return false
    }

    @Suppress("DEPRECATION")
    private fun queryAllInstalledMinecraftEditions(extraPackages: List<String> = emptyList()): List<InstalledMinecraftInfo> {
        val pm = context.packageManager

        val discoveredPackages = mutableSetOf<String>()
        val launcherQuery = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val launcherResolveInfos = runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.queryIntentActivities(launcherQuery, PackageManager.ResolveInfoFlags.of(0))
            } else {
                pm.queryIntentActivities(launcherQuery, 0)
            }
        }.getOrDefault(emptyList())

        for (ri in launcherResolveInfos) {
            val pkg = ri.activityInfo?.packageName ?: continue
            val lowerPkg = pkg.lowercase()
            val label = runCatching { ri.loadLabel(pm).toString() }.getOrDefault("").lowercase()
            if (lowerPkg.contains("minecraft") ||
                lowerPkg.contains("mojang") ||
                lowerPkg.contains("bedrock") ||
                label.contains("minecraft")
            ) {
                discoveredPackages.add(pkg)
            }
        }

        val uriQuery = Intent(Intent.ACTION_VIEW, Uri.parse("minecraft://"))
        val uriResolveInfos = runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.queryIntentActivities(uriQuery, PackageManager.ResolveInfoFlags.of(0))
            } else {
                pm.queryIntentActivities(uriQuery, 0)
            }
        }.getOrDefault(emptyList())
        for (ri in uriResolveInfos) {
            ri.activityInfo?.packageName?.let { discoveredPackages.add(it) }
        }

        val candidates = (listOf(
            "com.mojang.minecraftpe.preview",
            "com.mojang.minecraftpe",
            "com.mojang.minecrafttrialpe",
            "com.mojang.minecraftpe.beta"
        ) + discoveredPackages + extraPackages).filter { it.isNotBlank() }.distinct()

        val found = mutableListOf<InstalledMinecraftInfo>()
        for (pkg in candidates) {
            try {
                val pkgInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    pm.getPackageInfo(pkg, PackageManager.PackageInfoFlags.of(0))
                } else {
                    pm.getPackageInfo(pkg, 0)
                }
                val appInfo = pkgInfo.applicationInfo ?: continue
                val appLabel = runCatching { pm.getApplicationLabel(appInfo).toString() }
                    .getOrDefault("Minecraft")
                val nativeDir = appInfo.nativeLibraryDir.orEmpty()
                val sysLibFile = if (nativeDir.isNotEmpty()) File(nativeDir, "libminecraftpe.so") else null
                val hasNativeLib = sysLibFile != null &&
                    sysLibFile.exists() &&
                    sysLibFile.length() > ElfBinaryInspector.MIN_VERIFIED_LIB_BYTES &&
                    ElfBinaryInspector.inspectElfFile(sysLibFile).isValidElf
                val extractNativeLibs = (appInfo.flags and ApplicationInfo.FLAG_EXTRACT_NATIVE_LIBS) != 0
                val allSoLibs = probeEmbeddedNativeLibs(appInfo)
                val mcLibs = allSoLibs.filter { it.libraryFileName == "libminecraftpe.so" }
                val companionLibs = allSoLibs.filter { it.libraryFileName != "libminecraftpe.so" }
                val splits = appInfo.splitNames?.toList().orEmpty()
                val splitDirs = appInfo.splitSourceDirs?.toList().orEmpty()
                val versionCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    pkgInfo.longVersionCode
                } else {
                    pkgInfo.versionCode.toLong()
                }
                val launchable = pm.getLaunchIntentForPackage(pkg) != null || createLaunchIntent(pkg) != null
                val sigSha = computePackageSigningCertSha256(pm, pkg)
                found.add(
                    InstalledMinecraftInfo(
                        packageName = pkg,
                        appLabel = appLabel,
                        versionName = pkgInfo.versionName ?: "Unknown",
                        versionCode = versionCode,
                        nativeLibraryDir = nativeDir,
                        hasNativeLibInSystemDir = hasNativeLib,
                        extractNativeLibsEnabled = extractNativeLibs,
                        embeddedNativeLibs = mcLibs,
                        companionNativeLibs = companionLibs,
                        splitNames = splits,
                        splitSourceDirs = splitDirs,
                        sourceDir = appInfo.sourceDir.orEmpty(),
                        isLaunchable = launchable,
                        minSdkVersion = appInfo.minSdkVersion,
                        targetSdkVersion = appInfo.targetSdkVersion,
                        signingCertSha256 = sigSha
                    )
                )
            } catch (_: PackageManager.NameNotFoundException) {
                // Package not installed
            } catch (_: Exception) {
                // Safe fallback
            }
        }
        return found
    }

    @Suppress("DEPRECATION")
    private fun computePackageSigningCertSha256(pm: PackageManager, pkg: String): String =
        runCatching {
            val sigBytes: ByteArray? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val flags = PackageManager.GET_SIGNING_CERTIFICATES.toLong()
                val info = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    pm.getPackageInfo(pkg, PackageManager.PackageInfoFlags.of(flags))
                } else {
                    pm.getPackageInfo(pkg, PackageManager.GET_SIGNING_CERTIFICATES)
                }
                val signingInfo = info.signingInfo
                val signers = if (signingInfo?.hasMultipleSigners() == true) {
                    signingInfo.apkContentsSigners
                } else {
                    signingInfo?.signingCertificateHistory
                }
                signers?.firstOrNull()?.toByteArray()
            } else {
                pm.getPackageInfo(pkg, PackageManager.GET_SIGNATURES).signatures?.firstOrNull()?.toByteArray()
            }
            if (sigBytes != null) computeSha256Short(sigBytes) else ""
        }.getOrDefault("")

    private fun probeEmbeddedNativeLibs(appInfo: ApplicationInfo): List<NativeLibEntry> {
        val apkPaths = buildList {
            appInfo.sourceDir?.takeIf { it.isNotBlank() }?.let { add(it) }
            appInfo.splitSourceDirs?.forEach { if (!it.isNullOrBlank()) add(it) }
        }.distinct()
        val found = mutableListOf<NativeLibEntry>()
        for (apkPath in apkPaths) {
            val file = File(apkPath)
            if (!file.exists() || !file.canRead()) continue
            try {
                ZipFile(file).use { zip ->
                    val entries = zip.entries()
                    while (entries.hasMoreElements()) {
                        val entry = entries.nextElement()
                        val name = entry.name
                        if (!entry.isDirectory && name.startsWith("lib/") && name.endsWith(".so")) {
                            val abi = name.split("/").getOrNull(1) ?: "unknown"
                            val header = ByteArray(24)
                            val readCount = zip.getInputStream(entry).use { it.read(header) }
                            val elfArch = if (readCount >= 20) inspectElfHeader(header) else ""
                            found.add(
                                NativeLibEntry(
                                    abi = abi,
                                    entryPath = name,
                                    compressedSize = entry.compressedSize.coerceAtLeast(0L),
                                    uncompressedSize = entry.size.coerceAtLeast(0L),
                                    sourceApkName = file.name,
                                    elfArchLabel = elfArch,
                                    isStoredUncompressed = entry.method == ZipEntry.STORED
                                )
                            )
                        }
                    }
                }
            } catch (_: Exception) {
                // Skip unreadable or non-zip path safely
            }
        }
        return found
    }

    // Strictly verifies real ELF binary AND size > 1 MB (1,048,576 bytes). Never trusts fake files.
    // Uses nativeLibraryDir directly if a valid matching ELF exists there; otherwise checks extracted cache.
    suspend fun inspectProfileCache(
        profileId: String,
        displayName: String,
        versionName: String,
        packageName: String,
        targetAbi: String,
        deviceSupportedAbis: List<String>,
        sourceType: ProfileSourceType,
        isCustomInstance: Boolean = false,
        installedNativeLibDir: String? = null
    ): GameProfile = withContext(Dispatchers.IO) {
        val profileDir = File(cacheRootDir, profileId)
        val availableAbis = profileDir.listFiles()
            ?.filter { abiSubDir ->
                if (!abiSubDir.isDirectory) return@filter false
                val f = File(abiSubDir, "libminecraftpe.so")
                f.exists() && f.length() > ElfBinaryInspector.MIN_VERIFIED_LIB_BYTES &&
                    ElfBinaryInspector.inspectElfFile(f).isValidElf
            }
            ?.map { it.name }
            ?.sorted()
            .orEmpty()

        val sysLibDir = installedNativeLibDir?.takeIf { it.isNotBlank() }?.let { File(it) }
        val sysLibFile = sysLibDir?.let { File(it, "libminecraftpe.so") }
            ?.takeIf { it.exists() && it.canRead() && it.length() > ElfBinaryInspector.MIN_VERIFIED_LIB_BYTES }
        val sysLibElf = sysLibFile?.let { ElfBinaryInspector.inspectElfFile(it) }
        val canUseSysLibDirectly = sysLibFile != null &&
            sysLibElf != null &&
            sysLibElf.isValidElf &&
            sysLibElf.meetsMinSize1Mb &&
            ElfBinaryInspector.matchesAbi(sysLibElf, targetAbi) &&
            deviceSupportedAbis.contains(targetAbi)

        val abiDir = if (canUseSysLibDirectly) sysLibDir!! else File(profileDir, targetAbi)
        val targetLibFile = if (canUseSysLibDirectly) sysLibFile!! else File(abiDir, "libminecraftpe.so")
        val sidecarMetaFile = File(File(profileDir, targetAbi), "libminecraftpe.levimeta")

        var isRealElf = false
        var elfLabel = ""
        var sha256 = "—"
        var reportedSize = 0L
        var metaMap: Map<String, String> = emptyMap()
        var is16KbAligned = false
        var maxLoadAlignBytes = 0L
        var neededLibraries = emptyList<String>()
        var verificationNote = ""
        var verified = false

        if (sidecarMetaFile.exists()) {
            metaMap = runCatching { parseCacheMetadata(sidecarMetaFile.readBytes()) }.getOrDefault(emptyMap())
        }

        if (targetLibFile.exists()) {
            reportedSize = targetLibFile.length()
            val elfReport = if (canUseSysLibDirectly) sysLibElf!! else ElfBinaryInspector.inspectElfFile(targetLibFile)
            isRealElf = elfReport.isValidElf
            elfLabel = elfReport.archLabel
            is16KbAligned = elfReport.is16KbAligned
            maxLoadAlignBytes = elfReport.maxLoadAlignBytes
            neededLibraries = elfReport.neededLibraries

            if (!isRealElf) {
                verificationNote = "Invalid binary: not an ELF file (${elfReport.archLabel})"
            } else if (!elfReport.meetsMinSize1Mb) {
                verificationNote = "File too small (${reportedSize} bytes <= 1 MB minimum)"
            } else if (!ElfBinaryInspector.matchesAbi(elfReport, targetAbi)) {
                verificationNote = "ELF machine (${elfReport.archLabel}) does not match $targetAbi"
            } else if (!deviceSupportedAbis.contains(targetAbi)) {
                verificationNote = "$targetAbi is not supported on this device"
            } else {
                verified = true
                sha256 = if (canUseSysLibDirectly) {
                    computeFileSha256Short(targetLibFile)
                } else {
                    metaMap["real_sha256"]?.takeIf { it.isNotBlank() } ?: computeFileSha256Short(targetLibFile)
                }
                val mb = reportedSize / (1024 * 1024)
                verificationNote = if (canUseSysLibDirectly) {
                    "Verified direct nativeLibraryDir ELF ($mb MB)"
                } else {
                    "Verified extracted ELF ($mb MB)"
                }
            }
        } else {
            verificationNote = "libminecraftpe.so not in nativeLibraryDir and not extracted to cache yet"
        }

        val status = when {
            verified -> CacheHealthStatus.VERIFIED
            targetLibFile.exists() && isRealElf && !ElfBinaryInspector.matchesAbi(
                ElfBinaryInspector.inspectElfFile(targetLibFile),
                targetAbi
            ) -> CacheHealthStatus.ABI_MISMATCH
            targetLibFile.exists() && !deviceSupportedAbis.contains(targetAbi) -> CacheHealthStatus.ABI_MISMATCH
            availableAbis.isNotEmpty() && !verified -> CacheHealthStatus.ABI_MISMATCH
            else -> CacheHealthStatus.MISSING_LIB
        }

        val companions = abiDir.listFiles()
            ?.filter { it.isFile && it.name.endsWith(".so") && it.name != "libminecraftpe.so" }
            ?.map { it.name }
            ?.sorted()
            .orEmpty()

        val resolvedAvailableAbis = if (canUseSysLibDirectly) {
            (availableAbis + targetAbi).distinct().sorted()
        } else {
            availableAbis
        }

        GameProfile(
            id = profileId,
            displayName = displayName,
            versionName = versionName,
            packageName = packageName,
            targetAbi = targetAbi,
            cacheStatus = status,
            cachePath = targetLibFile.absolutePath,
            cachedLibSizeBytes = reportedSize,
            cachedLibSha256 = sha256,
            sourceType = sourceType,
            availableCachedAbis = resolvedAvailableAbis,
            isInstalledOnDevice = false,
            installedVersionName = null,
            cacheSourceSummary = if (canUseSysLibDirectly) {
                "Direct nativeLibraryDir (${targetLibFile.parent})"
            } else {
                metaMap["source"].orEmpty()
            },
            elfArchLabel = elfLabel,
            isCustomInstance = isCustomInstance,
            companionLibsFound = companions,
            hasRealElfBinary = isRealElf && reportedSize > ElfBinaryInspector.MIN_VERIFIED_LIB_BYTES,
            is16KbAligned = is16KbAligned,
            maxLoadAlignBytes = maxLoadAlignBytes,
            neededLibraries = neededLibraries,
            verificationNote = verificationNote
        )
    }

    // If libminecraftpe.so already exists as a valid >1MB ELF in nativeLibraryDir, uses it directly.
    // Otherwise extracts lib/<abi> .so files matching Build.SUPPORTED_ABIS from sourceDir + splitSourceDirs
    // via .tmp write, byte size & ELF magic verification, and atomic rename.
    @Suppress("DEPRECATION")
    suspend fun extractRealLibsFromInstalledPackage(
        profileId: String,
        packageName: String,
        targetAbi: String
    ): RealExtractionResult = withContext(Dispatchers.IO) {
        val pm = context.packageManager
        val pkgInfo = runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getPackageInfo(packageName, PackageManager.PackageInfoFlags.of(0))
            } else {
                pm.getPackageInfo(packageName, 0)
            }
        }.getOrElse { err ->
            return@withContext RealExtractionResult(
                success = false,
                mainLib = null,
                extractedFiles = emptyList(),
                extractedAbis = emptyList(),
                failureMessage = "Package '$packageName' not found via PackageManager: ${err.message}"
            )
        }

        val appInfo = pkgInfo.applicationInfo
            ?: return@withContext RealExtractionResult(
                success = false,
                mainLib = null,
                extractedFiles = emptyList(),
                extractedAbis = emptyList(),
                failureMessage = "ApplicationInfo is null for '$packageName'."
            )

        val supportedAbis = Build.SUPPORTED_ABIS?.toList().orEmpty().ifEmpty { listOf(targetAbi) }
        val abisToExtract = (listOf(targetAbi) + supportedAbis).distinct()
        val extractedFileNames = mutableListOf<String>()
        val extractedAbis = linkedSetOf<String>()
        val extractedCompanionsByAbi = mutableMapOf<String, MutableList<String>>()
        var mainLibEntry: NativeLibEntry? = null

        fun copyStreamViaTempAndVerify(
            input: InputStream,
            destFile: File,
            expectedSize: Long
        ): Pair<Boolean, String?> {
            destFile.parentFile?.mkdirs()
            val tmpFile = File(destFile.parentFile, "${destFile.name}.tmp")
            return try {
                if (tmpFile.exists()) tmpFile.delete()
                FileOutputStream(tmpFile).use { output ->
                    input.copyTo(output, bufferSize = 64 * 1024)
                    output.flush()
                }
                val writtenLen = tmpFile.length()
                if (writtenLen <= 0L) {
                    tmpFile.delete()
                    return false to "Zero bytes written for ${destFile.name}"
                }
                if (expectedSize > 0L && writtenLen != expectedSize) {
                    tmpFile.delete()
                    return false to "Size mismatch for ${destFile.name}: expected $expectedSize B, wrote $writtenLen B"
                }
                val elfHeader = ByteArray(24)
                val headerRead = tmpFile.inputStream().use { it.read(elfHeader) }
                val elfReport = if (headerRead >= 20) ElfBinaryInspector.inspectHeaderOnly(elfHeader) else ElfBinaryInspector.inspectHeaderOnly(ByteArray(0))
                if (!elfReport.isValidElf) {
                    tmpFile.delete()
                    return false to "${destFile.name} failed ELF header check (${elfReport.archLabel})"
                }
                if (destFile.name == "libminecraftpe.so" && writtenLen <= ElfBinaryInspector.MIN_VERIFIED_LIB_BYTES) {
                    tmpFile.delete()
                    return false to "libminecraftpe.so size ($writtenLen B) is not > 1 MB"
                }
                if (destFile.exists() && !destFile.delete()) {
                    tmpFile.delete()
                    return false to "Cannot replace existing ${destFile.name}"
                }
                if (!tmpFile.renameTo(destFile)) {
                    tmpFile.delete()
                    return false to "Failed to rename ${tmpFile.name} -> ${destFile.name}"
                }
                true to null
            } catch (e: Exception) {
                runCatching { tmpFile.delete() }
                false to "I/O error writing ${destFile.name}: ${e.message}"
            }
        }

        // 1. Check nativeLibraryDir first: if a valid >1MB matching ELF libminecraftpe.so exists there, use it directly without copying.
        val sysLibDir = appInfo.nativeLibraryDir?.takeIf { it.isNotBlank() }?.let { File(it) }
        if (sysLibDir != null && sysLibDir.exists() && sysLibDir.isDirectory) {
            val sysMainSo = File(sysLibDir, "libminecraftpe.so")
            if (sysMainSo.exists() && sysMainSo.isFile && sysMainSo.canRead()) {
                val elf = ElfBinaryInspector.inspectElfFile(sysMainSo)
                if (elf.isValidElf && elf.meetsMinSize1Mb && ElfBinaryInspector.matchesAbi(elf, targetAbi)) {
                    val sysFiles = sysLibDir.listFiles()
                        ?.filter { it.isFile && it.name.endsWith(".so") && it.canRead() }
                        .orEmpty()
                    val sha = computeFileSha256Short(sysMainSo)
                    val directMain = NativeLibEntry(
                        abi = targetAbi,
                        entryPath = sysMainSo.absolutePath,
                        compressedSize = sysMainSo.length(),
                        uncompressedSize = sysMainSo.length(),
                        sourceApkName = "nativeLibraryDir (direct)",
                        elfArchLabel = elf.archLabel,
                        sha256Short = sha
                    )
                    return@withContext RealExtractionResult(
                        success = true,
                        mainLib = directMain,
                        extractedFiles = sysFiles.map { "nativeLibraryDir/${it.name}" }.sorted(),
                        extractedAbis = listOf(targetAbi)
                    )
                }
            }
        }

        // 2. Otherwise scan sourceDir + splitSourceDirs for all lib/<abi> .so files matching Build.SUPPORTED_ABIS
        val apkPaths = buildList {
            appInfo.sourceDir?.takeIf { it.isNotBlank() }?.let { add(it) }
            appInfo.splitSourceDirs?.forEach { if (!it.isNullOrBlank()) add(it) }
        }.distinct()

        for (apkPath in apkPaths) {
            val apkFile = File(apkPath)
            if (!apkFile.exists() || !apkFile.canRead()) continue
            runCatching {
                ZipFile(apkFile).use { zip ->
                    val entries = zip.entries()
                    while (entries.hasMoreElements()) {
                        val entry = entries.nextElement()
                        val name = entry.name
                        if (!entry.isDirectory && name.startsWith("lib/") && name.endsWith(".so")) {
                            val parts = name.split("/")
                            val abi = parts.getOrNull(1) ?: continue
                            if (abi !in abisToExtract) continue
                            val libFileName = parts.lastOrNull() ?: continue
                            val abiDir = File(cacheRootDir, "$profileId/$abi")
                            val dest = File(abiDir, libFileName)

                            val (ok, err) = zip.getInputStream(entry).use { input ->
                                copyStreamViaTempAndVerify(input, dest, entry.size)
                            }
                            if (ok) {
                                extractedFileNames.add("$abi/$libFileName")
                                extractedAbis.add(abi)
                                if (libFileName == "libminecraftpe.so" && (abi == targetAbi || mainLibEntry == null)) {
                                    val sha = computeFileSha256Short(dest)
                                    val elf = ElfBinaryInspector.inspectElfFile(dest)
                                    mainLibEntry = NativeLibEntry(
                                        abi = abi,
                                        entryPath = name,
                                        compressedSize = entry.compressedSize.coerceAtLeast(0L),
                                        uncompressedSize = dest.length(),
                                        sourceApkName = apkFile.name,
                                        elfArchLabel = elf.archLabel,
                                        isStoredUncompressed = entry.method == ZipEntry.STORED,
                                        sha256Short = sha
                                    )
                                } else if (libFileName != "libminecraftpe.so") {
                                    extractedCompanionsByAbi.getOrPut(abi) { mutableListOf() }.add(libFileName)
                                }
                            } else if (libFileName == "libminecraftpe.so" && abi == targetAbi && err != null) {
                                return@withContext RealExtractionResult(false, null, extractedFileNames, extractedAbis.toList(), err)
                            }
                        }
                    }
                }
            }
        }

        val main = mainLibEntry
        if (main == null) {
            return@withContext RealExtractionResult(
                success = false,
                mainLib = null,
                extractedFiles = extractedFileNames,
                extractedAbis = extractedAbis.toList(),
                failureMessage = "No valid libminecraftpe.so (> 1 MB ELF) found in sourceDir, splitSourceDirs, or nativeLibraryDir for $packageName (ABIs: ${abisToExtract.joinToString()})."
            )
        }

        // Write sidecar metadata only (NEVER to libminecraftpe.so!)
        val sidecar = File(cacheRootDir, "$profileId/${main.abi}/libminecraftpe.levimeta")
        val companions = extractedCompanionsByAbi[main.abi].orEmpty().distinct()
        sidecar.writeText(
            buildString {
                appendLine("source=Extracted ELF from $packageName (${main.sourceApkName})")
                appendLine("real_sha256=${main.sha256Short}")
                appendLine("real_size_bytes=${main.uncompressedSize}")
                appendLine("companion_libs=${companions.joinToString(",")}")
                appendLine("extracted_at=${System.currentTimeMillis()}")
            }
        )

        RealExtractionResult(
            success = true,
            mainLib = main,
            extractedFiles = extractedFileNames.distinct(),
            extractedAbis = extractedAbis.toList()
        )
    }

    // Streams real native .so binaries from user-selected .apk / .apks / .xapk via temp file + size & ELF verification + rename.
    suspend fun extractRealLibsFromArchiveUri(
        uri: Uri,
        profileId: String,
        targetAbi: String
    ): RealExtractionResult = withContext(Dispatchers.IO) {
        val fileName = resolveFileName(uri)
        val supportedAbis = Build.SUPPORTED_ABIS?.toList().orEmpty().ifEmpty { listOf(targetAbi) }
        val abisToExtract = (listOf(targetAbi) + supportedAbis).distinct()
        val extractedFileNames = mutableListOf<String>()
        val extractedAbis = linkedSetOf<String>()
        val extractedCompanionsByAbi = mutableMapOf<String, MutableList<String>>()
        var mainLibEntry: NativeLibEntry? = null
        var lastError: String? = null

        fun copySoViaTempAndVerify(
            stream: InputStream,
            abi: String,
            entryName: String,
            expectedSize: Long,
            sourceApk: String,
            isStored: Boolean
        ) {
            val libFileName = entryName.substringAfterLast('/')
            val abiDir = File(cacheRootDir, "$profileId/$abi").apply { mkdirs() }
            val dest = File(abiDir, libFileName)
            val tmp = File(abiDir, "$libFileName.tmp")
            try {
                if (tmp.exists()) tmp.delete()
                FileOutputStream(tmp).use { output ->
                    stream.copyTo(output, bufferSize = 64 * 1024)
                    output.flush()
                }
                val writtenLen = tmp.length()
                if (writtenLen <= 0L) {
                    tmp.delete()
                    lastError = "Zero bytes written for $libFileName"
                    return
                }
                if (expectedSize > 0L && writtenLen != expectedSize) {
                    tmp.delete()
                    lastError = "Size mismatch for $libFileName: expected $expectedSize, got $writtenLen"
                    return
                }
                val header = ByteArray(24)
                val n = tmp.inputStream().use { it.read(header) }
                val elfHeader = if (n >= 20) ElfBinaryInspector.inspectHeaderOnly(header) else ElfBinaryInspector.inspectHeaderOnly(ByteArray(0))
                if (!elfHeader.isValidElf) {
                    tmp.delete()
                    lastError = "$libFileName is not a valid ELF binary"
                    return
                }
                if (libFileName == "libminecraftpe.so" && writtenLen <= ElfBinaryInspector.MIN_VERIFIED_LIB_BYTES) {
                    tmp.delete()
                    lastError = "libminecraftpe.so ($writtenLen B) is <= 1 MB minimum"
                    return
                }
                if (dest.exists()) dest.delete()
                if (!tmp.renameTo(dest)) {
                    tmp.delete()
                    lastError = "Failed to rename temp file for $libFileName"
                    return
                }
                extractedFileNames.add("$abi/$libFileName")
                extractedAbis.add(abi)
                if (libFileName == "libminecraftpe.so" && (abi == targetAbi || mainLibEntry == null)) {
                    val sha = computeFileSha256Short(dest)
                    val elf = ElfBinaryInspector.inspectElfFile(dest)
                    mainLibEntry = NativeLibEntry(
                        abi = abi,
                        entryPath = entryName,
                        compressedSize = writtenLen,
                        uncompressedSize = writtenLen,
                        sourceApkName = sourceApk,
                        elfArchLabel = elf.archLabel,
                        isStoredUncompressed = isStored,
                        sha256Short = sha
                    )
                } else if (libFileName != "libminecraftpe.so") {
                    extractedCompanionsByAbi.getOrPut(abi) { mutableListOf() }.add(libFileName)
                }
            } catch (e: Exception) {
                runCatching { tmp.delete() }
                lastError = "Extraction error for $libFileName: ${e.message}"
            }
        }

        runCatching {
            context.contentResolver.openInputStream(uri)?.use { raw ->
                ZipInputStream(BufferedInputStream(raw, 64 * 1024)).use { zis ->
                    var entry = zis.nextEntry
                    while (entry != null) {
                        val name = entry.name
                        if (!entry.isDirectory) {
                            when {
                                name.startsWith("lib/") && name.endsWith(".so") -> {
                                    val abi = name.split("/").getOrNull(1)
                                    if (abi != null && abi in abisToExtract) {
                                        copySoViaTempAndVerify(
                                            zis,
                                            abi,
                                            name,
                                            entry.size,
                                            fileName,
                                            entry.method == ZipEntry.STORED
                                        )
                                    }
                                }
                                name.endsWith(".apk", ignoreCase = true) -> {
                                    val nestedStream = object : InputStream() {
                                        override fun read(): Int = zis.read()
                                        override fun read(b: ByteArray, off: Int, len: Int): Int = zis.read(b, off, len)
                                        override fun close() {}
                                    }
                                    val nestedZip = ZipInputStream(nestedStream)
                                    var nestedEntry = nestedZip.nextEntry
                                    while (nestedEntry != null) {
                                        val nName = nestedEntry.name
                                        if (!nestedEntry.isDirectory && nName.startsWith("lib/") && nName.endsWith(".so")) {
                                            val abi = nName.split("/").getOrNull(1)
                                            if (abi != null && abi in abisToExtract) {
                                                copySoViaTempAndVerify(
                                                    nestedZip,
                                                    abi,
                                                    nName,
                                                    nestedEntry.size,
                                                    name.substringAfterLast('/'),
                                                    nestedEntry.method == ZipEntry.STORED
                                                )
                                            }
                                        }
                                        nestedZip.closeEntry()
                                        nestedEntry = nestedZip.nextEntry
                                    }
                                }
                            }
                        }
                        zis.closeEntry()
                        entry = zis.nextEntry
                    }
                }
            }
        }.onFailure { lastError = it.message }

        val main = mainLibEntry ?: return@withContext RealExtractionResult(
            success = false,
            mainLib = null,
            extractedFiles = extractedFileNames,
            extractedAbis = extractedAbis.toList(),
            failureMessage = lastError ?: "No valid libminecraftpe.so (> 1 MB ELF) found in archive $fileName"
        )

        val sidecar = File(cacheRootDir, "$profileId/${main.abi}/libminecraftpe.levimeta")
        val companions = extractedCompanionsByAbi[main.abi].orEmpty().distinct()
        sidecar.writeText(
            buildString {
                appendLine("source=Extracted ELF from $fileName -> ${main.sourceApkName}")
                appendLine("real_sha256=${main.sha256Short}")
                appendLine("real_size_bytes=${main.uncompressedSize}")
                appendLine("companion_libs=${companions.joinToString(",")}")
                appendLine("extracted_at=${System.currentTimeMillis()}")
            }
        )

        RealExtractionResult(
            success = true,
            mainLib = main,
            extractedFiles = extractedFileNames.distinct(),
            extractedAbis = extractedAbis.toList()
        )
    }

    suspend fun clearProfileCacheForAbi(profileId: String, targetAbi: String): Boolean = withContext(Dispatchers.IO) {
        val abiDir = File(cacheRootDir, "$profileId/$targetAbi")
        if (abiDir.exists()) {
            abiDir.listFiles()?.forEach { file ->
                if (file.isFile && (file.name.endsWith(".so") || file.name.endsWith(".levimeta") || file.name.endsWith(".tmp"))) {
                    file.delete()
                }
            }
        }
        !File(abiDir, "libminecraftpe.so").exists()
    }

    suspend fun inspectArchiveUri(uri: Uri, deviceSupportedAbis: List<String>): ApkInspectionResult =
        withContext(Dispatchers.IO) {
            val fileName = resolveFileName(uri)
            val fileSize = resolveFileSize(uri)
            val foundLibs = mutableListOf<NativeLibEntry>()
            val companionLibs = mutableListOf<NativeLibEntry>()
            val splitApks = mutableListOf<String>()
            val splitFragments = mutableListOf<InstalledSplitFragment>()
            var hasAssets = false

            try {
                context.contentResolver.openInputStream(uri)?.use { rawStream ->
                    BufferedInputStream(rawStream, 64 * 1024).use { buffered ->
                        ZipInputStream(buffered).use { zis ->
                            var entry = zis.nextEntry
                            while (entry != null) {
                                val name = entry.name
                                if (!entry.isDirectory) {
                                    when {
                                        name.startsWith("assets/") -> hasAssets = true
                                        name.startsWith("lib/") && name.endsWith(".so") -> {
                                            val libEntry = readSoEntryMetadata(zis, name, entry, fileName)
                                            if (libEntry.libraryFileName == "libminecraftpe.so") {
                                                foundLibs.add(libEntry)
                                            } else {
                                                companionLibs.add(libEntry)
                                            }
                                        }
                                        name.endsWith(".apk", ignoreCase = true) -> {
                                            splitApks.add(name)
                                            val nestedResult = scanNestedApkStream(zis, name)
                                            foundLibs.addAll(nestedResult.libs)
                                            companionLibs.addAll(nestedResult.companionLibs)
                                            if (nestedResult.hasAssets) hasAssets = true
                                            val resolvedSize = if (entry.size > 0L) entry.size else nestedResult.bytesConsumed
                                            val shortName = name.substringAfterLast('/')
                                            splitFragments.add(
                                                InstalledSplitFragment(
                                                    splitName = shortName.removeSuffix(".apk"),
                                                    category = classifySplitApkName(shortName),
                                                    sourcePath = "$fileName!/$name",
                                                    sizeBytes = resolvedSize,
                                                    existsOnDisk = true
                                                )
                                            )
                                        }
                                    }
                                }
                                zis.closeEntry()
                                entry = zis.nextEntry
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                return@withContext ApkInspectionResult(
                    fileName = fileName,
                    fileSizeBytes = fileSize,
                    isSplitArchive = false,
                    splitApkNames = emptyList(),
                    foundNativeLibs = emptyList(),
                    hasAssetsFolder = false,
                    compatibleWithDevice = false,
                    missingPrimaryAbi = true,
                    diagnosisSummaryEn = "Failed to parse archive: ${e.message ?: "Invalid ZIP/APK header"}",
                    diagnosisSummaryAr = "تعذّر فحص الملف: ${e.message ?: "ملف ZIP/APK غير صالح"}"
                )
            }

            val primaryAbi = deviceSupportedAbis.firstOrNull() ?: "arm64-v8a"
            val compatible = foundLibs.any { it.abi in deviceSupportedAbis && it.uncompressedSize > ElfBinaryInspector.MIN_VERIFIED_LIB_BYTES }
            val hasPrimary = foundLibs.any { it.abi == primaryAbi && it.uncompressedSize > ElfBinaryInspector.MIN_VERIFIED_LIB_BYTES }
            val isSplit = splitApks.isNotEmpty()
            val resAndLangBytes = splitFragments
                .filter { it.category == SplitCategory.RESOURCE_DENSITY || it.category == SplitCategory.LANGUAGE }
                .sumOf { it.sizeBytes }
            val totalSplitBytes = splitFragments.sumOf { it.sizeBytes }

            val (summaryEn, summaryAr) = when {
                foundLibs.isEmpty() && isSplit -> Pair(
                    "Split archive detected (${splitApks.size} APKs), but no libminecraftpe.so found. Missing split_config.$primaryAbi.apk.",
                    "تم اكتشاف حزمة مقسمة (${splitApks.size} ملفات APK)، لكن مكتبة libminecraftpe.so غير موجودة."
                )
                foundLibs.isEmpty() -> Pair(
                    "No libminecraftpe.so found in archive.",
                    "لم يتم العثور على libminecraftpe.so داخل الملف."
                )
                !compatible -> Pair(
                    "Found ${foundLibs.joinToString { "${it.abi} (${it.uncompressedSize} B)" }}, incompatible or <= 1 MB.",
                    "المكتبات المكتشفة غير متوافقة مع المعمارية أو حجمها <= 1 ميجا."
                )
                !hasPrimary -> Pair(
                    "Compatible secondary ABI found, but primary ABI $primaryAbi is missing.",
                    "توجد معمارية بديلة متوافقة لكن المعمارية الأساسية $primaryAbi مفقودة."
                )
                else -> Pair(
                    "Verified ELF! Found lib/$primaryAbi/libminecraftpe.so (> 1 MB) inside ${foundLibs.first { it.abi == primaryAbi }.sourceApkName}.",
                    "تم التحقق! تم العثور على lib/$primaryAbi/libminecraftpe.so (> 1 ميجا) وجاهز للاستخراج."
                )
            }

            var archivePackageName: String? = null
            var archiveVersionName: String? = null
            if (fileName.endsWith(".apk", ignoreCase = true)) {
                val manifestMeta = parseApkArchiveManifest(uri)
                archivePackageName = manifestMeta?.first
                archiveVersionName = manifestMeta?.second
            }

            ApkInspectionResult(
                fileName = fileName,
                fileSizeBytes = fileSize,
                archivePackageName = archivePackageName,
                archiveVersionName = archiveVersionName,
                isSplitArchive = isSplit,
                splitApkNames = splitApks,
                splitFragments = splitFragments,
                resourceAndLanguageTotalBytes = resAndLangBytes,
                totalArchiveSplitBytes = totalSplitBytes,
                foundNativeLibs = foundLibs,
                companionNativeLibs = companionLibs,
                hasAssetsFolder = hasAssets,
                compatibleWithDevice = compatible,
                missingPrimaryAbi = !hasPrimary,
                diagnosisSummaryEn = summaryEn,
                diagnosisSummaryAr = summaryAr
            )
        }

    private fun readSoEntryMetadata(
        stream: InputStream,
        entryName: String,
        entry: ZipEntry,
        sourceApkName: String
    ): NativeLibEntry {
        val parts = entryName.split("/")
        val abi = parts.getOrNull(1) ?: "unknown"
        val fileName = entryName.substringAfterLast('/')
        val header = ByteArray(24)
        val readCount = stream.read(header)
        val elfArch = if (readCount >= 20) inspectElfHeader(header) else ""

        var shaShort = ""
        var totalSize = entry.size.coerceAtLeast(0L)
        if (fileName == "libminecraftpe.so" && readCount > 0) {
            val digest = MessageDigest.getInstance("SHA-256")
            digest.update(header, 0, readCount)
            var streamed = readCount.toLong()
            val buf = ByteArray(16 * 1024)
            var n = stream.read(buf)
            while (n > 0) {
                digest.update(buf, 0, n)
                streamed += n
                n = stream.read(buf)
            }
            shaShort = digest.digest().take(6).joinToString("") { "%02x".format(it) }
            if (totalSize <= 0L) totalSize = streamed
        }

        return NativeLibEntry(
            abi = abi,
            entryPath = entryName,
            compressedSize = entry.compressedSize.coerceAtLeast(0L),
            uncompressedSize = totalSize,
            sourceApkName = sourceApkName,
            elfArchLabel = elfArch,
            isStoredUncompressed = entry.method == ZipEntry.STORED,
            sha256Short = shaShort
        )
    }

    @Suppress("DEPRECATION")
    private fun parseApkArchiveManifest(uri: Uri): Pair<String, String>? {
        val tempApk = File(context.cacheDir, "inspect_tmp_${System.currentTimeMillis()}.apk")
        return try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                tempApk.outputStream().use { output ->
                    input.copyTo(output, bufferSize = 32 * 1024)
                }
            }
            val pm = context.packageManager
            val info = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getPackageArchiveInfo(tempApk.absolutePath, PackageManager.PackageInfoFlags.of(0))
            } else {
                pm.getPackageArchiveInfo(tempApk.absolutePath, 0)
            }
            if (info != null) {
                Pair(info.packageName, info.versionName ?: "Unknown")
            } else null
        } catch (_: Exception) {
            null
        } finally {
            if (tempApk.exists()) tempApk.delete()
        }
    }

    private data class NestedApkScanResult(
        val libs: List<NativeLibEntry>,
        val companionLibs: List<NativeLibEntry>,
        val hasAssets: Boolean,
        val bytesConsumed: Long
    )

    private fun scanNestedApkStream(
        parentStream: InputStream,
        nestedApkName: String
    ): NestedApkScanResult {
        val libs = mutableListOf<NativeLibEntry>()
        val companionLibs = mutableListOf<NativeLibEntry>()
        var hasAssets = false
        var bytesRead = 0L
        val countingStream = object : InputStream() {
            override fun read(): Int {
                val b = parentStream.read()
                if (b >= 0) bytesRead++
                return b
            }

            override fun read(b: ByteArray, off: Int, len: Int): Int {
                val n = parentStream.read(b, off, len)
                if (n > 0) bytesRead += n
                return n
            }

            override fun close() {}
        }
        try {
            val nestedZip = ZipInputStream(countingStream)
            var entry = nestedZip.nextEntry
            while (entry != null) {
                val name = entry.name
                if (!entry.isDirectory) {
                    if (name.startsWith("assets/")) hasAssets = true
                    if (name.startsWith("lib/") && name.endsWith(".so")) {
                        val libEntry = readSoEntryMetadata(nestedZip, name, entry, nestedApkName)
                        if (libEntry.libraryFileName == "libminecraftpe.so") {
                            libs.add(libEntry)
                        } else {
                            companionLibs.add(libEntry)
                        }
                    }
                }
                nestedZip.closeEntry()
                entry = nestedZip.nextEntry
            }
            val buf = ByteArray(8192)
            while (countingStream.read(buf, 0, buf.size) > 0) {
                // Drain nested APK central directory
            }
        } catch (_: Exception) {
            // Nested entry could not be parsed cleanly
        }
        return NestedApkScanResult(libs, companionLibs, hasAssets, bytesRead)
    }

    fun inspectElfHeader(bytes: ByteArray): String =
        ElfBinaryInspector.inspectHeaderOnly(bytes).archLabel

    fun buildDiagnosticReport(
        telemetry: DeviceTelemetry?,
        profile: GameProfile?,
        sandbox: IsolatedSandboxConfig?,
        session: LaunchSessionState,
        linkedSafSummary: SafMojangTreeSummary? = null
    ): String = buildString {
        appendLine("=== LeviLab Diagnostic Report ===")
        appendLine("Device: ${telemetry?.deviceModel ?: "Unknown"} (Android ${telemetry?.androidVersion ?: "?"}, SDK ${telemetry?.sdkInt ?: 0})")
        appendLine("Supported ABIs: ${telemetry?.supportedAbis?.joinToString() ?: "Unknown"}")
        appendLine("Profile: ${profile?.displayName ?: "N/A"} (${profile?.versionName ?: "?"})")
        appendLine("Target Package: ${profile?.packageName ?: session.targetPackageName}")
        val installedMatch = telemetry?.installedEditions?.firstOrNull {
            it.packageName == (profile?.packageName ?: session.targetPackageName)
        }
        if (installedMatch != null) {
            appendLine("Installed APK: v${installedMatch.versionName} | sourceDir=${installedMatch.sourceDir} | nativeLibraryDir=${installedMatch.nativeLibraryDir}")
            appendLine("splitSourceDirs (${installedMatch.splitSourceDirs.size}): ${installedMatch.splitSourceDirs.joinToString()}")
        }
        appendLine("Target ABI: ${profile?.targetAbi ?: "?"}")
        appendLine("Cache Status: ${profile?.cacheStatus ?: "?"} | Size: ${profile?.cachedLibSizeBytes ?: 0} B | SHA-256: ${profile?.cachedLibSha256 ?: "—"} | RealELF=${profile?.hasRealElfBinary ?: false}")
        if (profile?.hasRealElfBinary == true) {
            appendLine("ELF 16KB Page Aligned: ${profile.is16KbAligned} (p_align=${profile.maxLoadAlignBytes})")
            if (profile.neededLibraries.isNotEmpty()) {
                appendLine("ELF DT_NEEDED: ${profile.neededLibraries.joinToString()}")
            }
        }
        appendLine("Cache Path: ${profile?.cachePath ?: "—"}")
        if (sandbox != null) {
            appendLine("Isolated Sandbox: ${sandbox.sandboxRootPath}")
        }
        if (linkedSafSummary != null) {
            appendLine("Linked SAF Folder: ${linkedSafSummary.folderDisplayName}")
        }
        appendLine()
        appendLine("--- Persisted Launch Log ---")
        session.logs.forEach { entry ->
            appendLine("[${entry.timestamp}] [${entry.level}] ${entry.message}")
        }
    }

    private fun parseCacheMetadata(bytes: ByteArray): Map<String, String> {
        val text = bytes.decodeToString()
        val map = mutableMapOf<String, String>()
        text.lineSequence().forEach { line ->
            val eqIdx = line.indexOf('=')
            if (eqIdx > 0) {
                val key = line.substring(0, eqIdx).trim()
                val value = line.substring(eqIdx + 1).trim()
                map[key] = value
            }
        }
        return map
    }

    private fun resolveFileName(uri: Uri): String {
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (nameIdx >= 0 && cursor.moveToFirst()) {
                return cursor.getString(nameIdx) ?: "selected_package.apk"
            }
        }
        return uri.lastPathSegment ?: "selected_package.apk"
    }

    private fun resolveFileSize(uri: Uri): Long {
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
            if (sizeIdx >= 0 && cursor.moveToFirst()) {
                return cursor.getLong(sizeIdx)
            }
        }
        return 0L
    }

    private fun computeFileSha256Short(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val buf = ByteArray(32 * 1024)
        file.inputStream().use { input ->
            var read = input.read(buf)
            while (read > 0) {
                digest.update(buf, 0, read)
                read = input.read(buf)
            }
        }
        return digest.digest().take(6).joinToString("") { "%02x".format(it) }
    }

    private fun computeSha256Short(bytes: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(bytes)
        return digest.take(6).joinToString("") { "%02x".format(it) }
    }
}
