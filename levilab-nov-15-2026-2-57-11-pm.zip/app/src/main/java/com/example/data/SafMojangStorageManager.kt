package com.example.data

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class SafMojangTreeSummary(
    val treeUriString: String,
    val folderDisplayName: String,
    val worldsCount: Int,
    val worldNames: List<String>,
    val resourcePacksCount: Int,
    val behaviorPacksCount: Int,
    val hasOptionsTxt: Boolean,
    val optionsTxtUriString: String?,
    val minecraftpeDirUriString: String? = null
)

class SafMojangStorageManager(private val context: Context) {

    suspend fun inspectLinkedTree(treeUri: Uri): SafMojangTreeSummary? = withContext(Dispatchers.IO) {
        runCatching {
            val treeDocId = DocumentsContract.getTreeDocumentId(treeUri)
            val rootChildren = listChildren(treeUri, treeDocId)

            val mojangDocId = rootChildren.firstOrNull {
                it.name.equals("com.mojang", ignoreCase = true) && it.isDirectory
            }?.docId ?: run {
                val gamesDir = rootChildren.firstOrNull {
                    it.name.equals("games", ignoreCase = true) && it.isDirectory
                }
                if (gamesDir != null) {
                    listChildren(treeUri, gamesDir.docId).firstOrNull {
                        it.name.equals("com.mojang", ignoreCase = true) && it.isDirectory
                    }?.docId ?: treeDocId
                } else {
                    treeDocId
                }
            }

            val mojangChildren = listChildren(treeUri, mojangDocId)
            val worldsDir = mojangChildren.firstOrNull { it.name.equals("minecraftWorlds", ignoreCase = true) && it.isDirectory }
            val rpDir = mojangChildren.firstOrNull { it.name.equals("resource_packs", ignoreCase = true) && it.isDirectory }
            val bpDir = mojangChildren.firstOrNull { it.name.equals("behavior_packs", ignoreCase = true) && it.isDirectory }
            val peDir = mojangChildren.firstOrNull { it.name.equals("minecraftpe", ignoreCase = true) && it.isDirectory }

            val worldChildren = if (worldsDir != null) {
                listChildren(treeUri, worldsDir.docId).filter { it.isDirectory }
            } else emptyList()

            val worldNames = worldChildren.take(10).map { worldEntry ->
                val files = listChildren(treeUri, worldEntry.docId)
                val levelNameFile = files.firstOrNull { it.name == "levelname.txt" }
                if (levelNameFile != null) {
                    val fileUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, levelNameFile.docId)
                    runCatching {
                        context.contentResolver.openInputStream(fileUri)?.bufferedReader()?.use { it.readText().trim() }
                    }.getOrNull()?.takeIf { it.isNotBlank() } ?: worldEntry.name
                } else {
                    worldEntry.name
                }
            }

            val rpCount = if (rpDir != null) listChildren(treeUri, rpDir.docId).size else 0
            val bpCount = if (bpDir != null) listChildren(treeUri, bpDir.docId).size else 0

            val optionsEntry = if (peDir != null) {
                listChildren(treeUri, peDir.docId).firstOrNull { it.name == "options.txt" }
            } else {
                mojangChildren.firstOrNull { it.name == "options.txt" }
            }
            val optionsUri = optionsEntry?.let {
                DocumentsContract.buildDocumentUriUsingTree(treeUri, it.docId).toString()
            }
            val peDirDocId = peDir?.docId ?: mojangDocId
            val peDirUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, peDirDocId).toString()

            SafMojangTreeSummary(
                treeUriString = treeUri.toString(),
                folderDisplayName = treeDocId.substringAfterLast(':').ifBlank { "com.mojang" },
                worldsCount = worldChildren.size,
                worldNames = worldNames,
                resourcePacksCount = rpCount,
                behaviorPacksCount = bpCount,
                hasOptionsTxt = optionsUri != null,
                optionsTxtUriString = optionsUri,
                minecraftpeDirUriString = peDirUri
            )
        }.getOrNull()
    }

    suspend fun ensureOrCreateOptionsTxtUri(summary: SafMojangTreeSummary): Uri? = withContext(Dispatchers.IO) {
        summary.optionsTxtUriString?.let { return@withContext Uri.parse(it) }
        val parentUriStr = summary.minecraftpeDirUriString ?: return@withContext null
        runCatching {
            DocumentsContract.createDocument(
                context.contentResolver,
                Uri.parse(parentUriStr),
                "text/plain",
                "options.txt"
            )
        }.getOrNull()
    }

    suspend fun writeOptionsToSafUri(optionsUri: Uri, content: String): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            context.contentResolver.openOutputStream(optionsUri, "wt")?.use { out ->
                out.write(content.toByteArray())
                out.flush()
            }
            true
        }.getOrDefault(false)
    }

    suspend fun readOptionsFromSafUri(optionsUri: Uri): Map<String, String> = withContext(Dispatchers.IO) {
        runCatching {
            val lines = context.contentResolver.openInputStream(optionsUri)?.bufferedReader()?.use {
                it.readLines()
            }.orEmpty()
            val map = mutableMapOf<String, String>()
            lines.forEach { line ->
                val idx = line.indexOf(':')
                if (idx > 0) {
                    map[line.substring(0, idx).trim()] = line.substring(idx + 1).trim()
                }
            }
            map
        }.getOrDefault(emptyMap())
    }

    private data class DocChild(
        val docId: String,
        val name: String,
        val isDirectory: Boolean
    )

    private fun listChildren(treeUri: Uri, parentDocId: String): List<DocChild> {
        val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentDocId)
        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE
        )
        val results = mutableListOf<DocChild>()
        context.contentResolver.query(childrenUri, projection, null, null, null)?.use { cursor ->
            val idIdx = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
            val nameIdx = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
            val mimeIdx = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_MIME_TYPE)
            while (cursor.moveToNext()) {
                val id = cursor.getString(idIdx) ?: continue
                val name = cursor.getString(nameIdx) ?: continue
                val mime = cursor.getString(mimeIdx) ?: ""
                results.add(
                    DocChild(
                        docId = id,
                        name = name,
                        isDirectory = mime == DocumentsContract.Document.MIME_TYPE_DIR
                    )
                )
            }
        }
        return results
    }
}
