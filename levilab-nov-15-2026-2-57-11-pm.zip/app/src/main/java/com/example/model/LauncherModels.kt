package com.example.model

enum class AppLanguage(val code: String, val label: String) {
    EN("en", "English"),
    AR("ar", "العربية")
}

enum class CacheHealthStatus {
    VERIFIED,
    MISSING_LIB,
    ABI_MISMATCH,
    STALE_INDEX
}

enum class ProfileSourceType {
    INTERNAL_CACHE,
    APK_IMPORT,
    SPLIT_APKS,
    INSTALLED_PACKAGE
}

data class CustomProfileSpec(
    val id: String,
    val displayName: String,
    val versionName: String,
    val packageName: String,
    val isolatedDataEnabled: Boolean = true
)

data class IsolatedSandboxConfig(
    val profileId: String,
    val sandboxRootPath: String,
    val optionsTxtPath: String,
    val playerName: String = "BetaPlayer",
    val isolatedEnabled: Boolean = true,
    val gfxVsync: Boolean = true,
    val devEnableProfiler: Boolean = false,
    val devShowChunkMap: Boolean = false,
    val maxFramerate: Int = 60,
    val gfxViewDistance: Int = 12,
    val resourcePackCount: Int = 0,
    val behaviorPackCount: Int = 0,
    val worldsCount: Int = 0
)

data class GameProfile(
    val id: String,
    val displayName: String,
    val versionName: String,
    val packageName: String,
    val targetAbi: String,
    val cacheStatus: CacheHealthStatus,
    val cachePath: String,
    val cachedLibSizeBytes: Long,
    val cachedLibSha256: String,
    val sourceType: ProfileSourceType,
    val availableCachedAbis: List<String> = emptyList(),
    val isInstalledOnDevice: Boolean = false,
    val installedVersionName: String? = null,
    val cacheSourceSummary: String = "",
    val elfArchLabel: String = "",
    val isCustomInstance: Boolean = false,
    val companionLibsFound: List<String> = emptyList(),
    val hasRealElfBinary: Boolean = false,
    val is16KbAligned: Boolean = false,
    val maxLoadAlignBytes: Long = 0L,
    val neededLibraries: List<String> = emptyList(),
    val verificationNote: String = ""
)

data class InstalledMinecraftInfo(
    val packageName: String,
    val appLabel: String = "Minecraft",
    val versionName: String,
    val versionCode: Long,
    val nativeLibraryDir: String,
    val hasNativeLibInSystemDir: Boolean,
    val extractNativeLibsEnabled: Boolean = true,
    val embeddedNativeLibs: List<NativeLibEntry> = emptyList(),
    val companionNativeLibs: List<NativeLibEntry> = emptyList(),
    val splitNames: List<String>,
    val splitSourceDirs: List<String> = emptyList(),
    val sourceDir: String,
    val isLaunchable: Boolean = true,
    val minSdkVersion: Int = 0,
    val targetSdkVersion: Int = 0,
    val signingCertSha256: String = ""
)

data class BedrockServerPreset(
    val id: String,
    val name: String,
    val host: String,
    val port: Int = 19132
)

data class ServerPingStatus(
    val isPinging: Boolean = false,
    val isOnline: Boolean? = null,
    val latencyMs: Long = -1L,
    val motd: String = "",
    val gameVersion: String = "",
    val playerCount: Int = 0,
    val maxPlayers: Int = 0,
    val worldName: String = "",
    val gameMode: String = "",
    val error: String? = null
)

data class DeviceTelemetry(
    val deviceModel: String,
    val androidVersion: String,
    val sdkInt: Int,
    val supportedAbis: List<String>,
    val primaryAbi: String,
    val installedMinecraftPackage: InstalledMinecraftInfo?,
    val installedEditions: List<InstalledMinecraftInfo> = emptyList()
)

enum class SplitCategory {
    BASE_APK,
    NATIVE_ABI,
    RESOURCE_DENSITY,
    LANGUAGE,
    FEATURE_MODULE,
    OTHER
}

data class InstalledSplitFragment(
    val splitName: String,
    val category: SplitCategory,
    val sourcePath: String,
    val sizeBytes: Long,
    val existsOnDisk: Boolean
)

data class InstalledPackageSplitsReport(
    val packageName: String,
    val versionName: String,
    val isInstalled: Boolean,
    val baseApkPath: String,
    val baseApkSizeBytes: Long,
    val splitFragments: List<InstalledSplitFragment>,
    val resourceAndLanguageSplits: List<InstalledSplitFragment>,
    val resourceAndLanguageTotalBytes: Long,
    val totalPackageDiskBytes: Long
)

data class NativeLibEntry(
    val abi: String,
    val entryPath: String,
    val compressedSize: Long,
    val uncompressedSize: Long,
    val sourceApkName: String,
    val elfArchLabel: String = "",
    val isStoredUncompressed: Boolean = false,
    val sha256Short: String = ""
) {
    val libraryFileName: String
        get() = entryPath.substringAfterLast('/')
}

data class ApkInspectionResult(
    val fileName: String,
    val fileSizeBytes: Long,
    val archivePackageName: String? = null,
    val archiveVersionName: String? = null,
    val isSplitArchive: Boolean,
    val splitApkNames: List<String>,
    val splitFragments: List<InstalledSplitFragment> = emptyList(),
    val resourceAndLanguageTotalBytes: Long = 0L,
    val totalArchiveSplitBytes: Long = 0L,
    val foundNativeLibs: List<NativeLibEntry>,
    val companionNativeLibs: List<NativeLibEntry> = emptyList(),
    val hasAssetsFolder: Boolean,
    val compatibleWithDevice: Boolean,
    val missingPrimaryAbi: Boolean,
    val diagnosisSummaryEn: String,
    val diagnosisSummaryAr: String
)

enum class ModType {
    NATIVE_SO,
    RESOURCE_PACK,
    BEHAVIOR_PACK,
    WORLD_TEMPLATE
}

data class ModItem(
    val id: String,
    val name: String,
    val author: String,
    val version: String,
    val type: ModType,
    val requiredAbi: String,
    val enabled: Boolean,
    val loadOrder: Int,
    val descriptionEn: String,
    val descriptionAr: String,
    val stagedFilePath: String? = null,
    val minEngineVersion: String? = null,
    val isCustomAdded: Boolean = false,
    val is16KbAligned: Boolean? = null,
    val neededLibraries: List<String> = emptyList()
)

enum class LaunchStageId {
    STAGE_A_VERIFY_LIB,
    STAGE_B_LAUNCH_INSTALLED,
    STAGE_C_IN_PROCESS_LOAD
}

enum class StageState {
    PENDING,
    RUNNING,
    PASSED,
    FAILED
}

data class LaunchStageStep(
    val stageId: LaunchStageId,
    val state: StageState,
    val detail: String = "",
    val errorDetail: String? = null
)

enum class LogLevel {
    INFO,
    WARN,
    ERROR,
    FIX,
    SUCCESS
}

data class LaunchLogEntry(
    val id: Long,
    val timestamp: String,
    val level: LogLevel,
    val message: String
)

sealed class FailureReason {
    data class MissingMinecraftPeLib(
        val expectedPath: String,
        val expectedAbi: String,
        val availableAbisInCache: List<String>,
        val reasonDetail: String
    ) : FailureReason()

    data class AbiMismatch(
        val deviceAbi: String,
        val cachedAbi: String
    ) : FailureReason()

    data class ModConflict(
        val conflictingMods: List<String>,
        val targetAbi: String
    ) : FailureReason()

    data class PackageLaunchFailed(
        val packageName: String,
        val reasonDetail: String
    ) : FailureReason()

    data class InProcessLoadFailed(
        val packageName: String,
        val reasonDetail: String
    ) : FailureReason()
}

data class LaunchSessionState(
    val isRunning: Boolean = false,
    val progress: Float = 0f,
    val stages: List<LaunchStageStep> = LaunchStageId.entries.map { LaunchStageStep(it, StageState.PENDING) },
    val logs: List<LaunchLogEntry> = emptyList(),
    val failedReason: FailureReason? = null,
    val elapsedMs: Long = 0L,
    val targetPackageName: String = "com.mojang.minecraftpe.preview",
    val persistedLogPath: String = "",
    val crashRecoveryNote: String? = null
)

data class RootCauseGuideItem(
    val id: String,
    val titleEn: String,
    val titleAr: String,
    val symptomEn: String,
    val symptomAr: String,
    val solutionEn: String,
    val solutionAr: String,
    val severityTag: String
)
