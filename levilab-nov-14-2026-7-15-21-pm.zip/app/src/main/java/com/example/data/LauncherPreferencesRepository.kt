package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.AppLanguage
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "levilab_prefs")

data class LauncherPersistedPrefs(
    val selectedProfileId: String = "bedrock_trial_latest",
    val targetAbiOverride: String = "AUTO",
    val language: AppLanguage = AppLanguage.AR,
    val simulateMissingLib: Boolean = false,
    val disabledModIds: Set<String> = emptySet()
)

class LauncherPreferencesRepository(private val context: Context) {

    private object Keys {
        val SELECTED_PROFILE_ID = stringPreferencesKey("selected_profile_id")
        val TARGET_ABI_OVERRIDE = stringPreferencesKey("target_abi_override")
        val LANGUAGE = stringPreferencesKey("app_language")
        val SIMULATE_MISSING_LIB = booleanPreferencesKey("simulate_missing_lib")
        val DISABLED_MOD_IDS = stringSetPreferencesKey("disabled_mod_ids")
    }

    val prefsFlow: Flow<LauncherPersistedPrefs> = context.dataStore.data.map { prefs ->
        val langCode = prefs[Keys.LANGUAGE] ?: AppLanguage.AR.code
        LauncherPersistedPrefs(
            selectedProfileId = prefs[Keys.SELECTED_PROFILE_ID] ?: "bedrock_trial_latest",
            targetAbiOverride = prefs[Keys.TARGET_ABI_OVERRIDE] ?: "AUTO",
            language = if (langCode == AppLanguage.EN.code) AppLanguage.EN else AppLanguage.AR,
            simulateMissingLib = prefs[Keys.SIMULATE_MISSING_LIB] ?: false,
            disabledModIds = prefs[Keys.DISABLED_MOD_IDS] ?: emptySet()
        )
    }

    suspend fun setSelectedProfile(profileId: String) {
        context.dataStore.edit { it[Keys.SELECTED_PROFILE_ID] = profileId }
    }

    suspend fun setTargetAbiOverride(abi: String) {
        context.dataStore.edit { it[Keys.TARGET_ABI_OVERRIDE] = abi }
    }

    suspend fun setLanguage(language: AppLanguage) {
        context.dataStore.edit { it[Keys.LANGUAGE] = language.code }
    }

    suspend fun setSimulateMissingLib(enabled: Boolean) {
        context.dataStore.edit { it[Keys.SIMULATE_MISSING_LIB] = enabled }
    }

    suspend fun setDisabledModIds(disabledIds: Set<String>) {
        context.dataStore.edit { it[Keys.DISABLED_MOD_IDS] = disabledIds }
    }
}
