package com.example

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Build
import androidx.compose.material.icons.outlined.Extension
import androidx.compose.material.icons.outlined.Layers
import androidx.compose.material.icons.outlined.RocketLaunch
import androidx.compose.material.icons.rounded.Build
import androidx.compose.material.icons.rounded.Extension
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.RocketLaunch
import androidx.compose.material.icons.rounded.Translate
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.model.AppLanguage
import com.example.ui.LauncherViewModel
import com.example.ui.components.LeviLeafMark
import com.example.ui.screens.CacheDiagnosticsScreen
import com.example.ui.screens.LaunchConsoleScreen
import com.example.ui.screens.LauncherHomeScreen
import com.example.ui.screens.ModsManagerScreen
import com.example.ui.screens.SplitInspectorScreen
import com.example.ui.stringsFor
import com.example.ui.theme.LeviLabTheme
import kotlinx.coroutines.launch

const val ROUTE_LAUNCHER = "launcher"
const val ROUTE_SPLITS = "splits"
const val ROUTE_DIAGNOSTICS = "diagnostics"
const val ROUTE_MODS = "mods"
const val ROUTE_LAUNCH = "launch"

private data class TopNavTab(
    val route: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        setContent {
            LeviLabTheme(darkTheme = true) {
                LeviLabApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LeviLabApp(
    viewModel: LauncherViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val strings = remember(uiState.language) { stringsFor(uiState.language) }
    val layoutDirection = if (uiState.language == AppLanguage.AR) LayoutDirection.Rtl else LayoutDirection.Ltr

    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: ROUTE_LAUNCHER

    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    LaunchedEffect(uiState.statusBanner) {
        val msg = uiState.statusBanner
        if (msg != null) {
            snackbarHostState.showSnackbar(msg)
            viewModel.dismissStatusBanner()
        }
    }

    val tabs = remember(strings) {
        listOf(
            TopNavTab(
                route = ROUTE_LAUNCHER,
                label = strings.navLauncher,
                selectedIcon = Icons.Rounded.RocketLaunch,
                unselectedIcon = Icons.Outlined.RocketLaunch,
                testTag = "nav_tab_launcher"
            ),
            TopNavTab(
                route = ROUTE_SPLITS,
                label = strings.navSplits,
                selectedIcon = Icons.Rounded.Layers,
                unselectedIcon = Icons.Outlined.Layers,
                testTag = "nav_tab_splits"
            ),
            TopNavTab(
                route = ROUTE_DIAGNOSTICS,
                label = strings.navDiagnostics,
                selectedIcon = Icons.Rounded.Build,
                unselectedIcon = Icons.Outlined.Build,
                testTag = "nav_tab_diagnostics"
            ),
            TopNavTab(
                route = ROUTE_MODS,
                label = strings.navMods,
                selectedIcon = Icons.Rounded.Extension,
                unselectedIcon = Icons.Outlined.Extension,
                testTag = "nav_tab_mods"
            )
        )
    }

    fun navigateToTab(route: String) {
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    val showShellChrome = currentRoute != ROUTE_LAUNCH

    CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val useNavigationRail = maxWidth >= 600.dp

            Scaffold(
                modifier = Modifier.fillMaxSize(),
                containerColor = MaterialTheme.colorScheme.background,
                contentWindowInsets = WindowInsets.safeDrawing,
                snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
                topBar = {
                    if (showShellChrome) {
                        TopAppBar(
                            title = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    LeviLeafMark(size = 28.dp)
                                    Spacer(Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = strings.appTitle,
                                            style = MaterialTheme.typography.titleLarge,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = strings.appSubtitle,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1
                                        )
                                    }
                                }
                            },
                            actions = {
                                FilledTonalButton(
                                    onClick = {
                                        val nextLang = if (uiState.language == AppLanguage.AR) {
                                            AppLanguage.EN
                                        } else {
                                            AppLanguage.AR
                                        }
                                        viewModel.setLanguage(nextLang)
                                    },
                                    modifier = Modifier
                                        .padding(end = 8.dp)
                                        .testTag("language_toggle_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Translate,
                                        contentDescription = "Switch Language",
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(Modifier.width(6.dp))
                                    Text(
                                        text = if (uiState.language == AppLanguage.AR) "EN" else "عربي",
                                        style = MaterialTheme.typography.labelMedium
                                    )
                                }
                            },
                            colors = TopAppBarDefaults.topAppBarColors(
                                containerColor = MaterialTheme.colorScheme.background,
                                titleContentColor = MaterialTheme.colorScheme.onBackground
                            )
                        )
                    }
                },
                bottomBar = {
                    if (showShellChrome && !useNavigationRail) {
                        NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surface
                        ) {
                            tabs.forEach { tab ->
                                val selected = currentRoute == tab.route
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = { navigateToTab(tab.route) },
                                    modifier = Modifier.testTag(tab.testTag),
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                            contentDescription = tab.label
                                        )
                                    },
                                    label = { Text(tab.label) }
                                )
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    if (showShellChrome && useNavigationRail) {
                        NavigationRail(
                            containerColor = MaterialTheme.colorScheme.surface
                        ) {
                            tabs.forEach { tab ->
                                val selected = currentRoute == tab.route
                                NavigationRailItem(
                                    selected = selected,
                                    onClick = { navigateToTab(tab.route) },
                                    modifier = Modifier.testTag(tab.testTag),
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                            contentDescription = tab.label
                                        )
                                    },
                                    label = { Text(tab.label) }
                                )
                            }
                        }
                    }

                    NavHost(
                        navController = navController,
                        startDestination = ROUTE_LAUNCHER,
                        modifier = Modifier.weight(1f)
                    ) {
                        composable(ROUTE_LAUNCHER) {
                            LauncherHomeScreen(
                                uiState = uiState,
                                strings = strings,
                                onSelectProfile = viewModel::selectProfile,
                                onLaunchClick = {
                                    viewModel.startLaunchPreflight()
                                    navController.navigate(ROUTE_LAUNCH)
                                },
                                onOpenDiagnostics = { navigateToTab(ROUTE_DIAGNOSTICS) },
                                onInspectArchiveUri = viewModel::inspectArchive,
                                onApplyInspectedArchive = viewModel::applyInspectedArchiveToCache,
                                onToggleSimulateError = viewModel::setSimulateMissingLib
                            )
                        }
                        composable(ROUTE_SPLITS) {
                            SplitInspectorScreen(
                                uiState = uiState,
                                strings = strings,
                                onRefreshInstalledSplits = viewModel::refreshInstalledSplits,
                                onInspectArchiveUri = viewModel::inspectArchive
                            )
                        }
                        composable(ROUTE_DIAGNOSTICS) {
                            CacheDiagnosticsScreen(
                                uiState = uiState,
                                strings = strings,
                                onSelectAbiOverride = viewModel::setTargetAbiOverride,
                                onRepairCache = viewModel::repairSelectedProfileCache,
                                onClearCache = viewModel::clearSelectedProfileCache,
                                onTestLaunch = {
                                    viewModel.startLaunchPreflight()
                                    navController.navigate(ROUTE_LAUNCH)
                                }
                            )
                        }
                        composable(ROUTE_MODS) {
                            ModsManagerScreen(
                                uiState = uiState,
                                strings = strings,
                                onToggleMod = viewModel::toggleMod,
                                onMoveOrder = viewModel::moveModOrder,
                                onAddCustomMod = viewModel::addCustomMod
                            )
                        }
                        composable(ROUTE_LAUNCH) {
                            LaunchConsoleScreen(
                                uiState = uiState,
                                strings = strings,
                                onBackToLauncher = { navController.popBackStack() },
                                onAutoRepairAndRetry = viewModel::repairCacheAndRetryLaunch,
                                onOpenDiagnostics = {
                                    navController.popBackStack()
                                    navigateToTab(ROUTE_DIAGNOSTICS)
                                },
                                onInspectArchiveUri = viewModel::inspectArchive,
                                onOpenInstalledGame = { pkg -> viewModel.openGamePackage(pkg) },
                                onOpenPlayStore = viewModel::openPlayStoreForPackage,
                                onShowCopiedFeedback = { msg ->
                                    scope.launch { snackbarHostState.showSnackbar(msg) }
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
