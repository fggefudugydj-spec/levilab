package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Obsidian & Emerald palette tailored for LeviLab Launcher
val ObsidianBg = Color(0xFF070D0C)
val ObsidianSurface = Color(0xFF0B1513)
val ObsidianSurfaceContainer = Color(0xFF101F1C)
val ObsidianSurfaceHigh = Color(0xFF162B27)
val ObsidianConsoleBg = Color(0xFF050F0D)

val EmeraldPrimary = Color(0xFF1BB89A)
val EmeraldPrimaryBright = Color(0xFF4BE2C0)
val EmeraldOnPrimary = Color(0xFF02201A)
val EmeraldContainer = Color(0xFF0D473C)
val EmeraldOnContainer = Color(0xFFA7F7E5)

val MintSecondary = Color(0xFF66D9B8)
val MintOnSecondary = Color(0xFF04241B)
val MintContainer = Color(0xFF143830)
val MintOnContainer = Color(0xFFBDF5E4)

val AmberTertiary = Color(0xFFF5B74F)
val AmberOnTertiary = Color(0xFF2B1B00)
val AmberContainer = Color(0xFF422C05)
val AmberOnContainer = Color(0xFFFFDFAA)

val CoralError = Color(0xFFFF6B6B)
val CoralOnError = Color(0xFF330608)
val CoralContainer = Color(0xFF451215)
val CoralOnContainer = Color(0xFFFFD6D6)

val TextPrimary = Color(0xFFECF4F2)
val TextSecondary = Color(0xFF9CB3AD)
val OutlineTeal = Color(0xFF1D4D43)
val OutlineSubtle = Color(0xFF15342D)

// Light scheme tokens (for optional light preview/system support)
val LightBg = Color(0xFFF3FAF8)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceContainer = Color(0xFFE6F3EF)
val LightPrimary = Color(0xFF0B7D67)
val LightTextPrimary = Color(0xFF0D1D1A)
val LightTextSecondary = Color(0xFF4A635D)
