package com.mcprobe.app

import android.content.Context
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build
import java.io.File
import java.io.RandomAccessFile
import java.lang.reflect.Modifier
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.zip.ZipEntry
import java.util.zip.ZipFile

/** Collects facts about the installed Minecraft so a real in-app launch can be designed. Read-only. */
object Probe {
    private val PACKAGES = listOf(
        "com.mojang.minecraftpe.preview",
        "com.mojang.minecraftpe",
        "com.mojang.minecrafttrialpe"
    )
    private const val MAIN_LIB = "libminecraftpe.so"

    fun run(ctx: Context, log: (String) -> Unit) {
        log("=== DEVICE ===")
        log("Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}), ${Build.MANUFACTURER} ${Build.MODEL}")
        log("ABIs: ${Build.SUPPORTED_ABIS.joinToString()}")
        var any = false
        for (pkg in PACKAGES) {
            val pi = packageInfo(ctx, pkg) ?: continue
            any = true
            try {
                probePackage(ctx, pkg, pi, log)
            } catch (t: Throwable) {
                log("[ERROR] $pkg: $t")
            }
        }
        if (!any) log("[ERROR] No Minecraft package is installed (or it is not visible).")
        log("=== DONE ===")
    }

    @Suppress("DEPRECATION")
    private fun packageInfo(ctx: Context, pkg: String): PackageInfo? = try {
        val flags = PackageManager.GET_ACTIVITIES or PackageManager.GET_META_DATA or
            PackageManager.GET_SERVICES or PackageManager.GET_PERMISSIONS
        if (Build.VERSION.SDK_INT >= 33) {
            ctx.packageManager.getPackageInfo(pkg, PackageManager.PackageInfoFlags.of(flags.toLong()))
        } else {
            ctx.packageManager.getPackageInfo(pkg, flags)
        }
    } catch (e: PackageManager.NameNotFoundException) {
        null
    }

    @Suppress("DEPRECATION")
    private fun probePackage(ctx: Context, pkg: String, pi: PackageInfo, log: (String) -> Unit) {
        val ai = pi.applicationInfo ?: return
        log("")
        log("=== PACKAGE $pkg ===")
        val code = if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode else pi.versionCode.toLong()
        log("version: ${pi.versionName} (code $code)")
        log("minSdk=${ai.minSdkVersion} targetSdk=${ai.targetSdkVersion}")
        log("sourceDir: ${ai.sourceDir}")
        log("splits: ${ai.splitSourceDirs?.toList() ?: emptyList<String>()}")
        log("nativeLibraryDir: ${ai.nativeLibraryDir}")
        val nativeFiles = File(ai.nativeLibraryDir).listFiles()?.map { "${it.name} ${it.length()}" }
        log("nativeLibraryDir files: ${nativeFiles ?: "none"}")
        ai.metaData?.let { m -> for (k in m.keySet()) log("app meta: $k = ${m.get(k)}") }

        pi.activities?.forEach { a ->
            log("activity ${a.name} exported=${a.exported} launchMode=${a.launchMode} process=${a.processName}")
            a.metaData?.let { m -> for (k in m.keySet()) log("    meta: $k = ${m.get(k)}") }
        }
        pi.services?.forEach { s -> log("service ${s.name} process=${s.processName}") }
        log("permissions: ${pi.requestedPermissions?.size ?: 0}")

        val apks = listOfNotNull(ai.sourceDir) + (ai.splitSourceDirs?.toList() ?: emptyList())
        val defined = ArrayList<Pair<String, String?>>()
        for (apk in apks) defined += analyzeApk(File(apk), log)

        log("--- dex summary: ${defined.size} defined classes ---")
        defined.groupingBy { it.first.removePrefix("L").split('/').take(3).joinToString("/") }
            .eachCount().entries.sortedByDescending { it.value }.take(25)
            .forEach { log("  ${it.key}: ${it.value}") }

        val mojang = defined.filter { it.first.startsWith("Lcom/mojang/") }
        log("--- com.mojang classes: ${mojang.size} (first 100) ---")
        mojang.take(100).forEach { log("  ${it.first} extends ${it.second}") }

        reflect(ctx, pkg, mojang, log)

        val nativeMain = File(ai.nativeLibraryDir, MAIN_LIB)
        if (nativeMain.isFile) {
            log("--- ELF: $nativeMain ---")
            analyzeElf(nativeMain, log)
        } else {
            val abi = Build.SUPPORTED_ABIS.firstOrNull { a -> apks.any { hasEntry(File(it), "lib/$a/$MAIN_LIB") } }
            if (abi == null) {
                log("[WARN] $MAIN_LIB not in nativeLibraryDir and not in any APK for this device ABI")
            } else {
                val src = apks.first { hasEntry(File(it), "lib/$abi/$MAIN_LIB") }
                val tmp = File(ctx.cacheDir, "probe_$MAIN_LIB")
                try {
                    log("extracting $MAIN_LIB ($abi) from ${File(src).name} for analysis...")
                    ZipFile(src).use { z ->
                        z.getInputStream(z.getEntry("lib/$abi/$MAIN_LIB")).use { i ->
                            tmp.outputStream().use { o -> i.copyTo(o) }
                        }
                    }
                    log("--- ELF: $abi from APK (${tmp.length()} bytes) ---")
                    analyzeElf(tmp, log)
                } finally {
                    tmp.delete()
                }
            }
        }
    }

    private fun hasEntry(apk: File, name: String): Boolean =
        try { ZipFile(apk).use { it.getEntry(name) != null } } catch (_: Exception) { false }

    private fun analyzeApk(apk: File, log: (String) -> Unit): List<Pair<String, String?>> {
        val result = ArrayList<Pair<String, String?>>()
        log("--- APK ${apk.name}: ${apk.length() / 1048576} MB ---")
        try {
            ZipFile(apk).use { z ->
                var assets = 0
                val dexNames = ArrayList<ZipEntry>()
                for (e in z.entries()) {
                    val n = e.name
                    when {
                        n.startsWith("lib/") && n.endsWith(".so") ->
                            log("  lib ${n} ${e.size} ${if (e.method == ZipEntry.STORED) "stored" else "deflated"}")
                        n.matches(Regex("classes\\d*\\.dex")) -> dexNames += e
                        n.startsWith("assets/") -> assets++
                    }
                }
                log("  assets entries: $assets, dex files: ${dexNames.map { it.name }}")
                for (e in dexNames) {
                    try {
                        result += dexClasses(z.getInputStream(e).readBytes())
                    } catch (t: Throwable) {
                        log("  [WARN] dex ${e.name}: $t")
                    }
                }
            }
        } catch (t: Throwable) {
            log("  [WARN] cannot read APK: $t")
        }
        return result
    }

    /** Minimal DEX reader: returns (class descriptor, superclass descriptor) for every defined class. */
    private fun dexClasses(b: ByteArray): List<Pair<String, String?>> {
        val bb = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN)
        val strOff = bb.getInt(0x3C)
        val typeOff = bb.getInt(0x44)
        val classSize = bb.getInt(0x60)
        val classOff = bb.getInt(0x64)
        fun str(idx: Int): String {
            var p = bb.getInt(strOff + idx * 4)
            while ((b[p].toInt() and 0x80) != 0) p++
            p++
            var e = p
            while (b[e].toInt() != 0) e++
            return String(b, p, e - p, Charsets.UTF_8)
        }
        fun type(idx: Int): String = str(bb.getInt(typeOff + idx * 4))
        val out = ArrayList<Pair<String, String?>>(classSize)
        for (i in 0 until classSize) {
            val base = classOff + i * 32
            val sup = bb.getInt(base + 8)
            out += Pair(type(bb.getInt(base)), if (sup == -1) null else type(sup))
        }
        return out
    }

    private fun reflect(ctx: Context, pkg: String, mojang: List<Pair<String, String?>>, log: (String) -> Unit) {
        val cl = try {
            ctx.createPackageContext(pkg, Context.CONTEXT_INCLUDE_CODE or Context.CONTEXT_IGNORE_SECURITY).classLoader
        } catch (t: Throwable) {
            log("[WARN] createPackageContext failed: $t")
            return
        }
        log("--- reflection through the game's class loader (no class init) ---")
        var nativeLines = 0
        for ((desc, _) in mojang.take(400)) {
            val cn = desc.removePrefix("L").removeSuffix(";").replace('/', '.')
            try {
                val c = Class.forName(cn, false, cl)
                val natives = c.declaredMethods.filter { Modifier.isNative(it.modifiers) }
                if (cn.endsWith(".MainActivity")) {
                    val chain = ArrayList<String>()
                    var k: Class<*>? = c
                    while (k != null) {
                        chain += k.name
                        k = k.superclass
                    }
                    log("MainActivity chain: ${chain.joinToString(" > ")}")
                    log("MainActivity interfaces: ${c.interfaces.joinToString { it.name }}")
                    log("MainActivity declared methods: ${c.declaredMethods.size}")
                }
                if (natives.isNotEmpty()) {
                    log("$cn extends ${c.superclass?.name}")
                    for (m in natives) {
                        if (nativeLines++ < 250) {
                            log("    native ${m.returnType.simpleName} ${m.name}(${m.parameterTypes.joinToString { it.simpleName }})")
                        }
                    }
                }
            } catch (t: Throwable) {
                log("$cn: ${t.javaClass.simpleName}")
            }
        }
        log("native methods found: $nativeLines")
    }

    /** Reads only the dynamic section and its string table of a 64-bit ELF file. */
    private fun analyzeElf(f: File, log: (String) -> Unit) {
        RandomAccessFile(f, "r").use { raf ->
            val hdr = ByteArray(64)
            raf.readFully(hdr)
            if (hdr[0] != 0x7F.toByte() || hdr[1] != 'E'.code.toByte() ||
                hdr[2] != 'L'.code.toByte() || hdr[3] != 'F'.code.toByte()
            ) {
                log("  not an ELF file")
                return
            }
            if (hdr[4].toInt() != 2) {
                log("  32-bit ELF: not parsed")
                return
            }
            val h = ByteBuffer.wrap(hdr).order(ByteOrder.LITTLE_ENDIAN)
            val phoff = h.getLong(0x20)
            val phentsize = h.getShort(0x36).toInt() and 0xFFFF
            val phnum = h.getShort(0x38).toInt() and 0xFFFF
            val ph = ByteArray(phentsize * phnum)
            raf.seek(phoff)
            raf.readFully(ph)
            val pb = ByteBuffer.wrap(ph).order(ByteOrder.LITTLE_ENDIAN)
            val types = IntArray(phnum)
            val offs = LongArray(phnum)
            val vaddrs = LongArray(phnum)
            val fsz = LongArray(phnum)
            for (i in 0 until phnum) {
                val o = i * phentsize
                types[i] = pb.getInt(o)
                offs[i] = pb.getLong(o + 8)
                vaddrs[i] = pb.getLong(o + 16)
                fsz[i] = pb.getLong(o + 32)
            }
            fun toFileOffset(v: Long): Long {
                for (i in 0 until phnum) {
                    if (types[i] == 1 && v >= vaddrs[i] && v < vaddrs[i] + fsz[i]) return offs[i] + (v - vaddrs[i])
                }
                return -1L
            }
            val dynIdx = (0 until phnum).firstOrNull { types[it] == 2 }
            if (dynIdx == null) {
                log("  no dynamic section")
                return
            }
            val d = ByteArray(fsz[dynIdx].toInt())
            raf.seek(offs[dynIdx])
            raf.readFully(d)
            val db = ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN)
            var strtab = 0L
            var strsz = 0L
            var soname = -1L
            val needed = ArrayList<Long>()
            var i = 0
            while (i + 16 <= d.size) {
                val tag = db.getLong(i)
                val v = db.getLong(i + 8)
                if (tag == 0L) break
                when (tag) {
                    1L -> needed += v
                    5L -> strtab = v
                    10L -> strsz = v
                    14L -> soname = v
                }
                i += 16
            }
            val so = toFileOffset(strtab)
            if (so < 0 || strsz <= 0) {
                log("  string table not found")
                return
            }
            val str = ByteArray(minOf(strsz, 64L * 1024 * 1024).toInt())
            raf.seek(so)
            raf.readFully(str)
            fun s(off: Long): String {
                val start = off.toInt()
                var e = start
                while (e < str.size && str[e].toInt() != 0) e++
                return String(str, start, e - start, Charsets.UTF_8)
            }
            log("  SONAME: ${if (soname >= 0) s(soname) else "-"}")
            log("  NEEDED: ${needed.joinToString { s(it) }}")
            val names = ArrayList<String>()
            var st = 0
            for (k in str.indices) {
                if (str[k].toInt() == 0) {
                    if (k > st) names += String(str, st, k - st, Charsets.UTF_8)
                    st = k + 1
                }
            }
            log("  dynamic string entries: ${names.size}")
            val interesting = names.filter {
                it.startsWith("Java_") || it == "JNI_OnLoad" || it == "JNI_OnUnload" ||
                    it.contains("GameActivity") || it.startsWith("ANativeActivity")
            }
            log("  JNI related names: ${interesting.size}")
            interesting.take(200).forEach { log("    $it") }
        }
    }
}
