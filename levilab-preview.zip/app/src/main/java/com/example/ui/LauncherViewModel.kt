package com.example.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AndroidTelemetryAndCacheManager
import com.example.data.LauncherPersistedPrefs
import com.example.data.LauncherPreferencesRepository
import com.example.model.ApkInspectionResult
import com.example.model.AppLanguage
import com.example.model.CacheHealthStatus
import com.example.model.DeviceTelemetry
import com.example.model.FailureReason
import com.example.model.GameProfile
import com.example.model.InstalledPackageSplitsReport
import com.example.model.LaunchLogEntry
import com.example.model.LaunchSessionState
import com.example.model.LogLevel
import com.example.model.ModItem
import com.example.model.ModType
import com.example.model.PreflightStage
import com.example.model.PreflightStep
import com.example.model.ProfileSourceType
import com.example.model.RootCauseGuideItem
import com.example.model.StageState
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class LeviUiState(
    val isInitializing: Boolean = true,
    val language: AppLanguage = AppLanguage.AR,
    val telemetry: DeviceTelemetry? = null,
    val profiles: List<GameProfile> = emptyList(),
    val selectedProfileId: String = "bedrock_preview",
    val targetAbiOverride: String = "AUTO",
    val simulateMissingLib: Boolean = false,
    val isInspectingApk: Boolean = false,
    val apkInspectionResult: ApkInspectionResult? = null,
    val isScanningSplits: Boolean = false,
    val installedSplitsReport: InstalledPackageSplitsReport? = null,
    val mods: List<ModItem> = emptyList(),
    val launchSession: LaunchSessionState = LaunchSessionState(),
    val rootCauseGuides: List<RootCauseGuideItem> = defaultRootCauseGuides(),
    val statusBanner: String? = null
) {
    val selectedProfile: GameProfile?
        get() = profiles.firstOrNull { it.id == selectedProfileId } ?: profiles.firstOrNull()

    val effectiveTargetAbi: String
        get() = if (targetAbiOverride == "AUTO") {
            telemetry?.primaryAbi ?: "arm64-v8a"
        } else {
            targetAbiOverride
        }
}

class LauncherViewModel(application: Application) : AndroidViewModel(application) {

    private val cacheManager = AndroidTelemetryAndCacheManager(application)
    private val prefsRepo = LauncherPreferencesRepository(application)

    private val _uiState = MutableStateFlow(
        LeviUiState(mods = defaultMods())
    )
    val uiState: StateFlow<LeviUiState> = _uiState.asStateFlow()

    private var launchJob: Job? = null
    private var lastInspectedUri: Uri? = null
    private var logIdCounter = 0L
    private var latestPrefs = LauncherPersistedPrefs()

    init {
        viewModelScope.launch {
            val telemetry = cacheManager.collectDeviceTelemetry()
            val splitsReport = cacheManager.inspectInstalledMinecraftSplits()
            cacheManager.ensureDefaultPrototypeCacheInitialized(telemetry.primaryAbi)
            _uiState.update {
                it.copy(
                    telemetry = telemetry,
                    installedSplitsReport = splitsReport
                )
            }

            prefsRepo.prefsFlow.collect { prefs ->
                latestPrefs = prefs
                val updatedMods = _uiState.value.mods.map { mod ->
                    mod.copy(enabled = mod.id !in prefs.disabledModIds)
                }
                _uiState.update {
                    it.copy(
                        language = prefs.language,
                        selectedProfileId = prefs.selectedProfileId,
                        targetAbiOverride = prefs.targetAbiOverride,
                        simulateMissingLib = prefs.simulateMissingLib,
                        mods = updatedMods
                    )
                }
                refreshProfiles(telemetry, prefs.targetAbiOverride)
            }
        }
    }

    private suspend fun refreshProfiles(telemetry: DeviceTelemetry?, abiOverride: String) {
        val activeTelemetry = telemetry ?: cacheManager.collectDeviceTelemetry()
        val effectiveAbi = if (abiOverride == "AUTO") activeTelemetry.primaryAbi else abiOverride
        val previewInstalled = activeTelemetry.installedEditions.firstOrNull {
            it.packageName == "com.mojang.minecraftpe.preview"
        }
        val previewProfile = cacheManager.inspectProfileCache(
            profileId = "bedrock_preview",
            displayName = "Bedrock Preview",
            versionName = previewInstalled?.versionName ?: "Preview Latest",
            packageName = "com.mojang.minecraftpe.preview",
            targetAbi = effectiveAbi,
            deviceSupportedAbis = activeTelemetry.supportedAbis,
            sourceType = if (previewInstalled != null) ProfileSourceType.INSTALLED_PACKAGE else ProfileSourceType.INTERNAL_CACHE
        ).copy(
            isInstalledOnDevice = previewInstalled != null,
            installedVersionName = previewInstalled?.versionName
        )
        val trialInstalled = activeTelemetry.installedEditions.firstOrNull {
            it.packageName == "com.mojang.minecrafttrialpe"
        }
        val fullInstalled = activeTelemetry.installedEditions.firstOrNull {
            it.packageName == "com.mojang.minecraftpe"
        }

        val trialProfile = cacheManager.inspectProfileCache(
            profileId = "bedrock_trial_latest",
            displayName = "Bedrock Trial (Beta/Preview)",
            versionName = trialInstalled?.versionName ?: "Trial Latest",
            packageName = "com.mojang.minecrafttrialpe",
            targetAbi = effectiveAbi,
            deviceSupportedAbis = activeTelemetry.supportedAbis,
            sourceType = if (trialInstalled != null) ProfileSourceType.INSTALLED_PACKAGE else ProfileSourceType.INTERNAL_CACHE
        ).copy(
            isInstalledOnDevice = trialInstalled != null,
            installedVersionName = trialInstalled?.versionName
        )

        val profile1 = cacheManager.inspectProfileCache(
            profileId = "bedrock_1_21_51",
            displayName = "Bedrock 1.21.51 (Unlocked)",
            versionName = fullInstalled?.versionName ?: "1.21.51.02",
            packageName = "com.mojang.minecraftpe",
            targetAbi = effectiveAbi,
            deviceSupportedAbis = activeTelemetry.supportedAbis,
            sourceType = ProfileSourceType.SPLIT_APKS
        ).copy(
            isInstalledOnDevice = fullInstalled != null,
            installedVersionName = fullInstalled?.versionName
        )

        val profile2 = cacheManager.inspectProfileCache(
            profileId = "bedrock_1_21_44",
            displayName = "Bedrock 1.21.44 (Verified)",
            versionName = "1.21.44.01",
            packageName = "com.mojang.minecraftpe",
            targetAbi = effectiveAbi,
            deviceSupportedAbis = activeTelemetry.supportedAbis,
            sourceType = ProfileSourceType.INTERNAL_CACHE
        ).copy(
            isInstalledOnDevice = fullInstalled != null,
            installedVersionName = fullInstalled?.versionName
        )

        _uiState.update {
            it.copy(
                isInitializing = false,
                telemetry = activeTelemetry,
                profiles = listOf(previewProfile, trialProfile, profile1, profile2)
            )
        }
    }

    fun selectProfile(profileId: String) {
        viewModelScope.launch {
            prefsRepo.setSelectedProfile(profileId)
        }
    }

    fun setTargetAbiOverride(abi: String) {
        viewModelScope.launch {
            prefsRepo.setTargetAbiOverride(abi)
        }
    }

    fun setLanguage(language: AppLanguage) {
        viewModelScope.launch {
            prefsRepo.setLanguage(language)
        }
    }

    fun setSimulateMissingLib(enabled: Boolean) {
        viewModelScope.launch {
            prefsRepo.setSimulateMissingLib(enabled)
        }
    }

    fun inspectArchive(uri: Uri) {
        viewModelScope.launch {
            lastInspectedUri = uri
            _uiState.update { it.copy(isInspectingApk = true) }
            val abis = _uiState.value.telemetry?.supportedAbis ?: listOf("arm64-v8a")
            val result = cacheManager.inspectArchiveUri(uri, abis)
            _uiState.update {
                it.copy(
                    isInspectingApk = false,
                    apkInspectionResult = result
                )
            }
        }
    }

    fun refreshInstalledSplits() {
        viewModelScope.launch {
            _uiState.update { it.copy(isScanningSplits = true) }
            val telemetry = cacheManager.collectDeviceTelemetry()
            val splitsReport = cacheManager.inspectInstalledMinecraftSplits()
            _uiState.update {
                it.copy(
                    isScanningSplits = false,
                    telemetry = telemetry,
                    installedSplitsReport = splitsReport
                )
            }
        }
    }

    fun applyInspectedArchiveToCache() {
        val state = _uiState.value
        val profile = state.selectedProfile ?: return
        val inspection = state.apkInspectionResult ?: return
        val matchingLib = inspection.foundNativeLibs.firstOrNull {
            it.abi == state.effectiveTargetAbi
        } ?: inspection.foundNativeLibs.firstOrNull {
            it.abi in (state.telemetry?.supportedAbis ?: emptyList())
        }

        viewModelScope.launch {
            if (matchingLib != null) {
                val ok = cacheManager.repairProfileCache(profile.id, matchingLib.abi, lastInspectedUri, profile.packageName)
                if (ok && matchingLib.abi != state.effectiveTargetAbi) {
                    prefsRepo.setTargetAbiOverride(matchingLib.abi)
                }
                if (ok) prefsRepo.setSimulateMissingLib(false)
                refreshProfiles(state.telemetry, latestPrefs.targetAbiOverride)
                _uiState.update {
                    it.copy(
                        statusBanner = if (!ok) {
                            if (state.language == AppLanguage.AR) {
                                "فشل استخراج libminecraftpe.so الحقيقي من هذا الملف."
                            } else {
                                "Could not extract a real libminecraftpe.so from this file."
                            }
                        } else if (state.language == AppLanguage.AR) {
                            "تمت مزامنة ${matchingLib.abi}/libminecraftpe.so الحقيقي إلى ذاكرة التخزين المؤقت."
                        } else {
                            "Synced ${matchingLib.abi}/libminecraftpe.so into library cache."
                        }
                    )
                }
            }
        }
    }

    fun repairSelectedProfileCache() {
        val state = _uiState.value
        val profile = state.selectedProfile ?: return
        val targetAbi = state.effectiveTargetAbi
        viewModelScope.launch {
            val ok = cacheManager.repairProfileCache(profile.id, targetAbi, lastInspectedUri, profile.packageName)
            if (ok) prefsRepo.setSimulateMissingLib(false)
            refreshProfiles(state.telemetry, state.targetAbiOverride)
            _uiState.update {
                it.copy(
                    statusBanner = if (!ok) {
                        if (state.language == AppLanguage.AR) {
                            "لم أجد libminecraftpe.so حقيقي للمعمارية $targetAbi. ثبّت ماينكرافت الرسمي أو استورد ملف APK الرسمي."
                        } else {
                            "No real libminecraftpe.so found for $targetAbi. Install official Minecraft or import the official APK."
                        }
                    } else if (state.language == AppLanguage.AR) {
                        "تم استخراج المكتبة الحقيقية للمعمارية $targetAbi."
                    } else {
                        "Repaired library cache for $targetAbi."
                    }
                )
            }
        }
    }

    fun clearSelectedProfileCache() {
        val state = _uiState.value
        val profile = state.selectedProfile ?: return
        val targetAbi = state.effectiveTargetAbi
        viewModelScope.launch {
            cacheManager.clearProfileCacheForAbi(profile.id, targetAbi)
            refreshProfiles(state.telemetry, state.targetAbiOverride)
            _uiState.update {
                it.copy(
                    statusBanner = if (state.language == AppLanguage.AR) {
                        "تم مسح libminecraftpe.so من كاش $targetAbi لاختبار التشخيص."
                    } else {
                        "Cleared $targetAbi cache to reproduce missing library error."
                    }
                )
            }
        }
    }

    fun toggleMod(modId: String) {
        viewModelScope.launch {
            val currentMods = _uiState.value.mods
            val updated = currentMods.map {
                if (it.id == modId) it.copy(enabled = !it.enabled) else it
            }
            _uiState.update { it.copy(mods = updated) }
            val disabledIds = updated.filter { !it.enabled }.map { it.id }.toSet()
            prefsRepo.setDisabledModIds(disabledIds)
        }
    }

    fun moveModOrder(modId: String, delta: Int) {
        val sorted = _uiState.value.mods.sortedBy { it.loadOrder }.toMutableList()
        val index = sorted.indexOfFirst { it.id == modId }
        if (index == -1) return
        val targetIndex = (index + delta).coerceIn(0, sorted.lastIndex)
        if (index == targetIndex) return
        val item = sorted.removeAt(index)
        sorted.add(targetIndex, item)
        val reindexed = sorted.mapIndexed { idx, mod -> mod.copy(loadOrder = idx + 1) }
        _uiState.update { it.copy(mods = reindexed) }
    }

    fun addCustomMod(name: String, abi: String, type: ModType) {
        val trimmed = name.trim()
        if (trimmed.isEmpty()) return
        val current = _uiState.value.mods
        val nextOrder = (current.maxOfOrNull { it.loadOrder } ?: 0) + 1
        val newMod = ModItem(
            id = "custom_${System.currentTimeMillis()}",
            name = trimmed,
            author = "Local Prototype",
            version = "1.0.0",
            type = type,
            requiredAbi = abi,
            enabled = true,
            loadOrder = nextOrder,
            descriptionEn = "User-added prototype test module ($abi)",
            descriptionAr = "وحدة تجريبية مضافة من المستخدم ($abi)"
        )
        _uiState.update { it.copy(mods = current + newMod) }
    }

    fun dismissStatusBanner() {
        _uiState.update { it.copy(statusBanner = null) }
    }

    fun startLaunchPreflight() {
        launchJob?.cancel()
        launchJob = viewModelScope.launch {
            val startTime = System.currentTimeMillis()
            val state = _uiState.value
            val telemetry = state.telemetry ?: cacheManager.collectDeviceTelemetry()
            val profile = state.selectedProfile
            val targetAbi = state.effectiveTargetAbi
            val enabledMods = state.mods.filter { it.enabled }.sortedBy { it.loadOrder }

            val initialSteps = PreflightStage.entries.map {
                PreflightStep(stage = it, state = StageState.PENDING)
            }
            val logs = mutableListOf<LaunchLogEntry>()

            fun appendLog(level: LogLevel, msg: String) {
                logs.add(
                    LaunchLogEntry(
                        id = ++logIdCounter,
                        timestamp = currentTimeTag(),
                        level = level,
                        message = msg
                    )
                )
            }

            val targetPackageName = profile?.packageName ?: "com.mojang.minecrafttrialpe"

            fun updateSession(
                isRunning: Boolean = true,
                progress: Float,
                steps: List<PreflightStep>,
                failedReason: FailureReason? = null,
                succeeded: Boolean = false,
                launchedPackageName: String? = null,
                targetPackageMissingOnDevice: Boolean = false
            ) {
                _uiState.update {
                    it.copy(
                        launchSession = LaunchSessionState(
                            isRunning = isRunning,
                            progress = progress,
                            steps = steps,
                            logs = logs.toList(),
                            failedReason = failedReason,
                            succeeded = succeeded,
                            elapsedMs = System.currentTimeMillis() - startTime,
                            targetPackageName = targetPackageName,
                            launchedPackageName = launchedPackageName,
                            targetPackageMissingOnDevice = targetPackageMissingOnDevice
                        )
                    )
                }
            }

            val workingSteps = initialSteps.toMutableList()
            appendLog(LogLevel.INFO, "Starting LeviLab preflight for ${profile?.displayName ?: "Bedrock Trial"}")
            updateSession(progress = 0.08f, steps = workingSteps)

            // Stage 1: Package & Profile Check
            workingSteps[0] = workingSteps[0].copy(state = StageState.RUNNING)
            updateSession(progress = 0.16f, steps = workingSteps)
            delay(260)
            val pkgInstalled = telemetry.installedEditions.firstOrNull {
                it.packageName == targetPackageName
            }
            if (pkgInstalled != null) {
                appendLog(
                    LogLevel.INFO,
                    "Detected installed package: ${pkgInstalled.packageName} (v${pkgInstalled.versionName})"
                )
            } else {
                appendLog(
                    LogLevel.WARN,
                    "$targetPackageName not installed on device; validating local library cache"
                )
            }
            workingSteps[0] = workingSteps[0].copy(
                state = StageState.PASSED,
                detail = pkgInstalled?.versionName ?: profile?.versionName.orEmpty()
            )
            updateSession(progress = 0.25f, steps = workingSteps)

            // Stage 2: ABI Compatibility
            workingSteps[1] = workingSteps[1].copy(state = StageState.RUNNING)
            updateSession(progress = 0.35f, steps = workingSteps)
            delay(260)
            val abiSupported = targetAbi in telemetry.supportedAbis
            appendLog(
                LogLevel.INFO,
                "Device ABIs: [${telemetry.supportedAbis.joinToString()}] | Target ABI: $targetAbi"
            )
            if (!abiSupported) {
                appendLog(LogLevel.ERROR, "Launch failed")
                appendLog(
                    LogLevel.ERROR,
                    "Target ABI '$targetAbi' is unsupported on ${telemetry.deviceModel}"
                )
                workingSteps[1] = workingSteps[1].copy(state = StageState.FAILED, detail = targetAbi)
                updateSession(
                    isRunning = false,
                    progress = 0.4f,
                    steps = workingSteps,
                    failedReason = FailureReason.AbiMismatch(telemetry.primaryAbi, targetAbi)
                )
                return@launch
            }
            workingSteps[1] = workingSteps[1].copy(state = StageState.PASSED, detail = targetAbi)
            updateSession(progress = 0.45f, steps = workingSteps)

            // Stage 3: Native Library Cache Check (Reproduces / Fixes the exact screenshot error!)
            workingSteps[2] = workingSteps[2].copy(state = StageState.RUNNING)
            updateSession(progress = 0.56f, steps = workingSteps)
            delay(320)

            val refreshedProfile = if (profile != null) {
                cacheManager.inspectProfileCache(
                    profileId = profile.id,
                    displayName = profile.displayName,
                    versionName = profile.versionName,
                    packageName = profile.packageName,
                    targetAbi = targetAbi,
                    deviceSupportedAbis = telemetry.supportedAbis,
                    sourceType = profile.sourceType
                )
            } else null

            val missingLib = state.simulateMissingLib ||
                refreshedProfile == null ||
                refreshedProfile.cacheStatus != CacheHealthStatus.VERIFIED

            if (missingLib) {
                val expectedPath = refreshedProfile?.cachePath
                    ?: "files/minecraft_library_cache/$targetAbi/libminecraftpe.so"
                val availableAbis = refreshedProfile?.availableCachedAbis.orEmpty()

                appendLog(LogLevel.ERROR, "Launch failed")
                appendLog(LogLevel.ERROR, "libminecraftpe.so not found in the Minecraft library cache")
                appendLog(LogLevel.WARN, "Expected cache file: $expectedPath")
                if (availableAbis.isNotEmpty()) {
                    appendLog(
                        LogLevel.WARN,
                        "Found cached ABIs [${availableAbis.joinToString()}], but target is $targetAbi (Split-APK mismatch)"
                    )
                } else {
                    appendLog(
                        LogLevel.WARN,
                        "Library cache directory for $targetAbi is empty. Import a full APK/APKS or run Auto-Repair."
                    )
                }

                workingSteps[2] = workingSteps[2].copy(state = StageState.FAILED, detail = "Missing .so")
                updateSession(
                    isRunning = false,
                    progress = 0.60f,
                    steps = workingSteps,
                    failedReason = FailureReason.MissingMinecraftPeLib(
                        expectedPath = expectedPath,
                        expectedAbi = targetAbi,
                        availableAbisInCache = availableAbis,
                        splitHint = availableAbis.isNotEmpty() || state.apkInspectionResult?.isSplitArchive == true
                    )
                )
                return@launch
            }

            appendLog(
                LogLevel.SUCCESS,
                "Verified libminecraftpe.so (${refreshedProfile.cachedLibSizeBytes} B, sha256:${refreshedProfile.cachedLibSha256}) at $targetAbi cache"
            )
            workingSteps[2] = workingSteps[2].copy(state = StageState.PASSED, detail = "Verified")
            updateSession(progress = 0.72f, steps = workingSteps)

            // Stage 4: Mod Validation
            workingSteps[3] = workingSteps[3].copy(state = StageState.RUNNING)
            updateSession(progress = 0.82f, steps = workingSteps)
            delay(280)
            val conflictingMods = enabledMods.filter {
                it.requiredAbi != "universal" && it.requiredAbi != targetAbi
            }
            if (conflictingMods.isNotEmpty()) {
                appendLog(LogLevel.ERROR, "Launch failed")
                appendLog(
                    LogLevel.ERROR,
                    "Mod ABI conflict: ${conflictingMods.joinToString { "${it.name} (${it.requiredAbi})" }} incompatible with $targetAbi"
                )
                workingSteps[3] = workingSteps[3].copy(state = StageState.FAILED, detail = "ABI Conflict")
                updateSession(
                    isRunning = false,
                    progress = 0.85f,
                    steps = workingSteps,
                    failedReason = FailureReason.ModConflict(
                        conflictingMods = conflictingMods.map { it.name },
                        targetAbi = targetAbi
                    )
                )
                return@launch
            }
            appendLog(LogLevel.INFO, "Validated ${enabledMods.size} enabled mods for $targetAbi")
            workingSteps[3] = workingSteps[3].copy(state = StageState.PASSED, detail = "${enabledMods.size} mods")
            updateSession(progress = 0.90f, steps = workingSteps)

            // Stage 5: Launch Environment Handoff
            workingSteps[4] = workingSteps[4].copy(state = StageState.RUNNING)
            updateSession(progress = 0.95f, steps = workingSteps)
            delay(260)

            val launchIntent = cacheManager.createLaunchIntent(targetPackageName)
            if (launchIntent != null) {
                val launched = openGamePackage(targetPackageName)
                if (launched) {
                    appendLog(LogLevel.SUCCESS, "Handing off launch to $targetPackageName...")
                } else {
                    appendLog(LogLevel.WARN, "Launch intent ready for $targetPackageName; tap Open Game Now.")
                }
                workingSteps[4] = workingSteps[4].copy(state = StageState.PASSED, detail = "Launched")
                updateSession(
                    isRunning = false,
                    progress = 1.0f,
                    steps = workingSteps,
                    succeeded = true,
                    launchedPackageName = targetPackageName,
                    targetPackageMissingOnDevice = false
                )
            } else {
                appendLog(
                    LogLevel.WARN,
                    "Preflight verified! $targetPackageName is not installed on this device yet."
                )
                workingSteps[4] = workingSteps[4].copy(state = StageState.PASSED, detail = "Install Needed")
                updateSession(
                    isRunning = false,
                    progress = 1.0f,
                    steps = workingSteps,
                    succeeded = true,
                    launchedPackageName = null,
                    targetPackageMissingOnDevice = true
                )
            }
        }
    }

    fun openGamePackage(packageName: String): Boolean {
        val intent = cacheManager.createLaunchIntent(packageName) ?: return false
        return try {
            getApplication<Application>().startActivity(intent)
            true
        } catch (_: Exception) {
            false
        }
    }

    fun openPlayStoreForPackage(packageName: String) {
        val intent = cacheManager.createStoreIntent(packageName)
        try {
            getApplication<Application>().startActivity(intent)
        } catch (_: Exception) {
            _uiState.update {
                it.copy(statusBanner = "Unable to open Google Play Store on this device.")
            }
        }
    }

    fun repairCacheAndRetryLaunch() {
        val state = _uiState.value
        val profile = state.selectedProfile ?: return
        val targetAbi = state.effectiveTargetAbi
        viewModelScope.launch {
            val ok = cacheManager.repairProfileCache(profile.id, targetAbi, lastInspectedUri, profile.packageName)
            if (ok) prefsRepo.setSimulateMissingLib(false)
            refreshProfiles(state.telemetry, state.targetAbiOverride)
            startLaunchPreflight()
        }
    }

    private fun currentTimeTag(): String {
        val sdf = SimpleDateFormat("HH:mm:ss", Locale.US)
        return sdf.format(Date())
    }
}

private fun defaultMods(): List<ModItem> = listOf(
    ModItem(
        id = "mod_levi_core",
        name = "LeviHook Runtime",
        author = "LeviLab Core",
        version = "2.4.1",
        type = ModType.NATIVE_SO,
        requiredAbi = "arm64-v8a",
        enabled = true,
        loadOrder = 1,
        descriptionEn = "Pre-loader bridge for native Bedrock hooks and crash symbol resolver.",
        descriptionAr = "جسر التحميل المسبق لإضافات Bedrock وحل رموز الأخطاء."
    ),
    ModItem(
        id = "mod_chunk_perf",
        name = "RenderDragon FrameBoost",
        author = "OptiBedrock",
        version = "1.8.0",
        type = ModType.NATIVE_SO,
        requiredAbi = "arm64-v8a",
        enabled = true,
        loadOrder = 2,
        descriptionEn = "Async chunk upload & shader cache warmer for smoother frame pacing.",
        descriptionAr = "تسريع تحميل الـ Chunks وتحسين ثبات الإطارات."
    ),
    ModItem(
        id = "mod_legacy_ui",
        name = "Classic HUD Pack",
        author = "CraftUI",
        version = "1.3.2",
        type = ModType.RESOURCE_PACK,
        requiredAbi = "universal",
        enabled = true,
        loadOrder = 3,
        descriptionEn = "Clean dark HUD overlay with coordinate & FPS telemetry.",
        descriptionAr = "واجهة لعب داكنة أنيقة مع عرض الإحداثيات وعداد الإطارات."
    ),
    ModItem(
        id = "mod_32bit_legacy",
        name = "Legacy Input Patch (32-bit)",
        author = "OldArch",
        version = "0.9.4",
        type = ModType.NATIVE_SO,
        requiredAbi = "armeabi-v7a",
        enabled = false,
        loadOrder = 4,
        descriptionEn = "Older 32-bit native library; enabling on arm64-v8a triggers preflight conflict detection.",
        descriptionAr = "مكتبة 32-بت قديمة؛ تفعيلها على جهاز 64-بت يفعّل تحذير تعارض المعمارية."
    )
)

private fun defaultRootCauseGuides(): List<RootCauseGuideItem> = listOf(
    RootCauseGuideItem(
        id = "split_apk",
        titleEn = "Split APK Missing Native Library Split",
        titleAr = "ملف Split APK ينقصه حزمة المعمارية",
        symptomEn = "Installed or imported only base.apk without split_config.arm64_v8a.apk.",
        symptomAr = "تم تثبيت أو استيراد base.apk فقط بدون ملف split_config.arm64_v8a.apk.",
        solutionEn = "Use a full .apks/.xapk bundle or import the matching ABI split via the APK Inspector.",
        solutionAr = "استخدم حزمة .apks/.xapk كاملة أو افحصها عبر فاحص الحزم للتأكد من وجود libminecraftpe.so.",
        severityTag = "CRITICAL"
    ),
    RootCauseGuideItem(
        id = "abi_mismatch",
        titleEn = "32-bit vs 64-bit ABI Mismatch",
        titleAr = "تعارض معمارية 32-بت مقابل 64-بت",
        symptomEn = "Cache holds armeabi-v7a while the device runs arm64-v8a-only (Android 14+).",
        symptomAr = "الذاكرة المؤقتة تحتوي على armeabi-v7a بينما الجهاز يعمل بمعمارية arm64-v8a فقط.",
        solutionEn = "Align Target ABI to device primary ABI or acquire the arm64-v8a game build.",
        solutionAr = "طابق المعمارية المستهدفة مع معمارية جهازك أو وفّر نسخة arm64-v8a من اللعبة.",
        severityTag = "HIGH"
    ),
    RootCauseGuideItem(
        id = "unextracted_cache",
        titleEn = "Unextracted or Wiped Library Cache",
        titleAr = "ذاكرة المكتبات غير مستخرجة أو ممسوحة",
        symptomEn = "Launcher checks files/library_cache before extracting libminecraftpe.so from APK.",
        symptomAr = "المشغّل يبحث داخل مجلد الكاش قبل استخراج مكتبة libminecraftpe.so أو بعد مسح البيانات.",
        solutionEn = "Run preflight auto-repair to rebuild the cache index before invoking native launch.",
        solutionAr = "شغّل الإصلاح التلقائي لإعادة فهرسة واستخراج المكتبة قبل بدء التشغيل.",
        severityTag = "FIXABLE"
    ),
    RootCauseGuideItem(
        id = "stale_update",
        titleEn = "Stale Cache Index After Game Update",
        titleAr = "فهرس كاش قديم بعد تحديث اللعبة",
        symptomEn = "Minecraft updated via Play Store, invalidating previous nativeLibraryDir path.",
        symptomAr = "تم تحديث اللعبة فتغيّر مسار nativeLibraryDir وبقي المشغّل يبحث في المسار القديم.",
        solutionEn = "Re-query PackageManager nativeLibraryDir and verify SHA-256 on every launch.",
        solutionAr = "أعد فحص PackageManager والتحقق من مسار المكتبة وتجزئة SHA-256 عند كل تشغيل.",
        severityTag = "MEDIUM"
    )
)
