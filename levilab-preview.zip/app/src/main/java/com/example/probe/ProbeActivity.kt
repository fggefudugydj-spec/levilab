package com.example.probe

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File

class ProbeActivity : Activity() {
    private lateinit var out: TextView
    private lateinit var scroll: ScrollView
    private lateinit var runBtn: Button
    private val lines = ArrayList<String>()
    private val logFile by lazy { File(filesDir, "probe.log") }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        runBtn = Button(this).apply { text = "Run probe"; setOnClickListener { runProbe() } }
        val copyBtn = Button(this).apply { text = "Copy log"; setOnClickListener { copyLog() } }
        val shareBtn = Button(this).apply { text = "Share log"; setOnClickListener { shareLog() } }
        out = TextView(this).apply {
            textSize = 11f
            typeface = Typeface.MONOSPACE
            setTextIsSelectable(true)
            text = "Press Run probe. Minecraft Preview (or Release) must be installed."
        }
        scroll = ScrollView(this).apply { addView(out) }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 56, 24, 24)
            addView(runBtn)
            addView(copyBtn)
            addView(shareBtn)
            addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        })
    }

    private fun add(line: String) {
        synchronized(lines) { lines.add(line) }
        try { logFile.appendText(line + "\n") } catch (_: Exception) { }
        runOnUiThread {
            out.text = synchronized(lines) { lines.takeLast(150).joinToString("\n") }
            scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
        }
    }

    private fun runProbe() {
        synchronized(lines) { lines.clear() }
        logFile.delete()
        runBtn.isEnabled = false
        Thread {
            try {
                Probe.run(this) { add(it) }
            } catch (t: Throwable) {
                add("[FATAL] $t")
            }
            runOnUiThread { runBtn.isEnabled = true }
        }.start()
    }

    private fun fullLog(): String = if (logFile.isFile) logFile.readText().take(300_000) else ""

    private fun copyLog() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("probe log", fullLog()))
        out.append("\n[copied to clipboard]")
    }

    private fun shareLog() {
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, fullLog())
        }, "Share log"))
    }
}
