package com.example

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import androidx.test.core.app.ApplicationProvider
import com.example.data.AndroidTelemetryAndCacheManager
import com.example.model.CacheHealthStatus
import com.example.model.ProfileSourceType
import com.example.model.SplitCategory
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read app name string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("LeviLab", appName)
    }

    @Test
    fun `repair extracts a real library and rejects fake placeholders`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val manager = AndroidTelemetryAndCacheManager(context)

        // Fake placeholder (text file) must never count as a verified library.
        val fakeDir = File(context.filesDir, "minecraft_library_cache/p1/arm64-v8a").apply { mkdirs() }
        File(fakeDir, "libminecraftpe.so").writeText("not a real library")
        manager.ensureDefaultPrototypeCacheInitialized("arm64-v8a")
        val before = manager.inspectProfileCache(
            "p1", "P1", "1.0", "com.mojang.minecraftpe", "arm64-v8a",
            listOf("arm64-v8a"), ProfileSourceType.APK_IMPORT
        )
        assertEquals(CacheHealthStatus.MISSING_LIB, before.cacheStatus)

        // Build a zip containing a valid ELF-like library (> 1 MB) and repair from it.
        val zip = File(context.cacheDir, "test.apk")
        java.util.zip.ZipOutputStream(zip.outputStream()).use { z ->
            z.putNextEntry(java.util.zip.ZipEntry("lib/arm64-v8a/libminecraftpe.so"))
            val data = ByteArray(1_200_000)
            data[0] = 0x7F; data[1] = 'E'.code.toByte(); data[2] = 'L'.code.toByte(); data[3] = 'F'.code.toByte()
            z.write(data)
            z.closeEntry()
        }
        val ok = manager.repairProfileCache("p1", "arm64-v8a", android.net.Uri.fromFile(zip))
        assertTrue(ok)
        val after = manager.inspectProfileCache(
            "p1", "P1", "1.0", "com.mojang.minecraftpe", "arm64-v8a",
            listOf("arm64-v8a"), ProfileSourceType.APK_IMPORT
        )
        assertEquals(CacheHealthStatus.VERIFIED, after.cacheStatus)
    }

    @Test
    fun `split inspector classifies resource and language splits and sums disk usage`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val manager = AndroidTelemetryAndCacheManager(context)

        assertEquals(SplitCategory.RESOURCE_DENSITY, manager.classifySplitApkName("split_config.xxhdpi"))
        assertEquals(SplitCategory.LANGUAGE, manager.classifySplitApkName("split_config.ar"))
        assertEquals(SplitCategory.LANGUAGE, manager.classifySplitApkName("config.pt_rBR"))
        assertEquals(SplitCategory.NATIVE_ABI, manager.classifySplitApkName("split_config.arm64_v8a"))

        val tempDir = File(context.cacheDir, "test_splits").apply { mkdirs() }
        val baseFile = File(tempDir, "base.apk").apply { writeBytes(ByteArray(1024)) }
        val resFile = File(tempDir, "split_config.xxhdpi.apk").apply { writeBytes(ByteArray(2048)) }
        val langFile = File(tempDir, "split_config.ar.apk").apply { writeBytes(ByteArray(512)) }
        val abiFile = File(tempDir, "split_config.arm64_v8a.apk").apply { writeBytes(ByteArray(4096)) }

        val pkgInfo = PackageInfo().apply {
            packageName = "com.mojang.minecraftpe"
            versionName = "1.21.51.02"
            applicationInfo = ApplicationInfo().apply {
                packageName = "com.mojang.minecraftpe"
                sourceDir = baseFile.absolutePath
                splitNames = arrayOf("config.xxhdpi", "config.ar", "config.arm64_v8a")
                splitSourceDirs = arrayOf(
                    resFile.absolutePath,
                    langFile.absolutePath,
                    abiFile.absolutePath
                )
            }
        }
        shadowOf(context.packageManager).installPackage(pkgInfo)

        val report = manager.inspectInstalledMinecraftSplits()
        assertTrue(report.isInstalled)
        assertEquals(3, report.splitFragments.size)
        assertEquals(2, report.resourceAndLanguageSplits.size)
        assertEquals(2048L + 512L, report.resourceAndLanguageTotalBytes)
        assertEquals(1024L + 2048L + 512L + 4096L, report.totalPackageDiskBytes)
    }

    @Test
    fun `telemetry detects installed bedrock trial and creates store intent`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val manager = AndroidTelemetryAndCacheManager(context)

        val trialPkg = PackageInfo().apply {
            packageName = "com.mojang.minecrafttrialpe"
            versionName = "1.21.60.21"
            applicationInfo = ApplicationInfo().apply {
                packageName = "com.mojang.minecrafttrialpe"
                sourceDir = "/data/app/trial/base.apk"
            }
        }
        shadowOf(context.packageManager).installPackage(trialPkg)

        val telemetry = manager.collectDeviceTelemetry()
        assertTrue(telemetry.installedEditions.any { it.packageName == "com.mojang.minecrafttrialpe" })
        assertEquals("1.21.60.21", telemetry.installedMinecraftPackage?.versionName)

        val storeIntent = manager.createStoreIntent("com.mojang.minecrafttrialpe")
        assertEquals(
            "https://play.google.com/store/apps/details?id=com.mojang.minecrafttrialpe",
            storeIntent.dataString
        )
    }
}
