package com.example.data

import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import com.example.model.ApkInspectionResult
import com.example.model.CacheHealthStatus
import com.example.model.DeviceTelemetry
import com.example.model.GameProfile
import com.example.model.InstalledMinecraftInfo
import com.example.model.InstalledPackageSplitsReport
import com.example.model.InstalledSplitFragment
import com.example.model.NativeLibEntry
import com.example.model.ProfileSourceType
import com.example.model.SplitCategory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.File
import java.io.InputStream
import java.security.MessageDigest
import java.util.zip.ZipInputStream

class AndroidTelemetryAndCacheManager(private val context: Context) {

    private companion object {
        const val MIN_LIB_BYTES = 1_000_000L
    }

    private val cacheRootDir: File
        get() = File(context.filesDir, "minecraft_library_cache").apply {
            if (!exists()) mkdirs()
        }

    suspend fun collectDeviceTelemetry(): DeviceTelemetry = withContext(Dispatchers.IO) {
        val supportedAbis = Build.SUPPORTED_ABIS?.toList().orEmpty().ifEmpty { listOf("arm64-v8a") }
        val primaryAbi = supportedAbis.firstOrNull() ?: "arm64-v8a"
        val installedInfo = queryInstalledMinecraftPackage()
        DeviceTelemetry(
            deviceModel = "${Build.MANUFACTURER.replaceFirstChar { it.uppercase() }} ${Build.MODEL}",
            androidVersion = Build.VERSION.RELEASE ?: "14",
            sdkInt = Build.VERSION.SDK_INT,
            supportedAbis = supportedAbis,
            primaryAbi = primaryAbi,
            installedMinecraftPackage = installedInfo
        )
    }

    @Suppress("DEPRECATION")
    suspend fun inspectInstalledMinecraftSplits(): InstalledPackageSplitsReport =
        withContext(Dispatchers.IO) {
            val candidates = listOf("com.mojang.minecraftpe", "com.mojang.minecrafttrialpe")
            val pm = context.packageManager
            for (pkg in candidates) {
                try {
                    val pkgInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        pm.getPackageInfo(pkg, PackageManager.PackageInfoFlags.of(0))
                    } else {
                        pm.getPackageInfo(pkg, 0)
                    }
                    val appInfo = pkgInfo.applicationInfo ?: continue
                    val basePath = appInfo.sourceDir.orEmpty()
                    val baseSize = if (basePath.isNotEmpty()) {
                        File(basePath).takeIf { it.exists() }?.length() ?: 0L
                    } else 0L

                    val splitNames = appInfo.splitNames?.toList().orEmpty()
                    val splitDirs = appInfo.splitSourceDirs?.toList().orEmpty()

                    val fragments = splitNames.mapIndexed { index, rawName ->
                        val path = splitDirs.getOrNull(index).orEmpty()
                        val file = if (path.isNotEmpty()) File(path) else null
                        val exists = file?.exists() == true
                        val size = if (exists) file?.length() ?: 0L else 0L
                        InstalledSplitFragment(
                            splitName = rawName,
                            category = classifySplitApkName(rawName),
                            sourcePath = path,
                            sizeBytes = size,
                            existsOnDisk = exists
                        )
                    }

                    // Also handle cases where splitSourceDirs exists even if splitNames was shorter
                    val extraFragments = if (splitDirs.size > splitNames.size) {
                        splitDirs.drop(splitNames.size).map { path ->
                            val file = File(path)
                            val inferredName = file.nameWithoutExtension
                            val exists = file.exists()
                            InstalledSplitFragment(
                                splitName = inferredName,
                                category = classifySplitApkName(inferredName),
                                sourcePath = path,
                                sizeBytes = if (exists) file.length() else 0L,
                                existsOnDisk = exists
                            )
                        }
                    } else emptyList()

                    val allSplits = fragments + extraFragments
                    val resAndLang = allSplits.filter {
                        it.category == SplitCategory.RESOURCE_DENSITY || it.category == SplitCategory.LANGUAGE
                    }
                    val resAndLangTotal = resAndLang.sumOf { it.sizeBytes }
                    val totalDisk = baseSize + allSplits.sumOf { it.sizeBytes }

                    return@withContext InstalledPackageSplitsReport(
                        packageName = pkg,
                        versionName = pkgInfo.versionName ?: "Unknown",
                        isInstalled = true,
                        baseApkPath = basePath,
                        baseApkSizeBytes = baseSize,
                        splitFragments = allSplits,
                        resourceAndLanguageSplits = resAndLang,
                        resourceAndLanguageTotalBytes = resAndLangTotal,
                        totalPackageDiskBytes = totalDisk
                    )
                } catch (_: PackageManager.NameNotFoundException) {
                    // Check next candidate
                } catch (_: Exception) {
                    // Continue safely
                }
            }

            InstalledPackageSplitsReport(
                packageName = "com.mojang.minecraftpe",
                versionName = "",
                isInstalled = false,
                baseApkPath = "",
                baseApkSizeBytes = 0L,
                splitFragments = emptyList(),
                resourceAndLanguageSplits = emptyList(),
                resourceAndLanguageTotalBytes = 0L,
                totalPackageDiskBytes = 0L
            )
        }

    fun classifySplitApkName(splitName: String): SplitCategory {
        val normalized = splitName
            .lowercase()
            .removeSuffix(".apk")
            .removePrefix("split_")

        if (normalized == "base") return SplitCategory.BASE_APK

        val configSuffix = when {
            normalized.startsWith("config.") -> normalized.removePrefix("config.")
            normalized.contains(".config.") -> normalized.substringAfterLast(".config.")
            else -> return SplitCategory.FEATURE_MODULE
        }

        return when {
            configSuffix in setOf(
                "arm64_v8a", "armeabi_v7a", "armeabi", "x86", "x86_64", "mips", "mips64"
            ) -> SplitCategory.NATIVE_ABI

            configSuffix in setOf(
                "ldpi", "mdpi", "tvdpi", "hdpi", "xhdpi", "xxhdpi", "xxxhdpi", "anydpi", "nodpi"
            ) -> SplitCategory.RESOURCE_DENSITY

            isLanguageSplitToken(configSuffix) -> SplitCategory.LANGUAGE

            else -> SplitCategory.OTHER
        }
    }

    private fun isLanguageSplitToken(token: String): Boolean {
        // Matches BCP-47 / Android resource locale split names like:
        // en, ar, es, fr, de, ja, ko, zh, pt_rbr, zh_rcn, b+sr+latn, etc.
        if (token.matches(Regex("^[a-z]{2,3}$"))) return true
        if (token.matches(Regex("^[a-z]{2,3}[_-]r?[a-z]{2,4}$"))) return true
        if (token.startsWith("b+")) return true
        return false
    }

    @Suppress("DEPRECATION")
    private fun queryInstalledMinecraftPackage(): InstalledMinecraftInfo? {
        val candidates = listOf("com.mojang.minecraftpe", "com.mojang.minecrafttrialpe")
        val pm = context.packageManager
        for (pkg in candidates) {
            try {
                val pkgInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    pm.getPackageInfo(pkg, PackageManager.PackageInfoFlags.of(0))
                } else {
                    pm.getPackageInfo(pkg, 0)
                }
                val appInfo = pkgInfo.applicationInfo ?: continue
                val nativeDir = appInfo.nativeLibraryDir.orEmpty()
                val hasNativeLib = nativeDir.isNotEmpty() &&
                    File(nativeDir, "libminecraftpe.so").exists()
                val splits = appInfo.splitNames?.toList().orEmpty()
                val versionCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    pkgInfo.longVersionCode
                } else {
                    pkgInfo.versionCode.toLong()
                }
                return InstalledMinecraftInfo(
                    packageName = pkg,
                    versionName = pkgInfo.versionName ?: "Unknown",
                    versionCode = versionCode,
                    nativeLibraryDir = nativeDir,
                    hasNativeLibInSystemDir = hasNativeLib,
                    splitNames = splits,
                    sourceDir = appInfo.sourceDir.orEmpty()
                )
            } catch (_: PackageManager.NameNotFoundException) {
                // Continue checking next candidate
            } catch (_: Exception) {
                // Safe fallback
            }
        }
        return null
    }

    /** Removes fake placeholder libraries left by older builds. Never creates fake files. */
    suspend fun ensureDefaultPrototypeCacheInitialized(primaryAbi: String) = withContext(Dispatchers.IO) {
        cacheRootDir.walkTopDown()
            .filter { it.isFile && it.name == "libminecraftpe.so" && !isElf(it) }
            .forEach { it.delete() }
    }

    /** True only for a real ELF shared library of plausible size (not a text placeholder). */
    private fun isElf(f: File): Boolean = try {
        f.isFile && f.length() > MIN_LIB_BYTES && f.inputStream().use { s ->
            val h = ByteArray(4)
            s.read(h) == 4 && h[0] == 0x7F.toByte() && h[1] == 'E'.code.toByte() &&
                h[2] == 'L'.code.toByte() && h[3] == 'F'.code.toByte()
        }
    } catch (_: Exception) {
        false
    }

    private fun sha256ShortOfFile(f: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        f.inputStream().use { s ->
            val buf = ByteArray(65536)
            while (true) {
                val n = s.read(buf)
                if (n < 0) break
                md.update(buf, 0, n)
            }
        }
        return md.digest().take(6).joinToString("") { "%02x".format(it) }
    }

    suspend fun inspectProfileCache(
        profileId: String,
        displayName: String,
        versionName: String,
        packageName: String,
        targetAbi: String,
        deviceSupportedAbis: List<String>,
        sourceType: ProfileSourceType
    ): GameProfile = withContext(Dispatchers.IO) {
        val profileDir = File(cacheRootDir, profileId)
        val availableAbis = profileDir.listFiles()
            ?.filter { it.isDirectory && isElf(File(it, "libminecraftpe.so")) }
            ?.map { it.name }
            ?.sorted()
            .orEmpty()

        val targetLibFile = File(File(profileDir, targetAbi), "libminecraftpe.so")
        val targetExists = isElf(targetLibFile)

        val status = when {
            targetExists && deviceSupportedAbis.contains(targetAbi) -> CacheHealthStatus.VERIFIED
            targetExists && !deviceSupportedAbis.contains(targetAbi) -> CacheHealthStatus.ABI_MISMATCH
            availableAbis.isNotEmpty() && !targetExists -> CacheHealthStatus.ABI_MISMATCH
            else -> CacheHealthStatus.MISSING_LIB
        }

        val sha256 = if (targetExists) sha256ShortOfFile(targetLibFile) else "—"

        GameProfile(
            id = profileId,
            displayName = displayName,
            versionName = versionName,
            packageName = packageName,
            targetAbi = targetAbi,
            cacheStatus = status,
            cachePath = targetLibFile.absolutePath,
            cachedLibSizeBytes = if (targetExists) targetLibFile.length() else 0L,
            cachedLibSha256 = sha256,
            sourceType = sourceType,
            availableCachedAbis = availableAbis
        )
    }

    /**
     * Real repair: extracts the genuine native libraries for [targetAbi].
     * Sources, in order: the given archive (apk/apks/xapk/zip), the installed Minecraft
     * APKs (base + splits), the installed app's native library dir.
     * Returns true only if a valid ELF libminecraftpe.so ends up in the cache.
     */
    suspend fun repairProfileCache(
        profileId: String,
        targetAbi: String,
        archiveUri: Uri? = null
    ): Boolean = withContext(Dispatchers.IO) {
        val outDir = File(cacheRootDir, "$profileId/$targetAbi").apply { mkdirs() }
        val mainLib = File(outDir, "libminecraftpe.so")
        val temps = mutableListOf<File>()
        try {
            if (archiveUri != null) {
                val tmp = File(context.cacheDir, "import_${System.nanoTime()}.zip")
                temps += tmp
                context.contentResolver.openInputStream(archiveUri)?.use { i ->
                    tmp.outputStream().use { o -> i.copyTo(o) }
                }
                extractLibsFromZip(tmp, targetAbi, outDir, 0)
            }
            if (!isElf(mainLib)) {
                installedApkFiles().forEach { extractLibsFromZip(it, targetAbi, outDir, 0) }
            }
            if (!isElf(mainLib) && targetAbi == Build.SUPPORTED_ABIS.firstOrNull()) {
                val nativeDir = queryInstalledMinecraftPackage()?.nativeLibraryDir
                File(nativeDir.orEmpty()).listFiles { f -> f.name.endsWith(".so") }?.forEach { src ->
                    src.copyTo(File(outDir, src.name), overwrite = true)
                }
            }
        } catch (_: Exception) {
            // fall through: result is decided by the ELF check below
        } finally {
            temps.forEach { it.delete() }
        }
        isElf(mainLib)
    }

    @Suppress("DEPRECATION")
    private fun installedApkFiles(): List<File> {
        val pm = context.packageManager
        for (pkg in listOf("com.mojang.minecraftpe", "com.mojang.minecrafttrialpe")) {
            try {
                val ai = pm.getApplicationInfo(pkg, 0)
                return buildList {
                    add(File(ai.sourceDir))
                    ai.splitSourceDirs?.forEach { add(File(it)) }
                }
            } catch (_: PackageManager.NameNotFoundException) {
            }
        }
        return emptyList()
    }

    /** Extracts the .so files of the given ABI (atomically, size-checked) and also looks inside nested .apk entries. */
    private fun extractLibsFromZip(zipFile: File, abi: String, outDir: File, depth: Int) {
        if (!zipFile.isFile || zipFile.length() == 0L) return
        java.util.zip.ZipFile(zipFile).use { z ->
            val nested = mutableListOf<java.util.zip.ZipEntry>()
            for (e in z.entries()) {
                if (e.isDirectory) continue
                val n = e.name
                if (n.startsWith("lib/$abi/") && n.endsWith(".so")) {
                    val dest = File(outDir, n.substringAfterLast('/'))
                    val tmp = File(outDir, dest.name + ".tmp")
                    z.getInputStream(e).use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                    if (e.size < 0 || tmp.length() == e.size) {
                        dest.delete()
                        if (!tmp.renameTo(dest)) {
                            tmp.copyTo(dest, overwrite = true)
                            tmp.delete()
                        }
                    } else {
                        tmp.delete()
                    }
                } else if (depth < 1 && n.endsWith(".apk")) {
                    nested += e
                }
            }
            for (e in nested) {
                val tmp = File(context.cacheDir, "nested_${System.nanoTime()}.apk")
                try {
                    z.getInputStream(e).use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                    extractLibsFromZip(tmp, abi, outDir, depth + 1)
                } finally {
                    tmp.delete()
                }
            }
        }
    }

    suspend fun clearProfileCacheForAbi(profileId: String, targetAbi: String): Boolean = withContext(Dispatchers.IO) {
        val targetFile = File(cacheRootDir, "$profileId/$targetAbi/libminecraftpe.so")
        if (targetFile.exists()) {
            targetFile.delete()
        }
        !targetFile.exists()
    }

    suspend fun inspectArchiveUri(uri: Uri, deviceSupportedAbis: List<String>): ApkInspectionResult =
        withContext(Dispatchers.IO) {
            val fileName = resolveFileName(uri)
            val fileSize = resolveFileSize(uri)
            val foundLibs = mutableListOf<NativeLibEntry>()
            val splitApks = mutableListOf<String>()
            val splitFragments = mutableListOf<InstalledSplitFragment>()
            var hasAssets = false

            try {
                context.contentResolver.openInputStream(uri)?.use { rawStream ->
                    BufferedInputStream(rawStream, 64 * 1024).use { buffered ->
                        ZipInputStream(buffered).use { zis ->
                            var entry = zis.nextEntry
                            while (entry != null) {
                                val name = entry.name
                                if (!entry.isDirectory) {
                                    when {
                                        name.startsWith("assets/") -> hasAssets = true
                                        name.startsWith("lib/") && name.endsWith("/libminecraftpe.so") -> {
                                            val parts = name.split("/")
                                            val abi = parts.getOrNull(1) ?: "unknown"
                                            foundLibs.add(
                                                NativeLibEntry(
                                                    abi = abi,
                                                    entryPath = name,
                                                    compressedSize = entry.compressedSize.coerceAtLeast(0L),
                                                    uncompressedSize = entry.size.coerceAtLeast(0L),
                                                    sourceApkName = fileName
                                                )
                                            )
                                        }
                                        name.endsWith(".apk", ignoreCase = true) -> {
                                            splitApks.add(name)
                                            val nestedResult = scanNestedApkStream(zis, name)
                                            foundLibs.addAll(nestedResult.libs)
                                            if (nestedResult.hasAssets) hasAssets = true
                                            val resolvedSize = if (entry.size > 0L) entry.size else nestedResult.bytesConsumed
                                            val shortName = name.substringAfterLast('/')
                                            splitFragments.add(
                                                InstalledSplitFragment(
                                                    splitName = shortName.removeSuffix(".apk"),
                                                    category = classifySplitApkName(shortName),
                                                    sourcePath = "$fileName!/$name",
                                                    sizeBytes = resolvedSize,
                                                    existsOnDisk = true
                                                )
                                            )
                                        }
                                    }
                                }
                                zis.closeEntry()
                                entry = zis.nextEntry
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                return@withContext ApkInspectionResult(
                    fileName = fileName,
                    fileSizeBytes = fileSize,
                    isSplitArchive = false,
                    splitApkNames = emptyList(),
                    foundNativeLibs = emptyList(),
                    hasAssetsFolder = false,
                    compatibleWithDevice = false,
                    missingPrimaryAbi = true,
                    diagnosisSummaryEn = "Failed to parse archive: ${e.message ?: "Invalid ZIP/APK header"}",
                    diagnosisSummaryAr = "تعذّر فحص الملف: ${e.message ?: "ملف ZIP/APK غير صالح"}"
                )
            }

            val primaryAbi = deviceSupportedAbis.firstOrNull() ?: "arm64-v8a"
            val compatible = foundLibs.any { it.abi in deviceSupportedAbis }
            val hasPrimary = foundLibs.any { it.abi == primaryAbi }
            val isSplit = splitApks.isNotEmpty()
            val resAndLangBytes = splitFragments
                .filter { it.category == SplitCategory.RESOURCE_DENSITY || it.category == SplitCategory.LANGUAGE }
                .sumOf { it.sizeBytes }
            val totalSplitBytes = splitFragments.sumOf { it.sizeBytes }

            val (summaryEn, summaryAr) = when {
                foundLibs.isEmpty() && isSplit -> Pair(
                    "Split archive detected (${splitApks.size} APKs), but no libminecraftpe.so found. Missing native split APK (split_config.$primaryAbi.apk).",
                    "تم اكتشاف حزمة مقسمة (${splitApks.size} ملفات APK)، لكن مكتبة libminecraftpe.so غير موجودة. ينقصك ملف split_config.$primaryAbi.apk."
                )
                foundLibs.isEmpty() -> Pair(
                    "No libminecraftpe.so found in archive. This file appears to be a base-only split APK or non-Minecraft package.",
                    "لم يتم العثور على libminecraftpe.so داخل الملف. قد يكون ملف base.apk فقط بدون ملف المعمارية."
                )
                !compatible -> Pair(
                    "Found ${foundLibs.joinToString { it.abi }}, which is incompatible with device ABIs (${deviceSupportedAbis.joinToString()}).",
                    "تم العثور على معمارية (${foundLibs.joinToString { it.abi }}) وهي غير متوافقة مع جهازك (${deviceSupportedAbis.joinToString()})."
                )
                !hasPrimary -> Pair(
                    "Compatible secondary ABI found (${foundLibs.joinToString { it.abi }}), but primary ABI $primaryAbi is missing. Switch target ABI or import $primaryAbi split.",
                    "توجد معمارية بديلة متوافقة (${foundLibs.joinToString { it.abi }}) لكن المعمارية الأساسية $primaryAbi مفقودة."
                )
                else -> Pair(
                    "Verified! Found lib/$primaryAbi/libminecraftpe.so inside ${foundLibs.first { it.abi == primaryAbi }.sourceApkName}. Ready for library cache.",
                    "تم التحقق بنجاح! تم العثور على lib/$primaryAbi/libminecraftpe.so وهو جاهز للتخزين في الذاكرة المؤقتة."
                )
            }

            ApkInspectionResult(
                fileName = fileName,
                fileSizeBytes = fileSize,
                isSplitArchive = isSplit,
                splitApkNames = splitApks,
                splitFragments = splitFragments,
                resourceAndLanguageTotalBytes = resAndLangBytes,
                totalArchiveSplitBytes = totalSplitBytes,
                foundNativeLibs = foundLibs,
                hasAssetsFolder = hasAssets,
                compatibleWithDevice = compatible,
                missingPrimaryAbi = !hasPrimary,
                diagnosisSummaryEn = summaryEn,
                diagnosisSummaryAr = summaryAr
            )
        }

    private data class NestedApkScanResult(
        val libs: List<NativeLibEntry>,
        val hasAssets: Boolean,
        val bytesConsumed: Long
    )

    private fun scanNestedApkStream(
        parentStream: InputStream,
        nestedApkName: String
    ): NestedApkScanResult {
        val libs = mutableListOf<NativeLibEntry>()
        var hasAssets = false
        var bytesRead = 0L
        val countingStream = object : InputStream() {
            override fun read(): Int {
                val b = parentStream.read()
                if (b >= 0) bytesRead++
                return b
            }

            override fun read(b: ByteArray, off: Int, len: Int): Int {
                val n = parentStream.read(b, off, len)
                if (n > 0) bytesRead += n
                return n
            }

            override fun close() { /* Do not close outer ZipInputStream */ }
        }
        try {
            val nestedZip = ZipInputStream(countingStream)
            var entry = nestedZip.nextEntry
            while (entry != null) {
                val name = entry.name
                if (!entry.isDirectory) {
                    if (name.startsWith("assets/")) hasAssets = true
                    if (name.startsWith("lib/") && name.endsWith("/libminecraftpe.so")) {
                        val abi = name.split("/").getOrNull(1) ?: "unknown"
                        libs.add(
                            NativeLibEntry(
                                abi = abi,
                                entryPath = name,
                                compressedSize = entry.compressedSize.coerceAtLeast(0L),
                                uncompressedSize = entry.size.coerceAtLeast(0L),
                                sourceApkName = nestedApkName
                            )
                        )
                    }
                }
                nestedZip.closeEntry()
                entry = nestedZip.nextEntry
            }
            // Drain any trailing central directory bytes of the nested APK to measure full size
            val buf = ByteArray(8192)
            while (countingStream.read(buf, 0, buf.size) > 0) {
                // countingStream updates bytesRead
            }
        } catch (_: Exception) {
            // Nested entry could not be parsed cleanly
        }
        return NestedApkScanResult(libs, hasAssets, bytesRead)
    }

    private fun resolveFileName(uri: Uri): String {
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (nameIdx >= 0 && cursor.moveToFirst()) {
                return cursor.getString(nameIdx) ?: "selected_package.apk"
            }
        }
        return uri.lastPathSegment ?: "selected_package.apk"
    }

    private fun resolveFileSize(uri: Uri): Long {
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
            if (sizeIdx >= 0 && cursor.moveToFirst()) {
                return cursor.getLong(sizeIdx)
            }
        }
        return 0L
    }

    private fun computeSha256Short(bytes: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(bytes)
        return digest.take(6).joinToString("") { "%02x".format(it) }
    }
}
